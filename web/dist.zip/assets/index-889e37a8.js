import{d as E,h as f,r as L,c as w,w as je,n as Le,t as W,a as p,b as ft,e as _,f as pt,g as N,i as C,u as gt,N as De,T as _t,j as bt,k as Me,l as xe,m as J,o as xt,p as ye,q as yt,s as Ct,v as Ce,x as wt,y as zt,z as Ue,A as It,B as St,C as Z,D as se,E as $t,F as kt,G as V,H as X,I as q,J as Nt,K as he,L as me,M as we,O as ee,P as Rt,Q as Pt,R as fe,S as D,U as At,V as Ht,W as ze,X as qe,Y as b,Z as H,_ as M,$ as A,a0 as pe,a1 as k,a2 as Ge,a3 as te,a4 as F,a5 as Ye,a6 as ce,a7 as S,a8 as Q,a9 as Ie,aa as Lt,ab as ge,ac as Mt,ad as Bt,ae as Tt,af as Et,ag as B,ah as ie,ai as Be,aj as Ot,ak as ae,al as Ft,am as Kt,an as Xe,ao as Vt,ap as jt,aq as Dt,ar as Te,as as Ut,at as qt,au as Gt,av as Yt}from"./index-5696747f.js";import{N as We}from"./Dropdown-9dd5d126.js";import{s as Ee}from"./sanitize-0635dc57.js";import{_ as Ze}from"./_plugin-vue_export-helper-c27b6911.js";import{g as Xt,c as ve,V as Wt}from"./create-0fb7cf4a.js";import{N as Zt}from"./Popover-54994fb3.js";import{N as Jt}from"./Tag-b56d7bab.js";import{_ as Qt}from"./logo-b6f36c2e.js";import{l as eo,N as to,a as oo}from"./LayoutSider-f792c304.js";import{_ as no}from"./Tooltip-fd22a75d.js";import{u as Oe}from"./use-merged-state-a7aebbe5.js";import{u as ro}from"./use-compitable-77ab7946.js";import"./get-8c56e614.js";const io=E({name:"ChevronDownFilled",render(){return f("svg",{viewBox:"0 0 16 16",fill:"none",xmlns:"http://www.w3.org/2000/svg"},f("path",{d:"M3.20041 5.73966C3.48226 5.43613 3.95681 5.41856 4.26034 5.70041L8 9.22652L11.7397 5.70041C12.0432 5.41856 12.5177 5.43613 12.7996 5.73966C13.0815 6.0432 13.0639 6.51775 12.7603 6.7996L8.51034 10.7996C8.22258 11.0668 7.77743 11.0668 7.48967 10.7996L3.23966 6.7996C2.93613 6.51775 2.91856 6.0432 3.20041 5.73966Z",fill:"currentColor"}))}}),Fe=E({name:"SlotMachineNumber",props:{clsPrefix:{type:String,required:!0},value:{type:[Number,String],required:!0},oldOriginalNumber:{type:Number,default:void 0},newOriginalNumber:{type:Number,default:void 0}},setup(e){const t=L(null),o=L(e.value),a=L(e.value),i=L("up"),n=L(!1),s=w(()=>n.value?`${e.clsPrefix}-base-slot-machine-current-number--${i.value}-scroll`:null),u=w(()=>n.value?`${e.clsPrefix}-base-slot-machine-old-number--${i.value}-scroll`:null);je(W(e,"value"),(d,v)=>{o.value=v,a.value=d,Le(m)});function m(){const d=e.newOriginalNumber,v=e.oldOriginalNumber;v===void 0||d===void 0||(d>v?x("up"):v>d&&x("down"))}function x(d){i.value=d,n.value=!1,Le(()=>{var v;(v=t.value)===null||v===void 0||v.offsetWidth,n.value=!0})}return()=>{const{clsPrefix:d}=e;return f("span",{ref:t,class:`${d}-base-slot-machine-number`},o.value!==null?f("span",{class:[`${d}-base-slot-machine-old-number ${d}-base-slot-machine-old-number--top`,u.value]},o.value):null,f("span",{class:[`${d}-base-slot-machine-current-number`,s.value]},f("span",{ref:"numberWrapper",class:[`${d}-base-slot-machine-current-number__inner`,typeof e.value!="number"&&`${d}-base-slot-machine-current-number__inner--not-number`]},a.value)),o.value!==null?f("span",{class:[`${d}-base-slot-machine-old-number ${d}-base-slot-machine-old-number--bottom`,u.value]},o.value):null)}}}),{cubicBezierEaseOut:Y}=ft;function ao({duration:e=".2s"}={}){return[p("&.fade-up-width-expand-transition-leave-active",{transition:`
 opacity ${e} ${Y},
 max-width ${e} ${Y},
 transform ${e} ${Y}
 `}),p("&.fade-up-width-expand-transition-enter-active",{transition:`
 opacity ${e} ${Y},
 max-width ${e} ${Y},
 transform ${e} ${Y}
 `}),p("&.fade-up-width-expand-transition-enter-to",{opacity:1,transform:"translateX(0) translateY(0)"}),p("&.fade-up-width-expand-transition-enter-from",{maxWidth:"0 !important",opacity:0,transform:"translateY(60%)"}),p("&.fade-up-width-expand-transition-leave-from",{opacity:1,transform:"translateY(0)"}),p("&.fade-up-width-expand-transition-leave-to",{maxWidth:"0 !important",opacity:0,transform:"translateY(60%)"})]}const lo=p([p("@keyframes n-base-slot-machine-fade-up-in",`
 from {
 transform: translateY(60%);
 opacity: 0;
 }
 to {
 transform: translateY(0);
 opacity: 1;
 }
 `),p("@keyframes n-base-slot-machine-fade-down-in",`
 from {
 transform: translateY(-60%);
 opacity: 0;
 }
 to {
 transform: translateY(0);
 opacity: 1;
 }
 `),p("@keyframes n-base-slot-machine-fade-up-out",`
 from {
 transform: translateY(0%);
 opacity: 1;
 }
 to {
 transform: translateY(-60%);
 opacity: 0;
 }
 `),p("@keyframes n-base-slot-machine-fade-down-out",`
 from {
 transform: translateY(0%);
 opacity: 1;
 }
 to {
 transform: translateY(60%);
 opacity: 0;
 }
 `),_("base-slot-machine",`
 overflow: hidden;
 white-space: nowrap;
 display: inline-block;
 height: 18px;
 line-height: 18px;
 `,[_("base-slot-machine-number",`
 display: inline-block;
 position: relative;
 height: 18px;
 width: .6em;
 max-width: .6em;
 `,[ao({duration:".2s"}),pt({duration:".2s",delay:"0s"}),_("base-slot-machine-old-number",`
 display: inline-block;
 opacity: 0;
 position: absolute;
 left: 0;
 right: 0;
 `,[N("top",{transform:"translateY(-100%)"}),N("bottom",{transform:"translateY(100%)"}),N("down-scroll",{animation:"n-base-slot-machine-fade-down-out .2s cubic-bezier(0, 0, .2, 1)",animationIterationCount:1}),N("up-scroll",{animation:"n-base-slot-machine-fade-up-out .2s cubic-bezier(0, 0, .2, 1)",animationIterationCount:1})]),_("base-slot-machine-current-number",`
 display: inline-block;
 position: absolute;
 left: 0;
 top: 0;
 bottom: 0;
 right: 0;
 opacity: 1;
 transform: translateY(0);
 width: .6em;
 `,[N("down-scroll",{animation:"n-base-slot-machine-fade-down-in .2s cubic-bezier(0, 0, .2, 1)",animationIterationCount:1}),N("up-scroll",{animation:"n-base-slot-machine-fade-up-in .2s cubic-bezier(0, 0, .2, 1)",animationIterationCount:1}),C("inner",`
 display: inline-block;
 position: absolute;
 right: 0;
 top: 0;
 width: .6em;
 `,[N("not-number",`
 right: unset;
 left: 0;
 `)])])])])]),co=E({name:"BaseSlotMachine",props:{clsPrefix:{type:String,required:!0},value:{type:[Number,String],default:0},max:{type:Number,default:void 0},appeared:{type:Boolean,required:!0}},setup(e){gt("-base-slot-machine",lo,W(e,"clsPrefix"));const t=L(),o=L(),a=w(()=>{if(typeof e.value=="string")return[];if(e.value<1)return[0];const i=[];let n=e.value;for(e.max!==void 0&&(n=Math.min(e.max,n));n>=1;)i.push(n%10),n/=10,n=Math.floor(n);return i.reverse(),i});return je(W(e,"value"),(i,n)=>{typeof i=="string"?(o.value=void 0,t.value=void 0):typeof n=="string"?(o.value=i,t.value=void 0):(o.value=i,t.value=n)}),()=>{const{value:i,clsPrefix:n}=e;return typeof i=="number"?f("span",{class:`${n}-base-slot-machine`},f(_t,{name:"fade-up-width-expand-transition",tag:"span"},{default:()=>a.value.map((s,u)=>f(Fe,{clsPrefix:n,key:a.value.length-u-1,oldOriginalNumber:t.value,newOriginalNumber:o.value,value:s}))}),f(De,{key:"+",width:!0},{default:()=>e.max!==void 0&&e.max<i?f(Fe,{clsPrefix:n,value:"+"}):null})):f("span",{class:`${n}-base-slot-machine`},i)}}});function so(e){const{errorColor:t,infoColor:o,successColor:a,warningColor:i,fontFamily:n}=e;return{color:t,colorInfo:o,colorSuccess:a,colorError:t,colorWarning:i,fontSize:"12px",fontFamily:n}}const uo={name:"Badge",common:bt,self:so},mo=uo,vo=p([p("@keyframes badge-wave-spread",{from:{boxShadow:"0 0 0.5px 0px var(--n-ripple-color)",opacity:.6},to:{boxShadow:"0 0 0.5px 4.5px var(--n-ripple-color)",opacity:0}}),_("badge",`
 display: inline-flex;
 position: relative;
 vertical-align: middle;
 font-family: var(--n-font-family);
 `,[N("as-is",[_("badge-sup",{position:"static",transform:"translateX(0)"},[Me({transformOrigin:"left bottom",originalTransform:"translateX(0)"})])]),N("dot",[_("badge-sup",`
 height: 8px;
 width: 8px;
 padding: 0;
 min-width: 8px;
 left: 100%;
 bottom: calc(100% - 4px);
 `,[p("::before","border-radius: 4px;")])]),_("badge-sup",`
 background: var(--n-color);
 transition:
 background-color .3s var(--n-bezier),
 color .3s var(--n-bezier);
 color: #FFF;
 position: absolute;
 height: 18px;
 line-height: 18px;
 border-radius: 9px;
 padding: 0 6px;
 text-align: center;
 font-size: var(--n-font-size);
 transform: translateX(-50%);
 left: 100%;
 bottom: calc(100% - 9px);
 font-variant-numeric: tabular-nums;
 z-index: 1;
 display: flex;
 align-items: center;
 `,[Me({transformOrigin:"left bottom",originalTransform:"translateX(-50%)"}),_("base-wave",{zIndex:1,animationDuration:"2s",animationIterationCount:"infinite",animationDelay:"1s",animationTimingFunction:"var(--n-ripple-bezier)",animationName:"badge-wave-spread"}),p("&::before",`
 opacity: 0;
 transform: scale(1);
 border-radius: 9px;
 content: "";
 position: absolute;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 `)])])]),ho=Object.assign(Object.assign({},J.props),{value:[String,Number],max:Number,dot:Boolean,type:{type:String,default:"default"},show:{type:Boolean,default:!0},showZero:Boolean,processing:Boolean,color:String,offset:Array}),fo=E({name:"Badge",props:ho,setup(e,{slots:t}){const{mergedClsPrefixRef:o,inlineThemeDisabled:a,mergedRtlRef:i}=xe(e),n=J("Badge","-badge",vo,mo,e,o),s=L(!1),u=()=>{s.value=!0},m=()=>{s.value=!1},x=w(()=>e.show&&(e.dot||e.value!==void 0&&!(!e.showZero&&Number(e.value)<=0)||!xt(t.value)));ye(()=>{x.value&&(s.value=!0)});const d=yt("Badge",i,o),v=w(()=>{const{type:h,color:z}=e,{common:{cubicBezierEaseInOut:$,cubicBezierEaseOut:T},self:{[Ct("color",h)]:K,fontFamily:j,fontSize:G}}=n.value;return{"--n-font-size":G,"--n-font-family":j,"--n-color":z||K,"--n-ripple-color":z||K,"--n-bezier":$,"--n-ripple-bezier":T}}),c=a?Ce("badge",w(()=>{let h="";const{type:z,color:$}=e;return z&&(h+=z[0]),$&&(h+=wt($)),h}),v,e):void 0,P=w(()=>{const{offset:h}=e;if(!h)return;const[z,$]=h,T=typeof z=="number"?`${z}px`:z,K=typeof $=="number"?`${$}px`:$;return{transform:`translate(calc(${d?.value?"50%":"-50%"} + ${T}), ${K})`}});return{rtlEnabled:d,mergedClsPrefix:o,appeared:s,showBadge:x,handleAfterEnter:u,handleAfterLeave:m,cssVars:a?void 0:v,themeClass:c?.themeClass,onRender:c?.onRender,offsetStyle:P}},render(){var e;const{mergedClsPrefix:t,onRender:o,themeClass:a,$slots:i}=this;o?.();const n=(e=i.default)===null||e===void 0?void 0:e.call(i);return f("div",{class:[`${t}-badge`,this.rtlEnabled&&`${t}-badge--rtl`,a,{[`${t}-badge--dot`]:this.dot,[`${t}-badge--as-is`]:!n}],style:this.cssVars},n,f(zt,{name:"fade-in-scale-up-transition",onAfterEnter:this.handleAfterEnter,onAfterLeave:this.handleAfterLeave},{default:()=>this.showBadge?f("sup",{class:`${t}-badge-sup`,title:Xt(this.value),style:this.offsetStyle},Ue(i.value,()=>[this.dot?null:f(co,{clsPrefix:t,appeared:this.appeared,max:this.max,value:this.value})]),this.processing?f(It,{clsPrefix:t}):null):null}))}}),po=_("breadcrumb",`
 white-space: nowrap;
 cursor: default;
 line-height: var(--n-item-line-height);
`,[p("ul",`
 list-style: none;
 padding: 0;
 margin: 0;
 `),p("a",`
 color: inherit;
 text-decoration: inherit;
 `),_("breadcrumb-item",`
 font-size: var(--n-font-size);
 transition: color .3s var(--n-bezier);
 display: inline-flex;
 align-items: center;
 `,[_("icon",`
 font-size: 18px;
 vertical-align: -.2em;
 transition: color .3s var(--n-bezier);
 color: var(--n-item-text-color);
 `),p("&:not(:last-child)",[N("clickable",[C("link",`
 cursor: pointer;
 `,[p("&:hover",`
 background-color: var(--n-item-color-hover);
 `),p("&:active",`
 background-color: var(--n-item-color-pressed); 
 `)])])]),C("link",`
 padding: 4px;
 border-radius: var(--n-item-border-radius);
 transition:
 background-color .3s var(--n-bezier),
 color .3s var(--n-bezier);
 color: var(--n-item-text-color);
 position: relative;
 `,[p("&:hover",`
 color: var(--n-item-text-color-hover);
 `,[_("icon",`
 color: var(--n-item-text-color-hover);
 `)]),p("&:active",`
 color: var(--n-item-text-color-pressed);
 `,[_("icon",`
 color: var(--n-item-text-color-pressed);
 `)])]),C("separator",`
 margin: 0 8px;
 color: var(--n-separator-color);
 transition: color .3s var(--n-bezier);
 user-select: none;
 -webkit-user-select: none;
 `),p("&:last-child",[C("link",`
 font-weight: var(--n-font-weight-active);
 cursor: unset;
 color: var(--n-item-text-color-active);
 `,[_("icon",`
 color: var(--n-item-text-color-active);
 `)]),C("separator",`
 display: none;
 `)])])]),Je=se("n-breadcrumb"),go=Object.assign(Object.assign({},J.props),{separator:{type:String,default:"/"}}),_o=E({name:"Breadcrumb",props:go,setup(e){const{mergedClsPrefixRef:t,inlineThemeDisabled:o}=xe(e),a=J("Breadcrumb","-breadcrumb",po,St,e,t);Z(Je,{separatorRef:W(e,"separator"),mergedClsPrefixRef:t});const i=w(()=>{const{common:{cubicBezierEaseInOut:s},self:{separatorColor:u,itemTextColor:m,itemTextColorHover:x,itemTextColorPressed:d,itemTextColorActive:v,fontSize:c,fontWeightActive:P,itemBorderRadius:h,itemColorHover:z,itemColorPressed:$,itemLineHeight:T}}=a.value;return{"--n-font-size":c,"--n-bezier":s,"--n-item-text-color":m,"--n-item-text-color-hover":x,"--n-item-text-color-pressed":d,"--n-item-text-color-active":v,"--n-separator-color":u,"--n-item-color-hover":z,"--n-item-color-pressed":$,"--n-item-border-radius":h,"--n-font-weight-active":P,"--n-item-line-height":T}}),n=o?Ce("breadcrumb",void 0,i,e):void 0;return{mergedClsPrefix:t,cssVars:o?void 0:i,themeClass:n?.themeClass,onRender:n?.onRender}},render(){var e;return(e=this.onRender)===null||e===void 0||e.call(this),f("nav",{class:[`${this.mergedClsPrefix}-breadcrumb`,this.themeClass],style:this.cssVars,"aria-label":"Breadcrumb"},f("ul",null,this.$slots))}});function bo(e=kt?window:null){const t=()=>{const{hash:i,host:n,hostname:s,href:u,origin:m,pathname:x,port:d,protocol:v,search:c}=e?.location||{};return{hash:i,host:n,hostname:s,href:u,origin:m,pathname:x,port:d,protocol:v,search:c}},o=L(t()),a=()=>{o.value=t()};return ye(()=>{e&&(e.addEventListener("popstate",a),e.addEventListener("hashchange",a))}),$t(()=>{e&&(e.removeEventListener("popstate",a),e.removeEventListener("hashchange",a))}),o}const xo={separator:String,href:String,clickable:{type:Boolean,default:!0},onClick:Function},yo=E({name:"BreadcrumbItem",props:xo,setup(e,{slots:t}){const o=V(Je,null);if(!o)return()=>null;const{separatorRef:a,mergedClsPrefixRef:i}=o,n=bo(),s=w(()=>e.href?"a":"span"),u=w(()=>n.value.href===e.href?"location":null);return()=>{const{value:m}=i;return f("li",{class:[`${m}-breadcrumb-item`,e.clickable&&`${m}-breadcrumb-item--clickable`]},f(s.value,{class:`${m}-breadcrumb-item__link`,"aria-current":u.value,href:e.href,onClick:e.onClick},t),f("span",{class:`${m}-breadcrumb-item__separator`,"aria-hidden":"true"},Ue(t.separator,()=>{var x;return[(x=e.separator)!==null&&x!==void 0?x:a.value]})))}}}),oe=se("n-menu"),Se=se("n-submenu"),$e=se("n-menu-item-group"),le=8;function ke(e){const t=V(oe),{props:o,mergedCollapsedRef:a}=t,i=V(Se,null),n=V($e,null),s=w(()=>o.mode==="horizontal"),u=w(()=>s.value?o.dropdownPlacement:"tmNodes"in e?"right-start":"right"),m=w(()=>{var c;return Math.max((c=o.collapsedIconSize)!==null&&c!==void 0?c:o.iconSize,o.iconSize)}),x=w(()=>{var c;return!s.value&&e.root&&a.value&&(c=o.collapsedIconSize)!==null&&c!==void 0?c:o.iconSize}),d=w(()=>{if(s.value)return;const{collapsedWidth:c,indent:P,rootIndent:h}=o,{root:z,isGroup:$}=e,T=h===void 0?P:h;return z?a.value?c/2-m.value/2:T:n&&typeof n.paddingLeftRef.value=="number"?P/2+n.paddingLeftRef.value:i&&typeof i.paddingLeftRef.value=="number"?($?P/2:P)+i.paddingLeftRef.value:0}),v=w(()=>{const{collapsedWidth:c,indent:P,rootIndent:h}=o,{value:z}=m,{root:$}=e;return s.value||!$||!a.value?le:(h===void 0?P:h)+z+le-(c+z)/2});return{dropdownPlacement:u,activeIconSize:x,maxIconSize:m,paddingLeft:d,iconMarginRight:v,NMenu:t,NSubmenu:i}}const Ne={internalKey:{type:[String,Number],required:!0},root:Boolean,isGroup:Boolean,level:{type:Number,required:!0},title:[String,Function],extra:[String,Function]},Qe=Object.assign(Object.assign({},Ne),{tmNode:{type:Object,required:!0},tmNodes:{type:Array,required:!0}}),Co=E({name:"MenuOptionGroup",props:Qe,setup(e){Z(Se,null);const t=ke(e);Z($e,{paddingLeftRef:t.paddingLeft});const{mergedClsPrefixRef:o,props:a}=V(oe);return function(){const{value:i}=o,n=t.paddingLeft.value,{nodeProps:s}=a,u=s?.(e.tmNode.rawNode);return f("div",{class:`${i}-menu-item-group`,role:"group"},f("div",Object.assign({},u,{class:[`${i}-menu-item-group-title`,u?.class],style:[u?.style||"",n!==void 0?`padding-left: ${n}px;`:""]}),X(e.title),e.extra?f(q,null," ",X(e.extra)):null),f("div",null,e.tmNodes.map(m=>Re(m,a))))}}}),et=E({name:"MenuOptionContent",props:{collapsed:Boolean,disabled:Boolean,title:[String,Function],icon:Function,extra:[String,Function],showArrow:Boolean,childActive:Boolean,hover:Boolean,paddingLeft:Number,selected:Boolean,maxIconSize:{type:Number,required:!0},activeIconSize:{type:Number,required:!0},iconMarginRight:{type:Number,required:!0},clsPrefix:{type:String,required:!0},onClick:Function,tmNode:{type:Object,required:!0},isEllipsisPlaceholder:Boolean},setup(e){const{props:t}=V(oe);return{menuProps:t,style:w(()=>{const{paddingLeft:o}=e;return{paddingLeft:o&&`${o}px`}}),iconStyle:w(()=>{const{maxIconSize:o,activeIconSize:a,iconMarginRight:i}=e;return{width:`${o}px`,height:`${o}px`,fontSize:`${a}px`,marginRight:`${i}px`}})}},render(){const{clsPrefix:e,tmNode:t,menuProps:{renderIcon:o,renderLabel:a,renderExtra:i,expandIcon:n}}=this,s=o?o(t.rawNode):X(this.icon);return f("div",{onClick:u=>{var m;(m=this.onClick)===null||m===void 0||m.call(this,u)},role:"none",class:[`${e}-menu-item-content`,{[`${e}-menu-item-content--selected`]:this.selected,[`${e}-menu-item-content--collapsed`]:this.collapsed,[`${e}-menu-item-content--child-active`]:this.childActive,[`${e}-menu-item-content--disabled`]:this.disabled,[`${e}-menu-item-content--hover`]:this.hover}],style:this.style},s&&f("div",{class:`${e}-menu-item-content__icon`,style:this.iconStyle,role:"none"},[s]),f("div",{class:`${e}-menu-item-content-header`,role:"none"},this.isEllipsisPlaceholder?this.title:a?a(t.rawNode):X(this.title),this.extra||i?f("span",{class:`${e}-menu-item-content-header__extra`}," ",i?i(t.rawNode):X(this.extra)):null),this.showArrow?f(Nt,{ariaHidden:!0,class:`${e}-menu-item-content__arrow`,clsPrefix:e},{default:()=>n?n(t.rawNode):f(io,null)}):null)}}),tt=Object.assign(Object.assign({},Ne),{rawNodes:{type:Array,default:()=>[]},tmNodes:{type:Array,default:()=>[]},tmNode:{type:Object,required:!0},disabled:Boolean,icon:Function,onClick:Function,domId:String,virtualChildActive:{type:Boolean,default:void 0},isEllipsisPlaceholder:Boolean}),_e=E({name:"Submenu",props:tt,setup(e){const t=ke(e),{NMenu:o,NSubmenu:a}=t,{props:i,mergedCollapsedRef:n,mergedThemeRef:s}=o,u=w(()=>{const{disabled:c}=e;return a?.mergedDisabledRef.value||i.disabled?!0:c}),m=L(!1);Z(Se,{paddingLeftRef:t.paddingLeft,mergedDisabledRef:u}),Z($e,null);function x(){const{onClick:c}=e;c&&c()}function d(){u.value||(n.value||o.toggleExpand(e.internalKey),x())}function v(c){m.value=c}return{menuProps:i,mergedTheme:s,doSelect:o.doSelect,inverted:o.invertedRef,isHorizontal:o.isHorizontalRef,mergedClsPrefix:o.mergedClsPrefixRef,maxIconSize:t.maxIconSize,activeIconSize:t.activeIconSize,iconMarginRight:t.iconMarginRight,dropdownPlacement:t.dropdownPlacement,dropdownShow:m,paddingLeft:t.paddingLeft,mergedDisabled:u,mergedValue:o.mergedValueRef,childActive:he(()=>{var c;return(c=e.virtualChildActive)!==null&&c!==void 0?c:o.activePathRef.value.includes(e.internalKey)}),collapsed:w(()=>i.mode==="horizontal"?!1:n.value?!0:!o.mergedExpandedKeysRef.value.includes(e.internalKey)),dropdownEnabled:w(()=>!u.value&&(i.mode==="horizontal"||n.value)),handlePopoverShowChange:v,handleClick:d}},render(){var e;const{mergedClsPrefix:t,menuProps:{renderIcon:o,renderLabel:a}}=this,i=()=>{const{isHorizontal:s,paddingLeft:u,collapsed:m,mergedDisabled:x,maxIconSize:d,activeIconSize:v,title:c,childActive:P,icon:h,handleClick:z,menuProps:{nodeProps:$},dropdownShow:T,iconMarginRight:K,tmNode:j,mergedClsPrefix:G,isEllipsisPlaceholder:de,extra:ne}=this,O=$?.(j.rawNode);return f("div",Object.assign({},O,{class:[`${G}-menu-item`,O?.class],role:"menuitem"}),f(et,{tmNode:j,paddingLeft:u,collapsed:m,disabled:x,iconMarginRight:K,maxIconSize:d,activeIconSize:v,title:c,extra:ne,showArrow:!s,childActive:P,clsPrefix:G,icon:h,hover:T,onClick:z,isEllipsisPlaceholder:de}))},n=()=>f(De,null,{default:()=>{const{tmNodes:s,collapsed:u}=this;return u?null:f("div",{class:`${t}-submenu-children`,role:"menu"},s.map(m=>Re(m,this.menuProps)))}});return this.root?f(We,Object.assign({size:"large",trigger:"hover"},(e=this.menuProps)===null||e===void 0?void 0:e.dropdownProps,{themeOverrides:this.mergedTheme.peerOverrides.Dropdown,theme:this.mergedTheme.peers.Dropdown,builtinThemeOverrides:{fontSizeLarge:"14px",optionIconSizeLarge:"18px"},value:this.mergedValue,disabled:!this.dropdownEnabled,placement:this.dropdownPlacement,keyField:this.menuProps.keyField,labelField:this.menuProps.labelField,childrenField:this.menuProps.childrenField,onUpdateShow:this.handlePopoverShowChange,options:this.rawNodes,onSelect:this.doSelect,inverted:this.inverted,renderIcon:o,renderLabel:a}),{default:()=>f("div",{class:`${t}-submenu`,role:"menu","aria-expanded":!this.collapsed,id:this.domId},i(),this.isHorizontal?null:n())}):f("div",{class:`${t}-submenu`,role:"menu","aria-expanded":!this.collapsed,id:this.domId},i(),n())}}),ot=Object.assign(Object.assign({},Ne),{tmNode:{type:Object,required:!0},disabled:Boolean,icon:Function,onClick:Function}),wo=E({name:"MenuOption",props:ot,setup(e){const t=ke(e),{NSubmenu:o,NMenu:a}=t,{props:i,mergedClsPrefixRef:n,mergedCollapsedRef:s}=a,u=o?o.mergedDisabledRef:{value:!1},m=w(()=>u.value||e.disabled);function x(v){const{onClick:c}=e;c&&c(v)}function d(v){m.value||(a.doSelect(e.internalKey,e.tmNode.rawNode),x(v))}return{mergedClsPrefix:n,dropdownPlacement:t.dropdownPlacement,paddingLeft:t.paddingLeft,iconMarginRight:t.iconMarginRight,maxIconSize:t.maxIconSize,activeIconSize:t.activeIconSize,mergedTheme:a.mergedThemeRef,menuProps:i,dropdownEnabled:he(()=>e.root&&s.value&&i.mode!=="horizontal"&&!m.value),selected:he(()=>a.mergedValueRef.value===e.internalKey),mergedDisabled:m,handleClick:d}},render(){const{mergedClsPrefix:e,mergedTheme:t,tmNode:o,menuProps:{renderLabel:a,nodeProps:i}}=this,n=i?.(o.rawNode);return f("div",Object.assign({},n,{role:"menuitem",class:[`${e}-menu-item`,n?.class]}),f(no,{theme:t.peers.Tooltip,themeOverrides:t.peerOverrides.Tooltip,trigger:"hover",placement:this.dropdownPlacement,disabled:!this.dropdownEnabled||this.title===void 0,internalExtraClass:["menu-tooltip"]},{default:()=>a?a(o.rawNode):X(this.title),trigger:()=>f(et,{tmNode:o,clsPrefix:e,paddingLeft:this.paddingLeft,iconMarginRight:this.iconMarginRight,maxIconSize:this.maxIconSize,activeIconSize:this.activeIconSize,selected:this.selected,title:this.title,extra:this.extra,disabled:this.mergedDisabled,icon:this.icon,onClick:this.handleClick})}))}}),zo=E({name:"MenuDivider",setup(){const e=V(oe),{mergedClsPrefixRef:t,isHorizontalRef:o}=e;return()=>o.value?null:f("div",{class:`${t.value}-menu-divider`})}}),Io=we(Qe),So=we(ot),$o=we(tt);function be(e){return e.type==="divider"||e.type==="render"}function ko(e){return e.type==="divider"}function Re(e,t){const{rawNode:o}=e,{show:a}=o;if(a===!1)return null;if(be(o))return ko(o)?f(zo,Object.assign({key:e.key},o.props)):null;const{labelField:i}=t,{key:n,level:s,isGroup:u}=e,m=Object.assign(Object.assign({},o),{title:o.title||o[i],extra:o.titleExtra||o.extra,key:n,internalKey:n,level:s,root:s===0,isGroup:u});return e.children?e.isGroup?f(Co,me(m,Io,{tmNode:e,tmNodes:e.children,key:n})):f(_e,me(m,$o,{key:n,rawNodes:o[t.childrenField],tmNodes:e.children,tmNode:e})):f(wo,me(m,So,{key:n,tmNode:e}))}const Ke=[p("&::before","background-color: var(--n-item-color-hover);"),C("arrow",`
 color: var(--n-arrow-color-hover);
 `),C("icon",`
 color: var(--n-item-icon-color-hover);
 `),_("menu-item-content-header",`
 color: var(--n-item-text-color-hover);
 `,[p("a",`
 color: var(--n-item-text-color-hover);
 `),C("extra",`
 color: var(--n-item-text-color-hover);
 `)])],Ve=[C("icon",`
 color: var(--n-item-icon-color-hover-horizontal);
 `),_("menu-item-content-header",`
 color: var(--n-item-text-color-hover-horizontal);
 `,[p("a",`
 color: var(--n-item-text-color-hover-horizontal);
 `),C("extra",`
 color: var(--n-item-text-color-hover-horizontal);
 `)])],No=p([_("menu",`
 background-color: var(--n-color);
 color: var(--n-item-text-color);
 overflow: hidden;
 transition: background-color .3s var(--n-bezier);
 box-sizing: border-box;
 font-size: var(--n-font-size);
 padding-bottom: 6px;
 `,[N("horizontal",`
 max-width: 100%;
 width: 100%;
 display: flex;
 overflow: hidden;
 padding-bottom: 0;
 `,[_("submenu","margin: 0;"),_("menu-item","margin: 0;"),_("menu-item-content",`
 padding: 0 20px;
 border-bottom: 2px solid #0000;
 `,[p("&::before","display: none;"),N("selected","border-bottom: 2px solid var(--n-border-color-horizontal)")]),_("menu-item-content",[N("selected",[C("icon","color: var(--n-item-icon-color-active-horizontal);"),_("menu-item-content-header",`
 color: var(--n-item-text-color-active-horizontal);
 `,[p("a","color: var(--n-item-text-color-active-horizontal);"),C("extra","color: var(--n-item-text-color-active-horizontal);")])]),N("child-active",`
 border-bottom: 2px solid var(--n-border-color-horizontal);
 `,[_("menu-item-content-header",`
 color: var(--n-item-text-color-child-active-horizontal);
 `,[p("a",`
 color: var(--n-item-text-color-child-active-horizontal);
 `),C("extra",`
 color: var(--n-item-text-color-child-active-horizontal);
 `)]),C("icon",`
 color: var(--n-item-icon-color-child-active-horizontal);
 `)]),ee("disabled",[ee("selected, child-active",[p("&:focus-within",Ve)]),N("selected",[U(null,[C("icon","color: var(--n-item-icon-color-active-hover-horizontal);"),_("menu-item-content-header",`
 color: var(--n-item-text-color-active-hover-horizontal);
 `,[p("a","color: var(--n-item-text-color-active-hover-horizontal);"),C("extra","color: var(--n-item-text-color-active-hover-horizontal);")])])]),N("child-active",[U(null,[C("icon","color: var(--n-item-icon-color-child-active-hover-horizontal);"),_("menu-item-content-header",`
 color: var(--n-item-text-color-child-active-hover-horizontal);
 `,[p("a","color: var(--n-item-text-color-child-active-hover-horizontal);"),C("extra","color: var(--n-item-text-color-child-active-hover-horizontal);")])])]),U("border-bottom: 2px solid var(--n-border-color-horizontal);",Ve)]),_("menu-item-content-header",[p("a","color: var(--n-item-text-color-horizontal);")])])]),ee("responsive",[_("menu-item-content-header",`
 overflow: hidden;
 text-overflow: ellipsis;
 `)]),N("collapsed",[_("menu-item-content",[N("selected",[p("&::before",`
 background-color: var(--n-item-color-active-collapsed) !important;
 `)]),_("menu-item-content-header","opacity: 0;"),C("arrow","opacity: 0;"),C("icon","color: var(--n-item-icon-color-collapsed);")])]),_("menu-item",`
 height: var(--n-item-height);
 margin-top: 6px;
 position: relative;
 `),_("menu-item-content",`
 box-sizing: border-box;
 line-height: 1.75;
 height: 100%;
 display: grid;
 grid-template-areas: "icon content arrow";
 grid-template-columns: auto 1fr auto;
 align-items: center;
 cursor: pointer;
 position: relative;
 padding-right: 18px;
 transition:
 background-color .3s var(--n-bezier),
 padding-left .3s var(--n-bezier),
 border-color .3s var(--n-bezier);
 `,[p("> *","z-index: 1;"),p("&::before",`
 z-index: auto;
 content: "";
 background-color: #0000;
 position: absolute;
 left: 8px;
 right: 8px;
 top: 0;
 bottom: 0;
 pointer-events: none;
 border-radius: var(--n-border-radius);
 transition: background-color .3s var(--n-bezier);
 `),N("disabled",`
 opacity: .45;
 cursor: not-allowed;
 `),N("collapsed",[C("arrow","transform: rotate(0);")]),N("selected",[p("&::before","background-color: var(--n-item-color-active);"),C("arrow","color: var(--n-arrow-color-active);"),C("icon","color: var(--n-item-icon-color-active);"),_("menu-item-content-header",`
 color: var(--n-item-text-color-active);
 `,[p("a","color: var(--n-item-text-color-active);"),C("extra","color: var(--n-item-text-color-active);")])]),N("child-active",[_("menu-item-content-header",`
 color: var(--n-item-text-color-child-active);
 `,[p("a",`
 color: var(--n-item-text-color-child-active);
 `),C("extra",`
 color: var(--n-item-text-color-child-active);
 `)]),C("arrow",`
 color: var(--n-arrow-color-child-active);
 `),C("icon",`
 color: var(--n-item-icon-color-child-active);
 `)]),ee("disabled",[ee("selected, child-active",[p("&:focus-within",Ke)]),N("selected",[U(null,[C("arrow","color: var(--n-arrow-color-active-hover);"),C("icon","color: var(--n-item-icon-color-active-hover);"),_("menu-item-content-header",`
 color: var(--n-item-text-color-active-hover);
 `,[p("a","color: var(--n-item-text-color-active-hover);"),C("extra","color: var(--n-item-text-color-active-hover);")])])]),N("child-active",[U(null,[C("arrow","color: var(--n-arrow-color-child-active-hover);"),C("icon","color: var(--n-item-icon-color-child-active-hover);"),_("menu-item-content-header",`
 color: var(--n-item-text-color-child-active-hover);
 `,[p("a","color: var(--n-item-text-color-child-active-hover);"),C("extra","color: var(--n-item-text-color-child-active-hover);")])])]),N("selected",[U(null,[p("&::before","background-color: var(--n-item-color-active-hover);")])]),U(null,Ke)]),C("icon",`
 grid-area: icon;
 color: var(--n-item-icon-color);
 transition:
 color .3s var(--n-bezier),
 font-size .3s var(--n-bezier),
 margin-right .3s var(--n-bezier);
 box-sizing: content-box;
 display: inline-flex;
 align-items: center;
 justify-content: center;
 `),C("arrow",`
 grid-area: arrow;
 font-size: 16px;
 color: var(--n-arrow-color);
 transform: rotate(180deg);
 opacity: 1;
 transition:
 color .3s var(--n-bezier),
 transform 0.2s var(--n-bezier),
 opacity 0.2s var(--n-bezier);
 `),_("menu-item-content-header",`
 grid-area: content;
 transition:
 color .3s var(--n-bezier),
 opacity .3s var(--n-bezier);
 opacity: 1;
 white-space: nowrap;
 color: var(--n-item-text-color);
 `,[p("a",`
 outline: none;
 text-decoration: none;
 transition: color .3s var(--n-bezier);
 color: var(--n-item-text-color);
 `,[p("&::before",`
 content: "";
 position: absolute;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 `)]),C("extra",`
 font-size: .93em;
 color: var(--n-group-text-color);
 transition: color .3s var(--n-bezier);
 `)])]),_("submenu",`
 cursor: pointer;
 position: relative;
 margin-top: 6px;
 `,[_("menu-item-content",`
 height: var(--n-item-height);
 `),_("submenu-children",`
 overflow: hidden;
 padding: 0;
 `,[Rt({duration:".2s"})])]),_("menu-item-group",[_("menu-item-group-title",`
 margin-top: 6px;
 color: var(--n-group-text-color);
 cursor: default;
 font-size: .93em;
 height: 36px;
 display: flex;
 align-items: center;
 transition:
 padding-left .3s var(--n-bezier),
 color .3s var(--n-bezier);
 `)])]),_("menu-tooltip",[p("a",`
 color: inherit;
 text-decoration: none;
 `)]),_("menu-divider",`
 transition: background-color .3s var(--n-bezier);
 background-color: var(--n-divider-color);
 height: 1px;
 margin: 6px 18px;
 `)]);function U(e,t){return[N("hover",e,t),p("&:hover",e,t)]}const Ro=Object.assign(Object.assign({},J.props),{options:{type:Array,default:()=>[]},collapsed:{type:Boolean,default:void 0},collapsedWidth:{type:Number,default:48},iconSize:{type:Number,default:20},collapsedIconSize:{type:Number,default:24},rootIndent:Number,indent:{type:Number,default:32},labelField:{type:String,default:"label"},keyField:{type:String,default:"key"},childrenField:{type:String,default:"children"},disabledField:{type:String,default:"disabled"},defaultExpandAll:Boolean,defaultExpandedKeys:Array,expandedKeys:Array,value:[String,Number],defaultValue:{type:[String,Number],default:null},mode:{type:String,default:"vertical"},watchProps:{type:Array,default:void 0},disabled:Boolean,show:{type:Boolean,default:!0},inverted:Boolean,"onUpdate:expandedKeys":[Function,Array],onUpdateExpandedKeys:[Function,Array],onUpdateValue:[Function,Array],"onUpdate:value":[Function,Array],expandIcon:Function,renderIcon:Function,renderLabel:Function,renderExtra:Function,dropdownProps:Object,accordion:Boolean,nodeProps:Function,dropdownPlacement:{type:String,default:"bottom"},responsive:Boolean,items:Array,onOpenNamesChange:[Function,Array],onSelect:[Function,Array],onExpandedNamesChange:[Function,Array],expandedNames:Array,defaultExpandedNames:Array}),Po=E({name:"Menu",props:Ro,setup(e){const{mergedClsPrefixRef:t,inlineThemeDisabled:o}=xe(e),a=J("Menu","-menu",No,Pt,e,t),i=V(eo,null),n=w(()=>{var g;const{collapsed:I}=e;if(I!==void 0)return I;if(i){const{collapseModeRef:r,collapsedRef:y}=i;if(r.value==="width")return(g=y.value)!==null&&g!==void 0?g:!1}return!1}),s=w(()=>{const{keyField:g,childrenField:I,disabledField:r}=e;return ve(e.items||e.options,{getIgnored(y){return be(y)},getChildren(y){return y[I]},getDisabled(y){return y[r]},getKey(y){var R;return(R=y[g])!==null&&R!==void 0?R:y.name}})}),u=w(()=>new Set(s.value.treeNodes.map(g=>g.key))),{watchProps:m}=e,x=L(null);m?.includes("defaultValue")?fe(()=>{x.value=e.defaultValue}):x.value=e.defaultValue;const d=W(e,"value"),v=Oe(d,x),c=L([]),P=()=>{c.value=e.defaultExpandAll?s.value.getNonLeafKeys():e.defaultExpandedNames||e.defaultExpandedKeys||s.value.getPath(v.value,{includeSelf:!1}).keyPath};m?.includes("defaultExpandedKeys")?fe(P):P();const h=ro(e,["expandedNames","expandedKeys"]),z=Oe(h,c),$=w(()=>s.value.treeNodes),T=w(()=>s.value.getPath(v.value).keyPath);Z(oe,{props:e,mergedCollapsedRef:n,mergedThemeRef:a,mergedValueRef:v,mergedExpandedKeysRef:z,activePathRef:T,mergedClsPrefixRef:t,isHorizontalRef:w(()=>e.mode==="horizontal"),invertedRef:W(e,"inverted"),doSelect:K,toggleExpand:G});function K(g,I){const{"onUpdate:value":r,onUpdateValue:y,onSelect:R}=e;y&&D(y,g,I),r&&D(r,g,I),R&&D(R,g,I),x.value=g}function j(g){const{"onUpdate:expandedKeys":I,onUpdateExpandedKeys:r,onExpandedNamesChange:y,onOpenNamesChange:R}=e;I&&D(I,g),r&&D(r,g),y&&D(y,g),R&&D(R,g),c.value=g}function G(g){const I=Array.from(z.value),r=I.findIndex(y=>y===g);if(~r)I.splice(r,1);else{if(e.accordion&&u.value.has(g)){const y=I.findIndex(R=>u.value.has(R));y>-1&&I.splice(y,1)}I.push(g)}j(I)}const de=g=>{const I=s.value.getPath(g??v.value,{includeSelf:!1}).keyPath;if(!I.length)return;const r=Array.from(z.value),y=new Set([...r,...I]);e.accordion&&u.value.forEach(R=>{y.has(R)&&!I.includes(R)&&y.delete(R)}),j(Array.from(y))},ne=w(()=>{const{inverted:g}=e,{common:{cubicBezierEaseInOut:I},self:r}=a.value,{borderRadius:y,borderColorHorizontal:R,fontSize:mt,itemHeight:vt,dividerColor:ht}=r,l={"--n-divider-color":ht,"--n-bezier":I,"--n-font-size":mt,"--n-border-color-horizontal":R,"--n-border-radius":y,"--n-item-height":vt};return g?(l["--n-group-text-color"]=r.groupTextColorInverted,l["--n-color"]=r.colorInverted,l["--n-item-text-color"]=r.itemTextColorInverted,l["--n-item-text-color-hover"]=r.itemTextColorHoverInverted,l["--n-item-text-color-active"]=r.itemTextColorActiveInverted,l["--n-item-text-color-child-active"]=r.itemTextColorChildActiveInverted,l["--n-item-text-color-child-active-hover"]=r.itemTextColorChildActiveInverted,l["--n-item-text-color-active-hover"]=r.itemTextColorActiveHoverInverted,l["--n-item-icon-color"]=r.itemIconColorInverted,l["--n-item-icon-color-hover"]=r.itemIconColorHoverInverted,l["--n-item-icon-color-active"]=r.itemIconColorActiveInverted,l["--n-item-icon-color-active-hover"]=r.itemIconColorActiveHoverInverted,l["--n-item-icon-color-child-active"]=r.itemIconColorChildActiveInverted,l["--n-item-icon-color-child-active-hover"]=r.itemIconColorChildActiveHoverInverted,l["--n-item-icon-color-collapsed"]=r.itemIconColorCollapsedInverted,l["--n-item-text-color-horizontal"]=r.itemTextColorHorizontalInverted,l["--n-item-text-color-hover-horizontal"]=r.itemTextColorHoverHorizontalInverted,l["--n-item-text-color-active-horizontal"]=r.itemTextColorActiveHorizontalInverted,l["--n-item-text-color-child-active-horizontal"]=r.itemTextColorChildActiveHorizontalInverted,l["--n-item-text-color-child-active-hover-horizontal"]=r.itemTextColorChildActiveHoverHorizontalInverted,l["--n-item-text-color-active-hover-horizontal"]=r.itemTextColorActiveHoverHorizontalInverted,l["--n-item-icon-color-horizontal"]=r.itemIconColorHorizontalInverted,l["--n-item-icon-color-hover-horizontal"]=r.itemIconColorHoverHorizontalInverted,l["--n-item-icon-color-active-horizontal"]=r.itemIconColorActiveHorizontalInverted,l["--n-item-icon-color-active-hover-horizontal"]=r.itemIconColorActiveHoverHorizontalInverted,l["--n-item-icon-color-child-active-horizontal"]=r.itemIconColorChildActiveHorizontalInverted,l["--n-item-icon-color-child-active-hover-horizontal"]=r.itemIconColorChildActiveHoverHorizontalInverted,l["--n-arrow-color"]=r.arrowColorInverted,l["--n-arrow-color-hover"]=r.arrowColorHoverInverted,l["--n-arrow-color-active"]=r.arrowColorActiveInverted,l["--n-arrow-color-active-hover"]=r.arrowColorActiveHoverInverted,l["--n-arrow-color-child-active"]=r.arrowColorChildActiveInverted,l["--n-arrow-color-child-active-hover"]=r.arrowColorChildActiveHoverInverted,l["--n-item-color-hover"]=r.itemColorHoverInverted,l["--n-item-color-active"]=r.itemColorActiveInverted,l["--n-item-color-active-hover"]=r.itemColorActiveHoverInverted,l["--n-item-color-active-collapsed"]=r.itemColorActiveCollapsedInverted):(l["--n-group-text-color"]=r.groupTextColor,l["--n-color"]=r.color,l["--n-item-text-color"]=r.itemTextColor,l["--n-item-text-color-hover"]=r.itemTextColorHover,l["--n-item-text-color-active"]=r.itemTextColorActive,l["--n-item-text-color-child-active"]=r.itemTextColorChildActive,l["--n-item-text-color-child-active-hover"]=r.itemTextColorChildActiveHover,l["--n-item-text-color-active-hover"]=r.itemTextColorActiveHover,l["--n-item-icon-color"]=r.itemIconColor,l["--n-item-icon-color-hover"]=r.itemIconColorHover,l["--n-item-icon-color-active"]=r.itemIconColorActive,l["--n-item-icon-color-active-hover"]=r.itemIconColorActiveHover,l["--n-item-icon-color-child-active"]=r.itemIconColorChildActive,l["--n-item-icon-color-child-active-hover"]=r.itemIconColorChildActiveHover,l["--n-item-icon-color-collapsed"]=r.itemIconColorCollapsed,l["--n-item-text-color-horizontal"]=r.itemTextColorHorizontal,l["--n-item-text-color-hover-horizontal"]=r.itemTextColorHoverHorizontal,l["--n-item-text-color-active-horizontal"]=r.itemTextColorActiveHorizontal,l["--n-item-text-color-child-active-horizontal"]=r.itemTextColorChildActiveHorizontal,l["--n-item-text-color-child-active-hover-horizontal"]=r.itemTextColorChildActiveHoverHorizontal,l["--n-item-text-color-active-hover-horizontal"]=r.itemTextColorActiveHoverHorizontal,l["--n-item-icon-color-horizontal"]=r.itemIconColorHorizontal,l["--n-item-icon-color-hover-horizontal"]=r.itemIconColorHoverHorizontal,l["--n-item-icon-color-active-horizontal"]=r.itemIconColorActiveHorizontal,l["--n-item-icon-color-active-hover-horizontal"]=r.itemIconColorActiveHoverHorizontal,l["--n-item-icon-color-child-active-horizontal"]=r.itemIconColorChildActiveHorizontal,l["--n-item-icon-color-child-active-hover-horizontal"]=r.itemIconColorChildActiveHoverHorizontal,l["--n-arrow-color"]=r.arrowColor,l["--n-arrow-color-hover"]=r.arrowColorHover,l["--n-arrow-color-active"]=r.arrowColorActive,l["--n-arrow-color-active-hover"]=r.arrowColorActiveHover,l["--n-arrow-color-child-active"]=r.arrowColorChildActive,l["--n-arrow-color-child-active-hover"]=r.arrowColorChildActiveHover,l["--n-item-color-hover"]=r.itemColorHover,l["--n-item-color-active"]=r.itemColorActive,l["--n-item-color-active-hover"]=r.itemColorActiveHover,l["--n-item-color-active-collapsed"]=r.itemColorActiveCollapsed),l}),O=o?Ce("menu",w(()=>e.inverted?"a":"b"),ne,e):void 0,ue=At(),Pe=L(null),rt=L(null);let Ae=!0;const He=()=>{var g;Ae?Ae=!1:(g=Pe.value)===null||g===void 0||g.sync({showAllItemsBeforeCalculate:!0})};function it(){return document.getElementById(ue)}const re=L(-1);function at(g){re.value=e.options.length-g}function lt(g){g||(re.value=-1)}const ct=w(()=>{const g=re.value;return{children:g===-1?[]:e.options.slice(g)}}),st=w(()=>{const{childrenField:g,disabledField:I,keyField:r}=e;return ve([ct.value],{getIgnored(y){return be(y)},getChildren(y){return y[g]},getDisabled(y){return y[I]},getKey(y){var R;return(R=y[r])!==null&&R!==void 0?R:y.name}})}),dt=w(()=>ve([{}]).treeNodes[0]);function ut(){var g;if(re.value===-1)return f(_e,{root:!0,level:0,key:"__ellpisisGroupPlaceholder__",internalKey:"__ellpisisGroupPlaceholder__",title:"···",tmNode:dt.value,domId:ue,isEllipsisPlaceholder:!0});const I=st.value.treeNodes[0],r=T.value,y=!!(!((g=I.children)===null||g===void 0)&&g.some(R=>r.includes(R.key)));return f(_e,{level:0,root:!0,key:"__ellpisisGroup__",internalKey:"__ellpisisGroup__",title:"···",virtualChildActive:y,tmNode:I,domId:ue,rawNodes:I.rawNode.children||[],tmNodes:I.children||[],isEllipsisPlaceholder:!0})}return{mergedClsPrefix:t,controlledExpandedKeys:h,uncontrolledExpanededKeys:c,mergedExpandedKeys:z,uncontrolledValue:x,mergedValue:v,activePath:T,tmNodes:$,mergedTheme:a,mergedCollapsed:n,cssVars:o?void 0:ne,themeClass:O?.themeClass,overflowRef:Pe,counterRef:rt,updateCounter:()=>{},onResize:He,onUpdateOverflow:lt,onUpdateCount:at,renderCounter:ut,getCounter:it,onRender:O?.onRender,showOption:de,deriveResponsiveState:He}},render(){const{mergedClsPrefix:e,mode:t,themeClass:o,onRender:a}=this;a?.();const i=()=>this.tmNodes.map(m=>Re(m,this.$props)),s=t==="horizontal"&&this.responsive,u=()=>f("div",{role:t==="horizontal"?"menubar":"menu",class:[`${e}-menu`,o,`${e}-menu--${t}`,s&&`${e}-menu--responsive`,this.mergedCollapsed&&`${e}-menu--collapsed`],style:this.cssVars},s?f(Wt,{ref:"overflowRef",onUpdateOverflow:this.onUpdateOverflow,getCounter:this.getCounter,onUpdateCount:this.onUpdateCount,updateCounter:this.updateCounter,style:{width:"100%",display:"flex",overflow:"hidden"}},{default:i,counter:this.renderCounter}):i());return s?f(Ht,{onResize:this.onResize},{default:u}):u()}}),Ao={__name:"BreadCrumb",setup(e){const t=ze(),o=qe();function a(n){n!==o.path&&t.push(n)}function i(n){return n?.customIcon?Ye(n.customIcon,{size:18}):n?.icon?ce(n.icon,{size:18}):null}return(n,s)=>{const u=yo,m=_o;return b(),H(m,null,{default:M(()=>[(b(!0),A(q,null,pe(k(o).matched.filter(x=>!!x.meta?.title),x=>(b(),H(u,{key:x.path,onClick:d=>a(x.path)},{default:M(()=>[(b(),H(Ge(i(x.meta)))),te(" "+F(x.meta.title),1)]),_:2},1032,["onClick"]))),128))]),_:1})}}},Ho={class:"inline-block",viewBox:"0 0 24 24",width:"1em",height:"1em"},Lo=S("path",{fill:"currentColor",d:"M11 13h10v-2H11m0-2h10V7H11M3 3v2h18V3M3 21h18v-2H3m0-7l4 4V8m4 9h10v-2H11z"},null,-1),Mo=[Lo];function Bo(e,t){return b(),A("svg",Ho,[...Mo])}const To={name:"mdi-format-indent-decrease",render:Bo},Eo={class:"inline-block",viewBox:"0 0 24 24",width:"1em",height:"1em"},Oo=S("path",{fill:"currentColor",d:"M11 13h10v-2H11m0-2h10V7H11M3 3v2h18V3M11 17h10v-2H11M3 8v8l4-4m-4 9h18v-2H3z"},null,-1),Fo=[Oo];function Ko(e,t){return b(),A("svg",Eo,[...Fo])}const Vo={name:"mdi-format-indent-increase",render:Ko},jo={__name:"MenuCollapse",setup(e){const t=Q();return(o,a)=>{const i=Vo,n=To,s=Ie;return b(),H(s,{size:"20","cursor-pointer":"",onClick:k(t).switchCollapsed},{default:M(()=>[k(t).collapsed?(b(),H(i,{key:0})):(b(),H(n,{key:1}))]),_:1},8,["onClick"])}}},Do={class:"inline-block",viewBox:"0 0 1024 1024",width:"1em",height:"1em"},Uo=S("path",{fill:"currentColor",d:"m290 236.4l43.9-43.9a8.01 8.01 0 0 0-4.7-13.6L169 160c-5.1-.6-9.5 3.7-8.9 8.9L179 329.1c.8 6.6 8.9 9.4 13.6 4.7l43.7-43.7L370 423.7c3.1 3.1 8.2 3.1 11.3 0l42.4-42.3c3.1-3.1 3.1-8.2 0-11.3zm352.7 187.3c3.1 3.1 8.2 3.1 11.3 0l133.7-133.6l43.7 43.7a8.01 8.01 0 0 0 13.6-4.7L863.9 169c.6-5.1-3.7-9.5-8.9-8.9L694.8 179c-6.6.8-9.4 8.9-4.7 13.6l43.9 43.9L600.3 370a8.03 8.03 0 0 0 0 11.3zM845 694.9c-.8-6.6-8.9-9.4-13.6-4.7l-43.7 43.7L654 600.3a8.03 8.03 0 0 0-11.3 0l-42.4 42.3a8.03 8.03 0 0 0 0 11.3L734 787.6l-43.9 43.9a8.01 8.01 0 0 0 4.7 13.6L855 864c5.1.6 9.5-3.7 8.9-8.9zm-463.7-94.6a8.03 8.03 0 0 0-11.3 0L236.3 733.9l-43.7-43.7a8.01 8.01 0 0 0-13.6 4.7L160.1 855c-.6 5.1 3.7 9.5 8.9 8.9L329.2 845c6.6-.8 9.4-8.9 4.7-13.6L290 787.6L423.7 654c3.1-3.1 3.1-8.2 0-11.3z"},null,-1),qo=[Uo];function Go(e,t){return b(),A("svg",Do,[...qo])}const Yo={name:"ant-design-fullscreen-outlined",render:Go},Xo={class:"inline-block",viewBox:"0 0 1024 1024",width:"1em",height:"1em"},Wo=S("path",{fill:"currentColor",d:"M391 240.9c-.8-6.6-8.9-9.4-13.6-4.7l-43.7 43.7L200 146.3a8.03 8.03 0 0 0-11.3 0l-42.4 42.3a8.03 8.03 0 0 0 0 11.3L280 333.6l-43.9 43.9a8.01 8.01 0 0 0 4.7 13.6L401 410c5.1.6 9.5-3.7 8.9-8.9zm10.1 373.2L240.8 633c-6.6.8-9.4 8.9-4.7 13.6l43.9 43.9L146.3 824a8.03 8.03 0 0 0 0 11.3l42.4 42.3c3.1 3.1 8.2 3.1 11.3 0L333.7 744l43.7 43.7A8.01 8.01 0 0 0 391 783l18.9-160.1c.6-5.1-3.7-9.4-8.8-8.8m221.8-204.2L783.2 391c6.6-.8 9.4-8.9 4.7-13.6L744 333.6L877.7 200c3.1-3.1 3.1-8.2 0-11.3l-42.4-42.3a8.03 8.03 0 0 0-11.3 0L690.3 279.9l-43.7-43.7a8.01 8.01 0 0 0-13.6 4.7L614.1 401c-.6 5.2 3.7 9.5 8.8 8.9M744 690.4l43.9-43.9a8.01 8.01 0 0 0-4.7-13.6L623 614c-5.1-.6-9.5 3.7-8.9 8.9L633 783.1c.8 6.6 8.9 9.4 13.6 4.7l43.7-43.7L824 877.7c3.1 3.1 8.2 3.1 11.3 0l42.4-42.3c3.1-3.1 3.1-8.2 0-11.3z"},null,-1),Zo=[Wo];function Jo(e,t){return b(),A("svg",Xo,[...Zo])}const Qo={name:"ant-design-fullscreen-exit-outlined",render:Jo},en={__name:"FullScreen",setup(e){const t=Q(),{isFullscreen:o,toggle:a}=Lt();return(i,n)=>{const s=Qo,u=Yo,m=Ie;return k(t).fullScreen?(b(),H(m,{key:0,mr20:"",size:"18",style:{cursor:"pointer"},onClick:k(a)},{default:M(()=>[k(o)?(b(),H(s,{key:0})):(b(),H(u,{key:1}))]),_:1},8,["onClick"])):ge("",!0)}}},tn={flex:"","cursor-pointer":"","items-center":""},on={__name:"UserAvatar",setup(e){const{t}=Mt(),o=ze(),a=Bt(),i=[{label:t("header.label_profile"),key:"profile",icon:ce("mdi-account-arrow-right-outline",{size:"14px"})},{label:t("header.label_logout"),key:"logout",icon:ce("mdi:exit-to-app",{size:"14px"})}];function n(s){s==="profile"?o.push("/profile"):s==="logout"&&$dialog.confirm({title:t("header.label_logout_dialog_title"),type:"warning",content:t("header.text_logout_confirm"),confirm(){a.logout(),$message.success("您已安全退出登录")}})}return(s,u)=>{const m=We;return b(),H(m,{options:i,onSelect:n},{default:M(()=>[S("div",tn,[S("span",null,F(k(a).name),1)])]),_:1})}}},nn={class:"inline-block",viewBox:"0 0 24 24",width:"1em",height:"1em"},rn=S("path",{fill:"currentColor",d:"m3.55 19.09l1.41 1.41l1.8-1.79l-1.42-1.42M12 6c-3.31 0-6 2.69-6 6s2.69 6 6 6s6-2.69 6-6c0-3.32-2.69-6-6-6m8 7h3v-2h-3m-2.76 7.71l1.8 1.79l1.41-1.41l-1.79-1.8M20.45 5l-1.41-1.4l-1.8 1.79l1.42 1.42M13 1h-2v3h2M6.76 5.39L4.96 3.6L3.55 5l1.79 1.81zM1 13h3v-2H1m12 9h-2v3h2"},null,-1),an=[rn];function ln(e,t){return b(),A("svg",nn,[...an])}const cn={name:"mdi-white-balance-sunny",render:ln},sn={class:"inline-block",viewBox:"0 0 24 24",width:"1em",height:"1em"},dn=S("path",{fill:"currentColor",d:"M2 12a10 10 0 0 0 13 9.54a10 10 0 0 1 0-19.08A10 10 0 0 0 2 12"},null,-1),un=[dn];function mn(e,t){return b(),A("svg",sn,[...un])}const vn={name:"mdi-moon-waning-crescent",render:mn},hn={__name:"ThemeMode",setup(e){const t=Q(),o=Tt(),a=()=>{t.toggleDark(),Et(o)()};return(i,n)=>{const s=vn,u=cn,m=Ie;return b(),H(m,{"mr-20":"","cursor-pointer":"",size:"18",onClick:a},{default:M(()=>[k(o)?(b(),H(s,{key:0})):(b(),H(u,{key:1}))]),_:1})}}},fn={class:"inline-block",viewBox:"0 0 24 24",width:"1em",height:"1em"},pn=S("path",{fill:"currentColor",d:"M10 21h4c0 1.1-.9 2-2 2s-2-.9-2-2m11-2v1H3v-1l2-2v-6c0-3.1 2-5.8 5-6.7V4c0-1.1.9-2 2-2s2 .9 2 2v.3c3 .9 5 3.6 5 6.7v6zm-4-8c0-2.8-2.2-5-5-5s-5 2.2-5 5v7h10z"},null,-1),gn=[pn];function _n(e,t){return b(),A("svg",fn,[...gn])}const bn={name:"mdi-bell-outline",render:_n};const nt=e=>(Ft("data-v-a39f80fa"),e=e(),Kt(),e),xn={class:"notice-panel"},yn={class:"notice-head"},Cn=nt(()=>S("strong",null,"消息通知",-1)),wn={key:0,class:"notice-loading"},zn={key:1,class:"notice-empty"},In={key:2,class:"notice-list"},Sn={class:"notice-item-head"},$n={class:"notice-title"},kn=["innerHTML"],Nn={class:"notice-preview-shell"},Rn={class:"notice-preview-list"},Pn=nt(()=>S("div",{class:"notice-preview-head"},"最近10条",-1)),An=["onClick"],Hn={class:"preview-item-title"},Ln={class:"preview-item-time"},Mn={key:0,class:"notice-preview-detail"},Bn={class:"preview-detail-head"},Tn={class:"preview-detail-time"},En={class:"preview-detail-actions"},On=["innerHTML"],Fn={key:1,class:"notice-empty"},Kn={__name:"NoticeBell",setup(e){const t=L(0),o=L([]),a=L(!1),i=L(!1),n=L(null);async function s(){const v=await ae.getNoticeUnreadCount();t.value=Number(v?.data?.unread_count||0)}async function u(){try{a.value=!0;const v=await ae.getNoticeInbox({page:1,page_size:10});o.value=Array.isArray(v?.data)?v.data:[]}finally{a.value=!1}}function m(v){n.value=v}async function x(v){await ae.readNotice({notice_id:v}),await Promise.all([s(),u()]),n.value&&n.value.notice_id===v&&(n.value.is_read=!0)}async function d(){await ae.readAllNotice(),await Promise.all([s(),u()]),n.value&&(n.value.is_read=!0)}return ye(async()=>{if(await Promise.all([s(),u()]),t.value>0&&o.value.length){const v=o.value.find(c=>!c.is_read);n.value=v||o.value[0],i.value=!0}}),(v,c)=>{const P=bn;return b(),A(q,null,[B(k(Zt),{trigger:"click",placement:"bottom-end",width:420},{trigger:M(()=>[B(k(fo),{value:t.value,max:99,show:t.value>0},{default:M(()=>[B(k(ie),{quaternary:"",circle:""},{icon:M(()=>[B(P)]),_:1})]),_:1},8,["value","show"])]),default:M(()=>[S("div",xn,[S("div",yn,[Cn,B(k(ie),{text:"",size:"small",onClick:d},{default:M(()=>[te("全部已读")]),_:1})]),a.value?(b(),A("div",wn,"加载中...")):o.value.length?(b(),A("div",In,[(b(!0),A(q,null,pe(o.value,h=>(b(),A("div",{key:h.notice_id,class:Be(["notice-item",{unread:!h.is_read}])},[S("div",Sn,[S("span",$n,F(h.title||"系统通知"),1),h.is_read?ge("",!0):(b(),H(k(ie),{key:0,text:"",size:"tiny",onClick:z=>x(h.notice_id)},{default:M(()=>[te("已读")]),_:2},1032,["onClick"]))]),S("div",{class:"notice-content",innerHTML:k(Ee)(h.content_html||"")},null,8,kn)],2))),128))])):(b(),A("div",zn,"暂无通知"))])]),_:1}),B(k(Ot),{show:i.value,"onUpdate:show":c[1]||(c[1]=h=>i.value=h),preset:"card",title:"最新通知",style:{width:"840px"},"mask-closable":!0},{default:M(()=>[S("div",Nn,[S("div",Rn,[Pn,(b(!0),A(q,null,pe(o.value,h=>(b(),A("div",{key:`preview-${h.notice_id}`,class:Be(["notice-preview-item",{active:n.value?.notice_id===h.notice_id,unread:!h.is_read}]),onClick:z=>m(h)},[S("div",Hn,F(h.title||"系统通知"),1),S("div",Ln,F(h.created_at||"-"),1)],10,An))),128))]),n.value?(b(),A("div",Mn,[S("div",Bn,[S("div",null,[S("h3",null,F(n.value.title||"系统通知"),1),S("div",Tn,F(n.value.created_at||"-"),1)]),S("div",En,[B(k(Jt),{type:n.value.is_read?"default":"warning"},{default:M(()=>[te(F(n.value.is_read?"已读":"未读"),1)]),_:1},8,["type"]),n.value.is_read?ge("",!0):(b(),H(k(ie),{key:0,size:"small",type:"primary",ghost:"",onClick:c[0]||(c[0]=h=>x(n.value.notice_id))},{default:M(()=>[te("标记已读")]),_:1}))])]),S("div",{class:"preview-detail-content",innerHTML:k(Ee)(n.value.content_html||"")},null,8,On)])):(b(),A("div",Fn,"暂无通知"))])]),_:1},8,["show"])],64)}}},Vn=Ze(Kn,[["__scopeId","data-v-a39f80fa"]]),jn={flex:"","items-center":""},Dn={"ml-auto":"",flex:"","items-center":""},Un={__name:"index",setup(e){return(t,o)=>(b(),A(q,null,[S("div",jn,[B(jo),B(Ao,{"ml-15":"",hidden:"","sm:block":""})]),S("div",Dn,[B(hn),B(Vn),B(en),B(on)])],64))}},qn=["src"],Gn={__name:"SideLogo",setup(e){const t="安得和众用户服务中心",o=Q();return(a,i)=>{const n=Qt,s=Xe("router-link");return b(),H(s,{"h-60":"","f-c-c":"",to:"/"},{default:M(()=>[k(o).siteLogo?(b(),A("img",{key:0,src:k(o).siteLogo,alt:"logo",style:{height:"36px",width:"36px"}},null,8,qn)):(b(),H(n,{key:1,"text-36":"","color-primary":""})),Vt(S("h2",{"ml-2":"","mr-8":"","max-w-220":"","flex-shrink-0":"","text-14":"","font-bold":"","color-primary":"","whitespace-nowrap":"","overflow-hidden":"","text-ellipsis":""},F(k(o).siteTitle||k(t)),513),[[jt,!k(o).collapsed]])]),_:1})}}};const Yn={__name:"SideMenu",setup(e){const t=ze(),o=qe(),a=Dt();Q();const i=w(()=>o.meta?.activeMenu||o.name),n=w(()=>a.menus.map(d=>u(d)).sort((d,v)=>d.order-v.order));function s(d,v){return Te(v)?v:"/"+[d,v].filter(c=>!!c&&c!=="/").map(c=>c.replace(/(^\/)|(\/$)/g,"")).join("/")}function u(d,v=""){let c={label:d.meta&&d.meta.title||d.name,key:d.name,path:s(v,d.path),icon:m(d.meta),order:d.meta?.order||0};const P=d.children?d.children.filter(h=>h.name&&!h.isHidden):[];if(!P.length)return c;if(P.length===1){const h=P[0];c={...c,label:h.meta?.title||h.name,key:h.name,path:s(c.path,h.path),icon:m(h.meta)};const z=h.children?h.children.filter($=>$.name&&!$.isHidden):[];z.length===1?c=u(z[0],c.path):z.length>1&&(c.children=z.map($=>u($,c.path)).sort(($,T)=>$.order-T.order))}else c.children=P.map(h=>u(h,c.path)).sort((h,z)=>h.order-z.order),d.redirect&&(c.path=d.redirect);return c}function m(d){return d?.customIcon?Ye(d.customIcon,{size:18}):d?.icon?ce(d.icon,{size:18}):null}function x(d,v){if(v?.path)if(Te(v.path))window.open(v.path);else{if(v.path===o.path)return;t.push(v.path).catch(c=>{console.warn("[SideMenu] router.push failed",c)})}}return(d,v)=>{const c=Po;return b(),H(c,{ref:"menu",class:"side-menu",accordion:"",indent:18,"collapsed-icon-size":22,"collapsed-width":64,options:k(n),value:k(i),"onUpdate:value":x},null,8,["options","value"])}}},Xn={__name:"index",setup(e){return(t,o)=>(b(),A(q,null,[B(Gn),B(Yn)],64))}},Wn={};function Zn(e,t){const o=Xe("router-view");return b(),H(o,null,{default:M(({Component:a,route:i})=>[(b(),H(Ge(a),{key:i.fullPath}))]),_:1})}const Jn=Ze(Wn,[["render",Zn]]),Qn={"flex-col":"","flex-1":"","overflow-hidden":""},er={"flex-1":"","overflow-hidden":"","bg-hex-f5f6fb":"","dark:bg-hex-101014":""},hr={__name:"index",setup(e){const t=Q(),a=Ut(qt({xl:1600,lg:1199,md:991,sm:666,xs:575})),i=a.smaller("sm"),n=a.between("sm","md"),s=a.greater("md");return fe(()=>{i.value&&(t.setCollapsed(!0),t.setFullScreen(!1)),n.value&&(t.setCollapsed(!0),t.setFullScreen(!1)),s.value&&(t.setCollapsed(!1),t.setFullScreen(!0))}),(u,m)=>{const x=to,d=oo;return b(),H(d,{"has-sider":"","wh-full":""},{default:M(()=>[B(x,{bordered:"","collapse-mode":"width","collapsed-width":64,width:220,"native-scrollbar":!1,collapsed:k(t).collapsed},{default:M(()=>[B(Xn)]),_:1},8,["collapsed"]),S("article",Qn,[S("header",{class:"flex items-center border-b bg-white px-15 bc-eee",dark:"bg-dark border-0",style:Gt(`height: ${k(Yt).height}px`)},[B(Un)],4),S("section",er,[B(Jn)])])]),_:1})}}};export{hr as default};
