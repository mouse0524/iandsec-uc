var H=(t,o,m)=>new Promise((_,c)=>{var g=p=>{try{k(m.next(p))}catch(C){c(C)}},w=p=>{try{k(m.throw(p))}catch(C){c(C)}},k=p=>p.done?_(p.value):Promise.resolve(p.value).then(g,w);k((m=m.apply(t,o)).next())});import{_ as ke}from"./CrudModal-9297c5ab.js";import{F as ye,j as we,d3 as xe,e as f,g as R,a as A,i as x,d as me,l as ue,m as he,C as ze,h as z,D as Ce,G as Se,aY as $e,c as j,s as L,v as Te,bC as oe,z as se,r as P,w as je,ah as W,ar as Ie,Y as d,$ as h,ad as T,_ as $,a5 as e,a4 as r,a1 as y,a3 as q,I as U,a0 as te,a8 as K,Z as O,ae,af as Be,ag as Me,ai as Re,aj as Ae}from"./index-3d12f408.js";import{i as ce,s as ie}from"./sanitize-77706078.js";import{f as Le,_ as Pe}from"./_plugin-vue_export-helper-f253986a.js";import{_ as ne}from"./Spin-5d692690.js";import{_ as le}from"./Empty-6ae419b1.js";import{N as Ue}from"./Tag-90f170e9.js";let re=!1;function Oe(){if(ye&&window.CSS&&!re&&(re=!0,"registerProperty"in(window==null?void 0:window.CSS)))try{CSS.registerProperty({name:"--n-color-start",syntax:"<color>",inherits:!1,initialValue:"#0000"}),CSS.registerProperty({name:"--n-color-end",syntax:"<color>",inherits:!1,initialValue:"#0000"})}catch(t){}}function De(t){const{textColor3:o,infoColor:m,errorColor:_,successColor:c,warningColor:g,textColor1:w,textColor2:k,railColor:p,fontWeightStrong:C,fontSize:B}=t;return Object.assign(Object.assign({},xe),{contentFontSize:B,titleFontWeight:C,circleBorder:`2px solid ${o}`,circleBorderInfo:`2px solid ${m}`,circleBorderError:`2px solid ${_}`,circleBorderSuccess:`2px solid ${c}`,circleBorderWarning:`2px solid ${g}`,iconColor:o,iconColorInfo:m,iconColorError:_,iconColorSuccess:c,iconColorWarning:g,titleTextColor:w,contentTextColor:k,metaTextColor:o,lineColor:p})}const Ne={name:"Timeline",common:we,self:De},Fe=Ne,de=1.25,Ve=f("timeline",`
 position: relative;
 width: 100%;
 display: flex;
 flex-direction: column;
 line-height: ${de};
`,[R("horizontal",`
 flex-direction: row;
 `,[A(">",[f("timeline-item",`
 flex-shrink: 0;
 padding-right: 40px;
 `,[R("dashed-line-type",[A(">",[f("timeline-item-timeline",[x("line",`
 background-image: linear-gradient(90deg, var(--n-color-start), var(--n-color-start) 50%, transparent 50%, transparent 100%);
 background-size: 10px 1px;
 `)])])]),A(">",[f("timeline-item-content",`
 margin-top: calc(var(--n-icon-size) + 12px);
 `,[A(">",[x("meta",`
 margin-top: 6px;
 margin-bottom: unset;
 `)])]),f("timeline-item-timeline",`
 width: 100%;
 height: calc(var(--n-icon-size) + 12px);
 `,[x("line",`
 left: var(--n-icon-size);
 top: calc(var(--n-icon-size) / 2 - 1px);
 right: 0px;
 width: unset;
 height: 2px;
 `)])])])])]),R("right-placement",[f("timeline-item",[f("timeline-item-content",`
 text-align: right;
 margin-right: calc(var(--n-icon-size) + 12px);
 `),f("timeline-item-timeline",`
 width: var(--n-icon-size);
 right: 0;
 `)])]),R("left-placement",[f("timeline-item",[f("timeline-item-content",`
 margin-left: calc(var(--n-icon-size) + 12px);
 `),f("timeline-item-timeline",`
 left: 0;
 `)])]),f("timeline-item",`
 position: relative;
 `,[A("&:last-child",[f("timeline-item-timeline",[x("line",`
 display: none;
 `)]),f("timeline-item-content",[x("meta",`
 margin-bottom: 0;
 `)])]),f("timeline-item-content",[x("title",`
 margin: var(--n-title-margin);
 font-size: var(--n-title-font-size);
 transition: color .3s var(--n-bezier);
 font-weight: var(--n-title-font-weight);
 color: var(--n-title-text-color);
 `),x("content",`
 transition: color .3s var(--n-bezier);
 font-size: var(--n-content-font-size);
 color: var(--n-content-text-color);
 `),x("meta",`
 transition: color .3s var(--n-bezier);
 font-size: 12px;
 margin-top: 6px;
 margin-bottom: 20px;
 color: var(--n-meta-text-color);
 `)]),R("dashed-line-type",[f("timeline-item-timeline",[x("line",`
 --n-color-start: var(--n-line-color);
 transition: --n-color-start .3s var(--n-bezier);
 background-color: transparent;
 background-image: linear-gradient(180deg, var(--n-color-start), var(--n-color-start) 50%, transparent 50%, transparent 100%);
 background-size: 1px 10px;
 `)])]),f("timeline-item-timeline",`
 width: calc(var(--n-icon-size) + 12px);
 position: absolute;
 top: calc(var(--n-title-font-size) * ${de} / 2 - var(--n-icon-size) / 2);
 height: 100%;
 `,[x("circle",`
 border: var(--n-circle-border);
 transition:
 background-color .3s var(--n-bezier),
 border-color .3s var(--n-bezier);
 width: var(--n-icon-size);
 height: var(--n-icon-size);
 border-radius: var(--n-icon-size);
 box-sizing: border-box;
 `),x("icon",`
 color: var(--n-icon-color);
 font-size: var(--n-icon-size);
 height: var(--n-icon-size);
 width: var(--n-icon-size);
 display: flex;
 align-items: center;
 justify-content: center;
 `),x("line",`
 transition: background-color .3s var(--n-bezier);
 position: absolute;
 top: var(--n-icon-size);
 left: calc(var(--n-icon-size) / 2 - 1px);
 bottom: 0px;
 width: 2px;
 background-color: var(--n-line-color);
 `)])])]),Ee=Object.assign(Object.assign({},he.props),{horizontal:Boolean,itemPlacement:{type:String,default:"left"},size:{type:String,default:"medium"},iconSize:Number}),_e=Ce("n-timeline"),He=me({name:"Timeline",props:Ee,setup(t,{slots:o}){const{mergedClsPrefixRef:m}=ue(t),_=he("Timeline","-timeline",Ve,Fe,t,m);return ze(_e,{props:t,mergedThemeRef:_,mergedClsPrefixRef:m}),()=>{const{value:c}=m;return z("div",{class:[`${c}-timeline`,t.horizontal&&`${c}-timeline--horizontal`,`${c}-timeline--${t.size}-size`,!t.horizontal&&`${c}-timeline--${t.itemPlacement}-placement`]},o)}}}),We={time:[String,Number],title:String,content:String,color:String,lineType:{type:String,default:"default"},type:{type:String,default:"default"}},qe=me({name:"TimelineItem",props:We,setup(t){const o=Se(_e);o||$e("timeline-item","`n-timeline-item` must be placed inside `n-timeline`."),Oe();const{inlineThemeDisabled:m}=ue(),_=j(()=>{const{props:{size:g,iconSize:w},mergedThemeRef:k}=o,{type:p}=t,{self:{titleTextColor:C,contentTextColor:B,metaTextColor:Y,lineColor:G,titleFontWeight:M,contentFontSize:D,[L("iconSize",g)]:Z,[L("titleMargin",g)]:N,[L("titleFontSize",g)]:J,[L("circleBorder",p)]:F,[L("iconColor",p)]:V},common:{cubicBezierEaseInOut:Q}}=k.value;return{"--n-bezier":Q,"--n-circle-border":F,"--n-icon-color":V,"--n-content-font-size":D,"--n-content-text-color":B,"--n-line-color":G,"--n-meta-text-color":Y,"--n-title-font-size":J,"--n-title-font-weight":M,"--n-title-margin":N,"--n-title-text-color":C,"--n-icon-size":Le(w)||Z}}),c=m?Te("timeline-item",j(()=>{const{props:{size:g,iconSize:w}}=o,{type:k}=t;return`${g[0]}${w||"a"}${k[0]}`}),_,o.props):void 0;return{mergedClsPrefix:o.mergedClsPrefixRef,cssVars:m?void 0:_,themeClass:c==null?void 0:c.themeClass,onRender:c==null?void 0:c.onRender}},render(){const{mergedClsPrefix:t,color:o,onRender:m,$slots:_}=this;return m==null||m(),z("div",{class:[`${t}-timeline-item`,this.themeClass,`${t}-timeline-item--${this.type}-type`,`${t}-timeline-item--${this.lineType}-line-type`],style:this.cssVars},z("div",{class:`${t}-timeline-item-timeline`},z("div",{class:`${t}-timeline-item-timeline__line`}),oe(_.icon,c=>c?z("div",{class:`${t}-timeline-item-timeline__icon`,style:{color:o}},c):z("div",{class:`${t}-timeline-item-timeline__circle`,style:{borderColor:o}}))),z("div",{class:`${t}-timeline-item-content`},oe(_.header,c=>c||this.title?z("div",{class:`${t}-timeline-item-content__title`},c||this.title):null),z("div",{class:`${t}-timeline-item-content__content`},se(_.default,()=>[this.content])),z("div",{class:`${t}-timeline-item-content__meta`},se(_.footer,()=>[this.time]))))}}),Ke={pending_review:"warning",cs_rejected:"error",tech_processing:"info",field_verification:"warning",pending_close:"success",tech_rejected:"error",done:"success"},ve={pending_review:"审核中",cs_rejected:"客服驳回",tech_processing:"技术处理中",field_verification:"现场验证",pending_close:"待关闭",tech_rejected:"技术驳回",done:"已关闭"},Ai=Object.entries(ve).map(([t,o])=>({value:t,label:o}));function Ye(t){return{submit:"提交工单",resubmit:"重新提交",cs_approve:"客服通过",cs_reject:"客服驳回",tech_start:"技术接手",tech_assign:"改派技术",tech_note:"处理备注",field_verify:"现场验证",field_reject:"验证不通过",tech_reject:"技术驳回",finish:"处理完成",close:"关闭工单"}[t]||t||"-"}const a=t=>(Re("data-v-7de333b6"),t=t(),Ae(),t),Ge={class:"detail-header"},Ze={class:"detail-no"},Je={class:"detail-title"},Qe={class:"detail-grid"},Xe={class:"detail-card"},et=a(()=>e("span",null,"项目名称",-1)),tt={class:"detail-card"},it=a(()=>e("span",null,"联系人",-1)),nt={class:"detail-card"},ot=a(()=>e("span",null,"联系方式",-1)),st={class:"detail-card"},at=a(()=>e("span",null,"项目阶段",-1)),ct={class:"detail-card"},lt=a(()=>e("span",null,"跟踪",-1)),rt={class:"detail-card"},dt=a(()=>e("span",null,"影响范围",-1)),mt={class:"detail-card"},ut=a(()=>e("span",null,"问题分类",-1)),ht={class:"detail-card"},_t=a(()=>e("span",null,"创建时间",-1)),vt={class:"detail-card"},gt=a(()=>e("span",null,"提交人",-1)),ft={class:"detail-card"},pt=a(()=>e("span",null,"附件数量",-1)),bt={class:"detail-card"},kt=a(()=>e("span",null,"客服审核人",-1)),yt={class:"detail-card"},wt=a(()=>e("span",null,"指派技术",-1)),xt={class:"detail-card"},zt=a(()=>e("span",null,"问题根因",-1)),Ct={class:"detail-card detail-card-wide"},St=a(()=>e("span",null,"完成时间",-1)),$t={class:"detail-card"},Tt=a(()=>e("span",null,"Redmine工单",-1)),jt=["href"],It={class:"detail-card"},Bt=a(()=>e("span",null,"Redmine状态",-1)),Mt={class:"detail-card"},Rt=a(()=>e("span",null,"Redmine同步时间",-1)),At={class:"description-card"},Lt=a(()=>e("div",{class:"section-title"},"问题描述",-1)),Pt={key:0,class:"detail-loading"},Ut=a(()=>e("span",null,"详情加载中...",-1)),Ot=["innerHTML"],Dt={class:"detail-secondary-grid"},Nt={class:"attachment-card"},Ft=a(()=>e("div",{class:"section-title"},"附件列表",-1)),Vt={key:0,class:"detail-loading"},Et=a(()=>e("span",null,"附件加载中...",-1)),Ht={key:1,class:"image-preview-grid"},Wt=["href"],qt=["src","alt"],Kt={key:2,class:"attachment-list"},Yt={class:"attachment-name"},Gt={class:"attachment-meta"},Zt={class:"attachment-actions"},Jt={class:"timeline-card"},Qt=a(()=>e("div",{class:"section-title"},"流转日志",-1)),Xt={key:0,class:"detail-loading"},ei=a(()=>e("span",null,"流转日志加载中...",-1)),ti={key:0,viewBox:"0 0 24 24","aria-hidden":"true"},ii=a(()=>e("path",{d:"M5 12.5l3.2 3.2L14 10"},null,-1)),ni=a(()=>e("path",{d:"M10 12.5l3.2 3.2L19 10"},null,-1)),oi=[ii,ni],si={key:1,viewBox:"0 0 24 24","aria-hidden":"true"},ai=a(()=>e("circle",{cx:"12",cy:"12",r:"3.5",fill:"currentColor",stroke:"none"},null,-1)),ci=[ai],li={key:2,viewBox:"0 0 24 24","aria-hidden":"true"},ri=a(()=>e("path",{d:"M16.5 7.5A6 6 0 1 0 18 12"},null,-1)),di=a(()=>e("path",{d:"M16.5 4.5v3h-3"},null,-1)),mi=[ri,di],ui={key:3,viewBox:"0 0 24 24","aria-hidden":"true"},hi=a(()=>e("path",{d:"M8 8l8 8"},null,-1)),_i=a(()=>e("path",{d:"M16 8l-8 8"},null,-1)),vi=[hi,_i],gi={key:4,viewBox:"0 0 24 24","aria-hidden":"true"},fi=a(()=>e("path",{d:"M6 12.5l4 4L18 8.5"},null,-1)),pi=[fi],bi={class:"timeline-content"},ki=["innerHTML"],yi={class:"timeline-meta"},wi={key:0,class:"timeline-meta"},xi={class:"description-image-preview"},zi=["src","alt"],Ci={__name:"TicketDetailModal",props:{visible:{type:Boolean,default:!1},ticket:{type:Object,default(){return{}}},loading:{type:Boolean,default:!1}},emits:["update:visible"],setup(t){const o=t,m=j(()=>{var i;return((i=o.ticket)==null?void 0:i.attachments)||[]}),_=j(()=>m.value.filter(i=>ce(i.origin_name||i.file_path||""))),c=P({}),g=P({}),w=P(!1),k=P(""),p=P(""),C=j(()=>{var i;return ie(((i=o.ticket)==null?void 0:i.description)||"-")}),B=j(()=>{var i;return Array.isArray((i=o.ticket)==null?void 0:i.actions)&&o.ticket.actions.length>0}),Y={never:"未同步",success:"同步成功",failed:"同步失败",syncing:"同步中"},G=j(()=>{var i,s;return((i=o.ticket)==null?void 0:i.redmine_status_name)||Y[(s=o.ticket)==null?void 0:s.redmine_sync_status]||"-"});function M(){Object.values(c.value||{}).forEach(i=>{i&&URL.revokeObjectURL(i)}),Object.values(g.value||{}).forEach(i=>{i&&URL.revokeObjectURL(i)})}function D(i){return c.value[i.id]||""}function Z(){w.value=!1,k.value="",p.value=""}function N(i){const s=i==null?void 0:i.target;if(!(s instanceof HTMLImageElement))return;const l=s.currentSrc||s.src;l&&(i.preventDefault(),k.value=l,p.value=s.alt||"问题描述图片",w.value=!0)}function J(i){N(i)}function F(i){const l=String(i||"").match(/[?&]attachment_id=(\d+)/);return l?Number(l[1]):null}function V(i,s){return`${i||"action"}:${s}`}function Q(i){const s=[],l=new Set;for(const b of i||[]){const u=String((b==null?void 0:b.comment)||""),v=new DOMParser().parseFromString(u,"text/html");for(const S of Array.from(v.querySelectorAll("img[src]"))){const I=F(S.getAttribute("src"));if(!I)continue;const ee=V(b.id,I);l.has(ee)||(l.add(ee),s.push({key:ee,attachmentId:I}))}}return s}je(()=>{var i,s;return[o.visible,(i=o.ticket)==null?void 0:i.id,_.value.map(l=>l.id).join(","),(((s=o.ticket)==null?void 0:s.actions)||[]).map(l=>`${l.id}:${l.updated_at||l.created_at||""}`).join(",")]},s=>H(this,[s],function*([i]){var u;if(!i){M(),c.value={},g.value={},Z();return}M();const l={};for(const n of _.value)try{const v=yield W.downloadTicketAttachment({attachment_id:n.id}),S=v instanceof Blob?v:new Blob([v]);l[n.id]=URL.createObjectURL(S)}catch(v){l[n.id]=""}c.value=l;const b={};for(const n of Q(((u=o.ticket)==null?void 0:u.actions)||[]))try{const v=yield W.downloadTicketAttachment({attachment_id:n.attachmentId}),S=v instanceof Blob?v:new Blob([v]);b[n.key]=URL.createObjectURL(S)}catch(v){b[n.key]=""}g.value=b}),{immediate:!0}),Ie(()=>{M(),c.value={},g.value={}});function ge(i){return H(this,null,function*(){if(!(i!=null&&i.id))return;const s=yield W.downloadTicketAttachment({attachment_id:i.id}),l=s instanceof Blob?s:new Blob([s]),b=window.URL.createObjectURL(l),u=document.createElement("a");u.href=b,u.download=i.origin_name||`attachment-${i.id}`,document.body.appendChild(u),u.click(),u.remove(),window.URL.revokeObjectURL(b)})}function fe(i){return H(this,null,function*(){const s=yield W.downloadTicketAttachment({attachment_id:i.id}),l=s instanceof Blob?s:new Blob([s]);if(!l.type.startsWith("image/")){$message.warning("仅支持复制图片附件");return}yield navigator.clipboard.write([new ClipboardItem({[l.type]:l})]),$message.success("图片已复制")})}function pe(i){var u,n;if(!i)return"-";if(i.action==="finish"&&((u=o.ticket)!=null&&u.root_cause)){const v=((n=i.comment)==null?void 0:n.trim())||"处理完成";return ie(`${v}（根因：${o.ticket.root_cause}）`)}const s=ie(i.comment||"-"),b=new DOMParser().parseFromString(s,"text/html");for(const v of Array.from(b.querySelectorAll("img[src]"))){const S=F(v.getAttribute("src"));if(!S)continue;const I=g.value[V(i.id,S)];I&&v.setAttribute("src",I)}return b.body.innerHTML}function X(i){return i==="cs_reject"||i==="tech_reject"}function E(i){return i==="finish"?"finish":i==="submit"||i==="resubmit"?"submit":i==="tech_start"?"handle":X(i)?"reject":"pass"}function be(i){return X(i)?"is-reject":i==="finish"?"is-finish":i==="submit"||i==="resubmit"?"is-submit":i==="tech_start"?"is-handle":"is-pass"}return(i,s)=>{const l=qe,b=He;return d(),h(U,null,[T(ke,{visible:t.visible,title:"工单详情",width:"min(96vw, 1280px)","show-footer":!1,"onUpdate:visible":s[0]||(s[0]=u=>i.$emit("update:visible",u))},{default:$(()=>{var u;return[e("div",Ge,[e("div",null,[e("div",Ze,r(t.ticket.ticket_no),1),e("div",Je,r(t.ticket.title),1)]),T(y(Ue),{type:y(Ke)[t.ticket.status]||"default"},{default:$(()=>[q(r(y(ve)[t.ticket.status]||"-"),1)]),_:1},8,["type"])]),e("div",Qe,[e("div",Xe,[et,e("strong",null,r(t.ticket.company_name||"-"),1)]),e("div",tt,[it,e("strong",null,r(t.ticket.contact_name||"-"),1)]),e("div",nt,[ot,e("strong",null,r(t.ticket.phone||"-"),1)]),e("div",st,[at,e("strong",null,r(t.ticket.project_phase||"-"),1)]),e("div",ct,[lt,e("strong",null,r(t.ticket.issue_type||"-"),1)]),e("div",rt,[dt,e("strong",null,r(t.ticket.impact_scope||"-"),1)]),e("div",mt,[ut,e("strong",null,r(t.ticket.category||"-"),1)]),e("div",ht,[_t,e("strong",null,r(t.ticket.created_at||"-"),1)]),e("div",vt,[gt,e("strong",null,r(t.ticket.submitter_name||t.ticket.submitter_id||"-"),1)]),e("div",ft,[pt,e("strong",null,r((u=t.ticket.attachment_count)!=null?u:m.value.length),1)]),e("div",bt,[kt,e("strong",null,r(t.ticket.reviewer_name||t.ticket.reviewer_id||"-"),1)]),e("div",yt,[wt,e("strong",null,r(t.ticket.tech_name||t.ticket.tech_id||"-"),1)]),e("div",xt,[zt,e("strong",null,r(t.ticket.root_cause||"-"),1)]),e("div",Ct,[St,e("strong",null,r(t.ticket.finished_at||"-"),1)]),e("div",$t,[Tt,e("strong",null,[t.ticket.redmine_issue_url?(d(),h("a",{key:0,href:t.ticket.redmine_issue_url,target:"_blank",rel:"noopener"}," #"+r(t.ticket.redmine_issue_id),9,jt)):(d(),h(U,{key:1},[q(r(t.ticket.redmine_issue_id?`#${t.ticket.redmine_issue_id}`:"-"),1)],64))])]),e("div",It,[Bt,e("strong",null,r(G.value),1)]),e("div",Mt,[Rt,e("strong",null,r(t.ticket.redmine_synced_at||"-"),1)])]),e("div",At,[Lt,t.loading?(d(),h("div",Pt,[T(y(ne),{size:"small"}),Ut])):(d(),h("div",{key:1,class:"description-content",onClick:N,innerHTML:C.value},null,8,Ot))]),e("div",Dt,[e("div",Nt,[Ft,t.loading?(d(),h("div",Vt,[T(y(ne),{size:"small"}),Et])):_.value.length?(d(),h("div",Ht,[(d(!0),h(U,null,te(_.value,n=>(d(),h("a",{key:`img-${n.id}`,href:D(n),target:"_blank",rel:"noopener",class:"image-preview-item"},[e("img",{src:D(n),alt:n.origin_name||`image-${n.id}`},null,8,qt)],8,Wt))),128))])):K("",!0),!t.loading&&m.value.length?(d(),h("div",Kt,[(d(!0),h(U,null,te(m.value,n=>(d(),h("div",{key:n.id,class:"attachment-item"},[e("div",null,[e("div",Yt,r(n.origin_name||n.file_path),1),e("div",Gt,r(n.mime_type||"application/octet-stream")+" / "+r(n.file_size||0)+" bytes",1)]),e("div",Zt,[y(ce)(n.origin_name||n.file_path||"")?(d(),O(y(ae),{key:0,size:"small",type:"info",quaternary:"",onClick:v=>fe(n)},{default:$(()=>[q("复制图片")]),_:2},1032,["onClick"])):K("",!0),T(y(ae),{size:"small",type:"primary",quaternary:"",onClick:v=>ge(n)},{default:$(()=>[q("下载")]),_:2},1032,["onClick"])])]))),128))])):t.loading?K("",!0):(d(),O(y(le),{key:3,description:"暂无附件",size:"small"}))]),e("div",Jt,[Qt,t.loading?(d(),h("div",Xt,[T(y(ne),{size:"small"}),ei])):B.value?(d(),O(b,{key:1,class:"ticket-timeline"},{default:$(()=>[(d(!0),h(U,null,te(t.ticket.actions||[],n=>(d(),O(l,{key:n.id,title:y(Ye)(n.action),type:X(n.action)?"error":"success"},{icon:$(()=>[e("span",{class:Be(["timeline-icon",be(n.action)])},[E(n.action)==="finish"?(d(),h("svg",ti,oi)):E(n.action)==="submit"?(d(),h("svg",si,ci)):E(n.action)==="handle"?(d(),h("svg",li,mi)):E(n.action)==="reject"?(d(),h("svg",ui,vi)):(d(),h("svg",gi,pi))],2)]),default:$(()=>[e("div",bi,[e("div",{class:"timeline-comment",onClick:J,innerHTML:pe(n)},null,8,ki),e("div",yi,"操作者："+r(n.operator_display||n.operator_name||n.operator_id||"-"),1),n.created_at?(d(),h("div",wi,"时间："+r(n.created_at),1)):K("",!0)])]),_:2},1032,["title","type"]))),128))]),_:1})):(d(),O(y(le),{key:2,description:"暂无流转日志",size:"small"}))])])]}),_:1},8,["visible"]),T(y(Me),{show:w.value,"onUpdate:show":s[1]||(s[1]=u=>w.value=u),preset:"card",title:"图片预览",class:"description-image-modal"},{default:$(()=>[e("div",xi,[e("img",{src:k.value,alt:p.value},null,8,zi)])]),_:1},8,["show"])],64)}}},Li=Pe(Ci,[["__scopeId","data-v-7de333b6"]]);export{Li as T,Ke as a,Ai as b,ve as t};
