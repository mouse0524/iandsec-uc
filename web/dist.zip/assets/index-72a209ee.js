import{d as K,h as p,r as A,c as S,w as ue,n as me,t as ee,a as b,b as It,e as y,f as kt,g as L,i as k,u as $t,N as Je,T as St,j as Rt,k as Ve,l as Se,m as ne,o as Nt,p as ve,q as Pt,s as At,v as Re,x as Lt,y as Mt,z as Qe,A as Ht,B as Tt,C as te,D as fe,E as Bt,F as Et,G as q,H as Q,I as W,J as Ot,K as ye,L as be,M as Ne,O as re,P as Ft,Q as Kt,R as we,S as G,U as Vt,V as Dt,W as pe,X as _e,Y as f,Z as M,_ as B,$ as P,a0 as he,a1 as w,a2 as et,a3 as J,a4 as D,a5 as tt,a6 as U,a7 as $,a8 as X,a9 as Pe,aa as jt,ab as oe,ac as Ut,ad as Wt,ae as qt,af as Gt,ag as T,ah as ce,ai as Ce,aj as Yt,ak as se,al as Xt,am as Zt,an as ot,ao as nt,ap as Jt,aq as rt,ar as De,as as it,at as Qt,au as eo,av as to,aw as ze,ax as oo,ay as Ie,az as at,aA as je,aB as no,aC as ro,aD as Ue}from"./index-ad7b4e66.js";import{N as Ae}from"./Dropdown-1ac458f0.js";import{s as We}from"./sanitize-0635dc57.js";import{_ as Le}from"./_plugin-vue_export-helper-c27b6911.js";import{g as io,c as xe,V as ao}from"./create-d554b2ed.js";import{N as lo}from"./Popover-563ac5a7.js";import{N as lt}from"./Tag-dd8bd7cf.js";import{_ as co}from"./logo-a3dfa6af.js";import{l as so,N as uo,a as mo}from"./LayoutSider-f2b564cb.js";import{N as ho}from"./Tooltip-d2a3659e.js";import{u as qe}from"./use-merged-state-d42f8899.js";import{u as vo}from"./use-compitable-6fc1e7e9.js";import{d as Ge}from"./common-93afc93a.js";import"./get-872bd3b8.js";const fo=K({name:"ChevronDownFilled",render(){return p("svg",{viewBox:"0 0 16 16",fill:"none",xmlns:"http://www.w3.org/2000/svg"},p("path",{d:"M3.20041 5.73966C3.48226 5.43613 3.95681 5.41856 4.26034 5.70041L8 9.22652L11.7397 5.70041C12.0432 5.41856 12.5177 5.43613 12.7996 5.73966C13.0815 6.0432 13.0639 6.51775 12.7603 6.7996L8.51034 10.7996C8.22258 11.0668 7.77743 11.0668 7.48967 10.7996L3.23966 6.7996C2.93613 6.51775 2.91856 6.0432 3.20041 5.73966Z",fill:"currentColor"}))}}),Ye=K({name:"SlotMachineNumber",props:{clsPrefix:{type:String,required:!0},value:{type:[Number,String],required:!0},oldOriginalNumber:{type:Number,default:void 0},newOriginalNumber:{type:Number,default:void 0}},setup(e){const o=A(null),t=A(e.value),i=A(e.value),r=A("up"),n=A(!1),d=S(()=>n.value?`${e.clsPrefix}-base-slot-machine-current-number--${r.value}-scroll`:null),u=S(()=>n.value?`${e.clsPrefix}-base-slot-machine-old-number--${r.value}-scroll`:null);ue(ee(e,"value"),(h,c)=>{t.value=c,i.value=h,me(v)});function v(){const h=e.newOriginalNumber,c=e.oldOriginalNumber;c===void 0||h===void 0||(h>c?g("up"):c>h&&g("down"))}function g(h){r.value=h,n.value=!1,me(()=>{var c;(c=o.value)===null||c===void 0||c.offsetWidth,n.value=!0})}return()=>{const{clsPrefix:h}=e;return p("span",{ref:o,class:`${h}-base-slot-machine-number`},t.value!==null?p("span",{class:[`${h}-base-slot-machine-old-number ${h}-base-slot-machine-old-number--top`,u.value]},t.value):null,p("span",{class:[`${h}-base-slot-machine-current-number`,d.value]},p("span",{ref:"numberWrapper",class:[`${h}-base-slot-machine-current-number__inner`,typeof e.value!="number"&&`${h}-base-slot-machine-current-number__inner--not-number`]},i.value)),t.value!==null?p("span",{class:[`${h}-base-slot-machine-old-number ${h}-base-slot-machine-old-number--bottom`,u.value]},t.value):null)}}}),{cubicBezierEaseOut:Z}=It;function po({duration:e=".2s"}={}){return[b("&.fade-up-width-expand-transition-leave-active",{transition:`
 opacity ${e} ${Z},
 max-width ${e} ${Z},
 transform ${e} ${Z}
 `}),b("&.fade-up-width-expand-transition-enter-active",{transition:`
 opacity ${e} ${Z},
 max-width ${e} ${Z},
 transform ${e} ${Z}
 `}),b("&.fade-up-width-expand-transition-enter-to",{opacity:1,transform:"translateX(0) translateY(0)"}),b("&.fade-up-width-expand-transition-enter-from",{maxWidth:"0 !important",opacity:0,transform:"translateY(60%)"}),b("&.fade-up-width-expand-transition-leave-from",{opacity:1,transform:"translateY(0)"}),b("&.fade-up-width-expand-transition-leave-to",{maxWidth:"0 !important",opacity:0,transform:"translateY(60%)"})]}const _o=b([b("@keyframes n-base-slot-machine-fade-up-in",`
 from {
 transform: translateY(60%);
 opacity: 0;
 }
 to {
 transform: translateY(0);
 opacity: 1;
 }
 `),b("@keyframes n-base-slot-machine-fade-down-in",`
 from {
 transform: translateY(-60%);
 opacity: 0;
 }
 to {
 transform: translateY(0);
 opacity: 1;
 }
 `),b("@keyframes n-base-slot-machine-fade-up-out",`
 from {
 transform: translateY(0%);
 opacity: 1;
 }
 to {
 transform: translateY(-60%);
 opacity: 0;
 }
 `),b("@keyframes n-base-slot-machine-fade-down-out",`
 from {
 transform: translateY(0%);
 opacity: 1;
 }
 to {
 transform: translateY(60%);
 opacity: 0;
 }
 `),y("base-slot-machine",`
 overflow: hidden;
 white-space: nowrap;
 display: inline-block;
 height: 18px;
 line-height: 18px;
 `,[y("base-slot-machine-number",`
 display: inline-block;
 position: relative;
 height: 18px;
 width: .6em;
 max-width: .6em;
 `,[po({duration:".2s"}),kt({duration:".2s",delay:"0s"}),y("base-slot-machine-old-number",`
 display: inline-block;
 opacity: 0;
 position: absolute;
 left: 0;
 right: 0;
 `,[L("top",{transform:"translateY(-100%)"}),L("bottom",{transform:"translateY(100%)"}),L("down-scroll",{animation:"n-base-slot-machine-fade-down-out .2s cubic-bezier(0, 0, .2, 1)",animationIterationCount:1}),L("up-scroll",{animation:"n-base-slot-machine-fade-up-out .2s cubic-bezier(0, 0, .2, 1)",animationIterationCount:1})]),y("base-slot-machine-current-number",`
 display: inline-block;
 position: absolute;
 left: 0;
 top: 0;
 bottom: 0;
 right: 0;
 opacity: 1;
 transform: translateY(0);
 width: .6em;
 `,[L("down-scroll",{animation:"n-base-slot-machine-fade-down-in .2s cubic-bezier(0, 0, .2, 1)",animationIterationCount:1}),L("up-scroll",{animation:"n-base-slot-machine-fade-up-in .2s cubic-bezier(0, 0, .2, 1)",animationIterationCount:1}),k("inner",`
 display: inline-block;
 position: absolute;
 right: 0;
 top: 0;
 width: .6em;
 `,[L("not-number",`
 right: unset;
 left: 0;
 `)])])])])]),go=K({name:"BaseSlotMachine",props:{clsPrefix:{type:String,required:!0},value:{type:[Number,String],default:0},max:{type:Number,default:void 0},appeared:{type:Boolean,required:!0}},setup(e){$t("-base-slot-machine",_o,ee(e,"clsPrefix"));const o=A(),t=A(),i=S(()=>{if(typeof e.value=="string")return[];if(e.value<1)return[0];const r=[];let n=e.value;for(e.max!==void 0&&(n=Math.min(e.max,n));n>=1;)r.push(n%10),n/=10,n=Math.floor(n);return r.reverse(),r});return ue(ee(e,"value"),(r,n)=>{typeof r=="string"?(t.value=void 0,o.value=void 0):typeof n=="string"?(t.value=r,o.value=void 0):(t.value=r,o.value=n)}),()=>{const{value:r,clsPrefix:n}=e;return typeof r=="number"?p("span",{class:`${n}-base-slot-machine`},p(St,{name:"fade-up-width-expand-transition",tag:"span"},{default:()=>i.value.map((d,u)=>p(Ye,{clsPrefix:n,key:i.value.length-u-1,oldOriginalNumber:o.value,newOriginalNumber:t.value,value:d}))}),p(Je,{key:"+",width:!0},{default:()=>e.max!==void 0&&e.max<r?p(Ye,{clsPrefix:n,value:"+"}):null})):p("span",{class:`${n}-base-slot-machine`},r)}}});function bo(e){const{errorColor:o,infoColor:t,successColor:i,warningColor:r,fontFamily:n}=e;return{color:o,colorInfo:t,colorSuccess:i,colorError:o,colorWarning:r,fontSize:"12px",fontFamily:n}}const xo={name:"Badge",common:Rt,self:bo},yo=xo,wo=b([b("@keyframes badge-wave-spread",{from:{boxShadow:"0 0 0.5px 0px var(--n-ripple-color)",opacity:.6},to:{boxShadow:"0 0 0.5px 4.5px var(--n-ripple-color)",opacity:0}}),y("badge",`
 display: inline-flex;
 position: relative;
 vertical-align: middle;
 font-family: var(--n-font-family);
 `,[L("as-is",[y("badge-sup",{position:"static",transform:"translateX(0)"},[Ve({transformOrigin:"left bottom",originalTransform:"translateX(0)"})])]),L("dot",[y("badge-sup",`
 height: 8px;
 width: 8px;
 padding: 0;
 min-width: 8px;
 left: 100%;
 bottom: calc(100% - 4px);
 `,[b("::before","border-radius: 4px;")])]),y("badge-sup",`
 background: var(--n-color);
 transition:
 background-color .3s var(--n-bezier),
 color .3s var(--n-bezier);
 color: #FFF;
 position: absolute;
 height: 18px;
 line-height: 18px;
 border-radius: 9px;
 padding: 0 6px;
 text-align: center;
 font-size: var(--n-font-size);
 transform: translateX(-50%);
 left: 100%;
 bottom: calc(100% - 9px);
 font-variant-numeric: tabular-nums;
 z-index: 1;
 display: flex;
 align-items: center;
 `,[Ve({transformOrigin:"left bottom",originalTransform:"translateX(-50%)"}),y("base-wave",{zIndex:1,animationDuration:"2s",animationIterationCount:"infinite",animationDelay:"1s",animationTimingFunction:"var(--n-ripple-bezier)",animationName:"badge-wave-spread"}),b("&::before",`
 opacity: 0;
 transform: scale(1);
 border-radius: 9px;
 content: "";
 position: absolute;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 `)])])]),Co=Object.assign(Object.assign({},ne.props),{value:[String,Number],max:Number,dot:Boolean,type:{type:String,default:"default"},show:{type:Boolean,default:!0},showZero:Boolean,processing:Boolean,color:String,offset:Array}),zo=K({name:"Badge",props:Co,setup(e,{slots:o}){const{mergedClsPrefixRef:t,inlineThemeDisabled:i,mergedRtlRef:r}=Se(e),n=ne("Badge","-badge",wo,yo,e,t),d=A(!1),u=()=>{d.value=!0},v=()=>{d.value=!1},g=S(()=>e.show&&(e.dot||e.value!==void 0&&!(!e.showZero&&Number(e.value)<=0)||!Nt(o.value)));ve(()=>{g.value&&(d.value=!0)});const h=Pt("Badge",r,t),c=S(()=>{const{type:s,color:_}=e,{common:{cubicBezierEaseInOut:C,cubicBezierEaseOut:R},self:{[At("color",s)]:O,fontFamily:F,fontSize:E}}=n.value;return{"--n-font-size":E,"--n-font-family":F,"--n-color":_||O,"--n-ripple-color":_||O,"--n-bezier":C,"--n-ripple-bezier":R}}),a=i?Re("badge",S(()=>{let s="";const{type:_,color:C}=e;return _&&(s+=_[0]),C&&(s+=Lt(C)),s}),c,e):void 0,z=S(()=>{const{offset:s}=e;if(!s)return;const[_,C]=s,R=typeof _=="number"?`${_}px`:_,O=typeof C=="number"?`${C}px`:C;return{transform:`translate(calc(${h?.value?"50%":"-50%"} + ${R}), ${O})`}});return{rtlEnabled:h,mergedClsPrefix:t,appeared:d,showBadge:g,handleAfterEnter:u,handleAfterLeave:v,cssVars:i?void 0:c,themeClass:a?.themeClass,onRender:a?.onRender,offsetStyle:z}},render(){var e;const{mergedClsPrefix:o,onRender:t,themeClass:i,$slots:r}=this;t?.();const n=(e=r.default)===null||e===void 0?void 0:e.call(r);return p("div",{class:[`${o}-badge`,this.rtlEnabled&&`${o}-badge--rtl`,i,{[`${o}-badge--dot`]:this.dot,[`${o}-badge--as-is`]:!n}],style:this.cssVars},n,p(Mt,{name:"fade-in-scale-up-transition",onAfterEnter:this.handleAfterEnter,onAfterLeave:this.handleAfterLeave},{default:()=>this.showBadge?p("sup",{class:`${o}-badge-sup`,title:io(this.value),style:this.offsetStyle},Qe(r.value,()=>[this.dot?null:p(go,{clsPrefix:o,appeared:this.appeared,max:this.max,value:this.value})]),this.processing?p(Ht,{clsPrefix:o}):null):null}))}}),Io=y("breadcrumb",`
 white-space: nowrap;
 cursor: default;
 line-height: var(--n-item-line-height);
`,[b("ul",`
 list-style: none;
 padding: 0;
 margin: 0;
 `),b("a",`
 color: inherit;
 text-decoration: inherit;
 `),y("breadcrumb-item",`
 font-size: var(--n-font-size);
 transition: color .3s var(--n-bezier);
 display: inline-flex;
 align-items: center;
 `,[y("icon",`
 font-size: 18px;
 vertical-align: -.2em;
 transition: color .3s var(--n-bezier);
 color: var(--n-item-text-color);
 `),b("&:not(:last-child)",[L("clickable",[k("link",`
 cursor: pointer;
 `,[b("&:hover",`
 background-color: var(--n-item-color-hover);
 `),b("&:active",`
 background-color: var(--n-item-color-pressed); 
 `)])])]),k("link",`
 padding: 4px;
 border-radius: var(--n-item-border-radius);
 transition:
 background-color .3s var(--n-bezier),
 color .3s var(--n-bezier);
 color: var(--n-item-text-color);
 position: relative;
 `,[b("&:hover",`
 color: var(--n-item-text-color-hover);
 `,[y("icon",`
 color: var(--n-item-text-color-hover);
 `)]),b("&:active",`
 color: var(--n-item-text-color-pressed);
 `,[y("icon",`
 color: var(--n-item-text-color-pressed);
 `)])]),k("separator",`
 margin: 0 8px;
 color: var(--n-separator-color);
 transition: color .3s var(--n-bezier);
 user-select: none;
 -webkit-user-select: none;
 `),b("&:last-child",[k("link",`
 font-weight: var(--n-font-weight-active);
 cursor: unset;
 color: var(--n-item-text-color-active);
 `,[y("icon",`
 color: var(--n-item-text-color-active);
 `)]),k("separator",`
 display: none;
 `)])])]),ct=fe("n-breadcrumb"),ko=Object.assign(Object.assign({},ne.props),{separator:{type:String,default:"/"}}),$o=K({name:"Breadcrumb",props:ko,setup(e){const{mergedClsPrefixRef:o,inlineThemeDisabled:t}=Se(e),i=ne("Breadcrumb","-breadcrumb",Io,Tt,e,o);te(ct,{separatorRef:ee(e,"separator"),mergedClsPrefixRef:o});const r=S(()=>{const{common:{cubicBezierEaseInOut:d},self:{separatorColor:u,itemTextColor:v,itemTextColorHover:g,itemTextColorPressed:h,itemTextColorActive:c,fontSize:a,fontWeightActive:z,itemBorderRadius:s,itemColorHover:_,itemColorPressed:C,itemLineHeight:R}}=i.value;return{"--n-font-size":a,"--n-bezier":d,"--n-item-text-color":v,"--n-item-text-color-hover":g,"--n-item-text-color-pressed":h,"--n-item-text-color-active":c,"--n-separator-color":u,"--n-item-color-hover":_,"--n-item-color-pressed":C,"--n-item-border-radius":s,"--n-font-weight-active":z,"--n-item-line-height":R}}),n=t?Re("breadcrumb",void 0,r,e):void 0;return{mergedClsPrefix:o,cssVars:t?void 0:r,themeClass:n?.themeClass,onRender:n?.onRender}},render(){var e;return(e=this.onRender)===null||e===void 0||e.call(this),p("nav",{class:[`${this.mergedClsPrefix}-breadcrumb`,this.themeClass],style:this.cssVars,"aria-label":"Breadcrumb"},p("ul",null,this.$slots))}});function So(e=Et?window:null){const o=()=>{const{hash:r,host:n,hostname:d,href:u,origin:v,pathname:g,port:h,protocol:c,search:a}=e?.location||{};return{hash:r,host:n,hostname:d,href:u,origin:v,pathname:g,port:h,protocol:c,search:a}},t=A(o()),i=()=>{t.value=o()};return ve(()=>{e&&(e.addEventListener("popstate",i),e.addEventListener("hashchange",i))}),Bt(()=>{e&&(e.removeEventListener("popstate",i),e.removeEventListener("hashchange",i))}),t}const Ro={separator:String,href:String,clickable:{type:Boolean,default:!0},onClick:Function},No=K({name:"BreadcrumbItem",props:Ro,setup(e,{slots:o}){const t=q(ct,null);if(!t)return()=>null;const{separatorRef:i,mergedClsPrefixRef:r}=t,n=So(),d=S(()=>e.href?"a":"span"),u=S(()=>n.value.href===e.href?"location":null);return()=>{const{value:v}=r;return p("li",{class:[`${v}-breadcrumb-item`,e.clickable&&`${v}-breadcrumb-item--clickable`]},p(d.value,{class:`${v}-breadcrumb-item__link`,"aria-current":u.value,href:e.href,onClick:e.onClick},o),p("span",{class:`${v}-breadcrumb-item__separator`,"aria-hidden":"true"},Qe(o.separator,()=>{var g;return[(g=e.separator)!==null&&g!==void 0?g:i.value]})))}}}),ie=fe("n-menu"),Me=fe("n-submenu"),He=fe("n-menu-item-group"),de=8;function Te(e){const o=q(ie),{props:t,mergedCollapsedRef:i}=o,r=q(Me,null),n=q(He,null),d=S(()=>t.mode==="horizontal"),u=S(()=>d.value?t.dropdownPlacement:"tmNodes"in e?"right-start":"right"),v=S(()=>{var a;return Math.max((a=t.collapsedIconSize)!==null&&a!==void 0?a:t.iconSize,t.iconSize)}),g=S(()=>{var a;return!d.value&&e.root&&i.value&&(a=t.collapsedIconSize)!==null&&a!==void 0?a:t.iconSize}),h=S(()=>{if(d.value)return;const{collapsedWidth:a,indent:z,rootIndent:s}=t,{root:_,isGroup:C}=e,R=s===void 0?z:s;return _?i.value?a/2-v.value/2:R:n&&typeof n.paddingLeftRef.value=="number"?z/2+n.paddingLeftRef.value:r&&typeof r.paddingLeftRef.value=="number"?(C?z/2:z)+r.paddingLeftRef.value:0}),c=S(()=>{const{collapsedWidth:a,indent:z,rootIndent:s}=t,{value:_}=v,{root:C}=e;return d.value||!C||!i.value?de:(s===void 0?z:s)+_+de-(a+_)/2});return{dropdownPlacement:u,activeIconSize:g,maxIconSize:v,paddingLeft:h,iconMarginRight:c,NMenu:o,NSubmenu:r}}const Be={internalKey:{type:[String,Number],required:!0},root:Boolean,isGroup:Boolean,level:{type:Number,required:!0},title:[String,Function],extra:[String,Function]},st=Object.assign(Object.assign({},Be),{tmNode:{type:Object,required:!0},tmNodes:{type:Array,required:!0}}),Po=K({name:"MenuOptionGroup",props:st,setup(e){te(Me,null);const o=Te(e);te(He,{paddingLeftRef:o.paddingLeft});const{mergedClsPrefixRef:t,props:i}=q(ie);return function(){const{value:r}=t,n=o.paddingLeft.value,{nodeProps:d}=i,u=d?.(e.tmNode.rawNode);return p("div",{class:`${r}-menu-item-group`,role:"group"},p("div",Object.assign({},u,{class:[`${r}-menu-item-group-title`,u?.class],style:[u?.style||"",n!==void 0?`padding-left: ${n}px;`:""]}),Q(e.title),e.extra?p(W,null," ",Q(e.extra)):null),p("div",null,e.tmNodes.map(v=>Ee(v,i))))}}}),dt=K({name:"MenuOptionContent",props:{collapsed:Boolean,disabled:Boolean,title:[String,Function],icon:Function,extra:[String,Function],showArrow:Boolean,childActive:Boolean,hover:Boolean,paddingLeft:Number,selected:Boolean,maxIconSize:{type:Number,required:!0},activeIconSize:{type:Number,required:!0},iconMarginRight:{type:Number,required:!0},clsPrefix:{type:String,required:!0},onClick:Function,tmNode:{type:Object,required:!0},isEllipsisPlaceholder:Boolean},setup(e){const{props:o}=q(ie);return{menuProps:o,style:S(()=>{const{paddingLeft:t}=e;return{paddingLeft:t&&`${t}px`}}),iconStyle:S(()=>{const{maxIconSize:t,activeIconSize:i,iconMarginRight:r}=e;return{width:`${t}px`,height:`${t}px`,fontSize:`${i}px`,marginRight:`${r}px`}})}},render(){const{clsPrefix:e,tmNode:o,menuProps:{renderIcon:t,renderLabel:i,renderExtra:r,expandIcon:n}}=this,d=t?t(o.rawNode):Q(this.icon);return p("div",{onClick:u=>{var v;(v=this.onClick)===null||v===void 0||v.call(this,u)},role:"none",class:[`${e}-menu-item-content`,{[`${e}-menu-item-content--selected`]:this.selected,[`${e}-menu-item-content--collapsed`]:this.collapsed,[`${e}-menu-item-content--child-active`]:this.childActive,[`${e}-menu-item-content--disabled`]:this.disabled,[`${e}-menu-item-content--hover`]:this.hover}],style:this.style},d&&p("div",{class:`${e}-menu-item-content__icon`,style:this.iconStyle,role:"none"},[d]),p("div",{class:`${e}-menu-item-content-header`,role:"none"},this.isEllipsisPlaceholder?this.title:i?i(o.rawNode):Q(this.title),this.extra||r?p("span",{class:`${e}-menu-item-content-header__extra`}," ",r?r(o.rawNode):Q(this.extra)):null),this.showArrow?p(Ot,{ariaHidden:!0,class:`${e}-menu-item-content__arrow`,clsPrefix:e},{default:()=>n?n(o.rawNode):p(fo,null)}):null)}}),ut=Object.assign(Object.assign({},Be),{rawNodes:{type:Array,default:()=>[]},tmNodes:{type:Array,default:()=>[]},tmNode:{type:Object,required:!0},disabled:Boolean,icon:Function,onClick:Function,domId:String,virtualChildActive:{type:Boolean,default:void 0},isEllipsisPlaceholder:Boolean}),ke=K({name:"Submenu",props:ut,setup(e){const o=Te(e),{NMenu:t,NSubmenu:i}=o,{props:r,mergedCollapsedRef:n,mergedThemeRef:d}=t,u=S(()=>{const{disabled:a}=e;return i?.mergedDisabledRef.value||r.disabled?!0:a}),v=A(!1);te(Me,{paddingLeftRef:o.paddingLeft,mergedDisabledRef:u}),te(He,null);function g(){const{onClick:a}=e;a&&a()}function h(){u.value||(n.value||t.toggleExpand(e.internalKey),g())}function c(a){v.value=a}return{menuProps:r,mergedTheme:d,doSelect:t.doSelect,inverted:t.invertedRef,isHorizontal:t.isHorizontalRef,mergedClsPrefix:t.mergedClsPrefixRef,maxIconSize:o.maxIconSize,activeIconSize:o.activeIconSize,iconMarginRight:o.iconMarginRight,dropdownPlacement:o.dropdownPlacement,dropdownShow:v,paddingLeft:o.paddingLeft,mergedDisabled:u,mergedValue:t.mergedValueRef,childActive:ye(()=>{var a;return(a=e.virtualChildActive)!==null&&a!==void 0?a:t.activePathRef.value.includes(e.internalKey)}),collapsed:S(()=>r.mode==="horizontal"?!1:n.value?!0:!t.mergedExpandedKeysRef.value.includes(e.internalKey)),dropdownEnabled:S(()=>!u.value&&(r.mode==="horizontal"||n.value)),handlePopoverShowChange:c,handleClick:h}},render(){var e;const{mergedClsPrefix:o,menuProps:{renderIcon:t,renderLabel:i}}=this,r=()=>{const{isHorizontal:d,paddingLeft:u,collapsed:v,mergedDisabled:g,maxIconSize:h,activeIconSize:c,title:a,childActive:z,icon:s,handleClick:_,menuProps:{nodeProps:C},dropdownShow:R,iconMarginRight:O,tmNode:F,mergedClsPrefix:E,isEllipsisPlaceholder:j,extra:ae}=this,V=C?.(F.rawNode);return p("div",Object.assign({},V,{class:[`${E}-menu-item`,V?.class],role:"menuitem"}),p(dt,{tmNode:F,paddingLeft:u,collapsed:v,disabled:g,iconMarginRight:O,maxIconSize:h,activeIconSize:c,title:a,extra:ae,showArrow:!d,childActive:z,clsPrefix:E,icon:s,hover:R,onClick:_,isEllipsisPlaceholder:j}))},n=()=>p(Je,null,{default:()=>{const{tmNodes:d,collapsed:u}=this;return u?null:p("div",{class:`${o}-submenu-children`,role:"menu"},d.map(v=>Ee(v,this.menuProps)))}});return this.root?p(Ae,Object.assign({size:"large",trigger:"hover"},(e=this.menuProps)===null||e===void 0?void 0:e.dropdownProps,{themeOverrides:this.mergedTheme.peerOverrides.Dropdown,theme:this.mergedTheme.peers.Dropdown,builtinThemeOverrides:{fontSizeLarge:"14px",optionIconSizeLarge:"18px"},value:this.mergedValue,disabled:!this.dropdownEnabled,placement:this.dropdownPlacement,keyField:this.menuProps.keyField,labelField:this.menuProps.labelField,childrenField:this.menuProps.childrenField,onUpdateShow:this.handlePopoverShowChange,options:this.rawNodes,onSelect:this.doSelect,inverted:this.inverted,renderIcon:t,renderLabel:i}),{default:()=>p("div",{class:`${o}-submenu`,role:"menu","aria-expanded":!this.collapsed,id:this.domId},r(),this.isHorizontal?null:n())}):p("div",{class:`${o}-submenu`,role:"menu","aria-expanded":!this.collapsed,id:this.domId},r(),n())}}),mt=Object.assign(Object.assign({},Be),{tmNode:{type:Object,required:!0},disabled:Boolean,icon:Function,onClick:Function}),Ao=K({name:"MenuOption",props:mt,setup(e){const o=Te(e),{NSubmenu:t,NMenu:i}=o,{props:r,mergedClsPrefixRef:n,mergedCollapsedRef:d}=i,u=t?t.mergedDisabledRef:{value:!1},v=S(()=>u.value||e.disabled);function g(c){const{onClick:a}=e;a&&a(c)}function h(c){v.value||(i.doSelect(e.internalKey,e.tmNode.rawNode),g(c))}return{mergedClsPrefix:n,dropdownPlacement:o.dropdownPlacement,paddingLeft:o.paddingLeft,iconMarginRight:o.iconMarginRight,maxIconSize:o.maxIconSize,activeIconSize:o.activeIconSize,mergedTheme:i.mergedThemeRef,menuProps:r,dropdownEnabled:ye(()=>e.root&&d.value&&r.mode!=="horizontal"&&!v.value),selected:ye(()=>i.mergedValueRef.value===e.internalKey),mergedDisabled:v,handleClick:h}},render(){const{mergedClsPrefix:e,mergedTheme:o,tmNode:t,menuProps:{renderLabel:i,nodeProps:r}}=this,n=r?.(t.rawNode);return p("div",Object.assign({},n,{role:"menuitem",class:[`${e}-menu-item`,n?.class]}),p(ho,{theme:o.peers.Tooltip,themeOverrides:o.peerOverrides.Tooltip,trigger:"hover",placement:this.dropdownPlacement,disabled:!this.dropdownEnabled||this.title===void 0,internalExtraClass:["menu-tooltip"]},{default:()=>i?i(t.rawNode):Q(this.title),trigger:()=>p(dt,{tmNode:t,clsPrefix:e,paddingLeft:this.paddingLeft,iconMarginRight:this.iconMarginRight,maxIconSize:this.maxIconSize,activeIconSize:this.activeIconSize,selected:this.selected,title:this.title,extra:this.extra,disabled:this.mergedDisabled,icon:this.icon,onClick:this.handleClick})}))}}),Lo=K({name:"MenuDivider",setup(){const e=q(ie),{mergedClsPrefixRef:o,isHorizontalRef:t}=e;return()=>t.value?null:p("div",{class:`${o.value}-menu-divider`})}}),Mo=Ne(st),Ho=Ne(mt),To=Ne(ut);function $e(e){return e.type==="divider"||e.type==="render"}function Bo(e){return e.type==="divider"}function Ee(e,o){const{rawNode:t}=e,{show:i}=t;if(i===!1)return null;if($e(t))return Bo(t)?p(Lo,Object.assign({key:e.key},t.props)):null;const{labelField:r}=o,{key:n,level:d,isGroup:u}=e,v=Object.assign(Object.assign({},t),{title:t.title||t[r],extra:t.titleExtra||t.extra,key:n,internalKey:n,level:d,root:d===0,isGroup:u});return e.children?e.isGroup?p(Po,be(v,Mo,{tmNode:e,tmNodes:e.children,key:n})):p(ke,be(v,To,{key:n,rawNodes:t[o.childrenField],tmNodes:e.children,tmNode:e})):p(Ao,be(v,Ho,{key:n,tmNode:e}))}const Xe=[b("&::before","background-color: var(--n-item-color-hover);"),k("arrow",`
 color: var(--n-arrow-color-hover);
 `),k("icon",`
 color: var(--n-item-icon-color-hover);
 `),y("menu-item-content-header",`
 color: var(--n-item-text-color-hover);
 `,[b("a",`
 color: var(--n-item-text-color-hover);
 `),k("extra",`
 color: var(--n-item-text-color-hover);
 `)])],Ze=[k("icon",`
 color: var(--n-item-icon-color-hover-horizontal);
 `),y("menu-item-content-header",`
 color: var(--n-item-text-color-hover-horizontal);
 `,[b("a",`
 color: var(--n-item-text-color-hover-horizontal);
 `),k("extra",`
 color: var(--n-item-text-color-hover-horizontal);
 `)])],Eo=b([y("menu",`
 background-color: var(--n-color);
 color: var(--n-item-text-color);
 overflow: hidden;
 transition: background-color .3s var(--n-bezier);
 box-sizing: border-box;
 font-size: var(--n-font-size);
 padding-bottom: 6px;
 `,[L("horizontal",`
 max-width: 100%;
 width: 100%;
 display: flex;
 overflow: hidden;
 padding-bottom: 0;
 `,[y("submenu","margin: 0;"),y("menu-item","margin: 0;"),y("menu-item-content",`
 padding: 0 20px;
 border-bottom: 2px solid #0000;
 `,[b("&::before","display: none;"),L("selected","border-bottom: 2px solid var(--n-border-color-horizontal)")]),y("menu-item-content",[L("selected",[k("icon","color: var(--n-item-icon-color-active-horizontal);"),y("menu-item-content-header",`
 color: var(--n-item-text-color-active-horizontal);
 `,[b("a","color: var(--n-item-text-color-active-horizontal);"),k("extra","color: var(--n-item-text-color-active-horizontal);")])]),L("child-active",`
 border-bottom: 2px solid var(--n-border-color-horizontal);
 `,[y("menu-item-content-header",`
 color: var(--n-item-text-color-child-active-horizontal);
 `,[b("a",`
 color: var(--n-item-text-color-child-active-horizontal);
 `),k("extra",`
 color: var(--n-item-text-color-child-active-horizontal);
 `)]),k("icon",`
 color: var(--n-item-icon-color-child-active-horizontal);
 `)]),re("disabled",[re("selected, child-active",[b("&:focus-within",Ze)]),L("selected",[Y(null,[k("icon","color: var(--n-item-icon-color-active-hover-horizontal);"),y("menu-item-content-header",`
 color: var(--n-item-text-color-active-hover-horizontal);
 `,[b("a","color: var(--n-item-text-color-active-hover-horizontal);"),k("extra","color: var(--n-item-text-color-active-hover-horizontal);")])])]),L("child-active",[Y(null,[k("icon","color: var(--n-item-icon-color-child-active-hover-horizontal);"),y("menu-item-content-header",`
 color: var(--n-item-text-color-child-active-hover-horizontal);
 `,[b("a","color: var(--n-item-text-color-child-active-hover-horizontal);"),k("extra","color: var(--n-item-text-color-child-active-hover-horizontal);")])])]),Y("border-bottom: 2px solid var(--n-border-color-horizontal);",Ze)]),y("menu-item-content-header",[b("a","color: var(--n-item-text-color-horizontal);")])])]),re("responsive",[y("menu-item-content-header",`
 overflow: hidden;
 text-overflow: ellipsis;
 `)]),L("collapsed",[y("menu-item-content",[L("selected",[b("&::before",`
 background-color: var(--n-item-color-active-collapsed) !important;
 `)]),y("menu-item-content-header","opacity: 0;"),k("arrow","opacity: 0;"),k("icon","color: var(--n-item-icon-color-collapsed);")])]),y("menu-item",`
 height: var(--n-item-height);
 margin-top: 6px;
 position: relative;
 `),y("menu-item-content",`
 box-sizing: border-box;
 line-height: 1.75;
 height: 100%;
 display: grid;
 grid-template-areas: "icon content arrow";
 grid-template-columns: auto 1fr auto;
 align-items: center;
 cursor: pointer;
 position: relative;
 padding-right: 18px;
 transition:
 background-color .3s var(--n-bezier),
 padding-left .3s var(--n-bezier),
 border-color .3s var(--n-bezier);
 `,[b("> *","z-index: 1;"),b("&::before",`
 z-index: auto;
 content: "";
 background-color: #0000;
 position: absolute;
 left: 8px;
 right: 8px;
 top: 0;
 bottom: 0;
 pointer-events: none;
 border-radius: var(--n-border-radius);
 transition: background-color .3s var(--n-bezier);
 `),L("disabled",`
 opacity: .45;
 cursor: not-allowed;
 `),L("collapsed",[k("arrow","transform: rotate(0);")]),L("selected",[b("&::before","background-color: var(--n-item-color-active);"),k("arrow","color: var(--n-arrow-color-active);"),k("icon","color: var(--n-item-icon-color-active);"),y("menu-item-content-header",`
 color: var(--n-item-text-color-active);
 `,[b("a","color: var(--n-item-text-color-active);"),k("extra","color: var(--n-item-text-color-active);")])]),L("child-active",[y("menu-item-content-header",`
 color: var(--n-item-text-color-child-active);
 `,[b("a",`
 color: var(--n-item-text-color-child-active);
 `),k("extra",`
 color: var(--n-item-text-color-child-active);
 `)]),k("arrow",`
 color: var(--n-arrow-color-child-active);
 `),k("icon",`
 color: var(--n-item-icon-color-child-active);
 `)]),re("disabled",[re("selected, child-active",[b("&:focus-within",Xe)]),L("selected",[Y(null,[k("arrow","color: var(--n-arrow-color-active-hover);"),k("icon","color: var(--n-item-icon-color-active-hover);"),y("menu-item-content-header",`
 color: var(--n-item-text-color-active-hover);
 `,[b("a","color: var(--n-item-text-color-active-hover);"),k("extra","color: var(--n-item-text-color-active-hover);")])])]),L("child-active",[Y(null,[k("arrow","color: var(--n-arrow-color-child-active-hover);"),k("icon","color: var(--n-item-icon-color-child-active-hover);"),y("menu-item-content-header",`
 color: var(--n-item-text-color-child-active-hover);
 `,[b("a","color: var(--n-item-text-color-child-active-hover);"),k("extra","color: var(--n-item-text-color-child-active-hover);")])])]),L("selected",[Y(null,[b("&::before","background-color: var(--n-item-color-active-hover);")])]),Y(null,Xe)]),k("icon",`
 grid-area: icon;
 color: var(--n-item-icon-color);
 transition:
 color .3s var(--n-bezier),
 font-size .3s var(--n-bezier),
 margin-right .3s var(--n-bezier);
 box-sizing: content-box;
 display: inline-flex;
 align-items: center;
 justify-content: center;
 `),k("arrow",`
 grid-area: arrow;
 font-size: 16px;
 color: var(--n-arrow-color);
 transform: rotate(180deg);
 opacity: 1;
 transition:
 color .3s var(--n-bezier),
 transform 0.2s var(--n-bezier),
 opacity 0.2s var(--n-bezier);
 `),y("menu-item-content-header",`
 grid-area: content;
 transition:
 color .3s var(--n-bezier),
 opacity .3s var(--n-bezier);
 opacity: 1;
 white-space: nowrap;
 color: var(--n-item-text-color);
 `,[b("a",`
 outline: none;
 text-decoration: none;
 transition: color .3s var(--n-bezier);
 color: var(--n-item-text-color);
 `,[b("&::before",`
 content: "";
 position: absolute;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 `)]),k("extra",`
 font-size: .93em;
 color: var(--n-group-text-color);
 transition: color .3s var(--n-bezier);
 `)])]),y("submenu",`
 cursor: pointer;
 position: relative;
 margin-top: 6px;
 `,[y("menu-item-content",`
 height: var(--n-item-height);
 `),y("submenu-children",`
 overflow: hidden;
 padding: 0;
 `,[Ft({duration:".2s"})])]),y("menu-item-group",[y("menu-item-group-title",`
 margin-top: 6px;
 color: var(--n-group-text-color);
 cursor: default;
 font-size: .93em;
 height: 36px;
 display: flex;
 align-items: center;
 transition:
 padding-left .3s var(--n-bezier),
 color .3s var(--n-bezier);
 `)])]),y("menu-tooltip",[b("a",`
 color: inherit;
 text-decoration: none;
 `)]),y("menu-divider",`
 transition: background-color .3s var(--n-bezier);
 background-color: var(--n-divider-color);
 height: 1px;
 margin: 6px 18px;
 `)]);function Y(e,o){return[L("hover",e,o),b("&:hover",e,o)]}const Oo=Object.assign(Object.assign({},ne.props),{options:{type:Array,default:()=>[]},collapsed:{type:Boolean,default:void 0},collapsedWidth:{type:Number,default:48},iconSize:{type:Number,default:20},collapsedIconSize:{type:Number,default:24},rootIndent:Number,indent:{type:Number,default:32},labelField:{type:String,default:"label"},keyField:{type:String,default:"key"},childrenField:{type:String,default:"children"},disabledField:{type:String,default:"disabled"},defaultExpandAll:Boolean,defaultExpandedKeys:Array,expandedKeys:Array,value:[String,Number],defaultValue:{type:[String,Number],default:null},mode:{type:String,default:"vertical"},watchProps:{type:Array,default:void 0},disabled:Boolean,show:{type:Boolean,default:!0},inverted:Boolean,"onUpdate:expandedKeys":[Function,Array],onUpdateExpandedKeys:[Function,Array],onUpdateValue:[Function,Array],"onUpdate:value":[Function,Array],expandIcon:Function,renderIcon:Function,renderLabel:Function,renderExtra:Function,dropdownProps:Object,accordion:Boolean,nodeProps:Function,dropdownPlacement:{type:String,default:"bottom"},responsive:Boolean,items:Array,onOpenNamesChange:[Function,Array],onSelect:[Function,Array],onExpandedNamesChange:[Function,Array],expandedNames:Array,defaultExpandedNames:Array}),Fo=K({name:"Menu",props:Oo,setup(e){const{mergedClsPrefixRef:o,inlineThemeDisabled:t}=Se(e),i=ne("Menu","-menu",Eo,Kt,e,o),r=q(so,null),n=S(()=>{var x;const{collapsed:N}=e;if(N!==void 0)return N;if(r){const{collapseModeRef:l,collapsedRef:I}=r;if(l.value==="width")return(x=I.value)!==null&&x!==void 0?x:!1}return!1}),d=S(()=>{const{keyField:x,childrenField:N,disabledField:l}=e;return xe(e.items||e.options,{getIgnored(I){return $e(I)},getChildren(I){return I[N]},getDisabled(I){return I[l]},getKey(I){var H;return(H=I[x])!==null&&H!==void 0?H:I.name}})}),u=S(()=>new Set(d.value.treeNodes.map(x=>x.key))),{watchProps:v}=e,g=A(null);v?.includes("defaultValue")?we(()=>{g.value=e.defaultValue}):g.value=e.defaultValue;const h=ee(e,"value"),c=qe(h,g),a=A([]),z=()=>{a.value=e.defaultExpandAll?d.value.getNonLeafKeys():e.defaultExpandedNames||e.defaultExpandedKeys||d.value.getPath(c.value,{includeSelf:!1}).keyPath};v?.includes("defaultExpandedKeys")?we(z):z();const s=vo(e,["expandedNames","expandedKeys"]),_=qe(s,a),C=S(()=>d.value.treeNodes),R=S(()=>d.value.getPath(c.value).keyPath);te(ie,{props:e,mergedCollapsedRef:n,mergedThemeRef:i,mergedValueRef:c,mergedExpandedKeysRef:_,activePathRef:R,mergedClsPrefixRef:o,isHorizontalRef:S(()=>e.mode==="horizontal"),invertedRef:ee(e,"inverted"),doSelect:O,toggleExpand:E});function O(x,N){const{"onUpdate:value":l,onUpdateValue:I,onSelect:H}=e;I&&G(I,x,N),l&&G(l,x,N),H&&G(H,x,N),g.value=x}function F(x){const{"onUpdate:expandedKeys":N,onUpdateExpandedKeys:l,onExpandedNamesChange:I,onOpenNamesChange:H}=e;N&&G(N,x),l&&G(l,x),I&&G(I,x),H&&G(H,x),a.value=x}function E(x){const N=Array.from(_.value),l=N.findIndex(I=>I===x);if(~l)N.splice(l,1);else{if(e.accordion&&u.value.has(x)){const I=N.findIndex(H=>u.value.has(H));I>-1&&N.splice(I,1)}N.push(x)}F(N)}const j=x=>{const N=d.value.getPath(x??c.value,{includeSelf:!1}).keyPath;if(!N.length)return;const l=Array.from(_.value),I=new Set([...l,...N]);e.accordion&&u.value.forEach(H=>{I.has(H)&&!N.includes(H)&&I.delete(H)}),F(Array.from(I))},ae=S(()=>{const{inverted:x}=e,{common:{cubicBezierEaseInOut:N},self:l}=i.value,{borderRadius:I,borderColorHorizontal:H,fontSize:wt,itemHeight:Ct,dividerColor:zt}=l,m={"--n-divider-color":zt,"--n-bezier":N,"--n-font-size":wt,"--n-border-color-horizontal":H,"--n-border-radius":I,"--n-item-height":Ct};return x?(m["--n-group-text-color"]=l.groupTextColorInverted,m["--n-color"]=l.colorInverted,m["--n-item-text-color"]=l.itemTextColorInverted,m["--n-item-text-color-hover"]=l.itemTextColorHoverInverted,m["--n-item-text-color-active"]=l.itemTextColorActiveInverted,m["--n-item-text-color-child-active"]=l.itemTextColorChildActiveInverted,m["--n-item-text-color-child-active-hover"]=l.itemTextColorChildActiveInverted,m["--n-item-text-color-active-hover"]=l.itemTextColorActiveHoverInverted,m["--n-item-icon-color"]=l.itemIconColorInverted,m["--n-item-icon-color-hover"]=l.itemIconColorHoverInverted,m["--n-item-icon-color-active"]=l.itemIconColorActiveInverted,m["--n-item-icon-color-active-hover"]=l.itemIconColorActiveHoverInverted,m["--n-item-icon-color-child-active"]=l.itemIconColorChildActiveInverted,m["--n-item-icon-color-child-active-hover"]=l.itemIconColorChildActiveHoverInverted,m["--n-item-icon-color-collapsed"]=l.itemIconColorCollapsedInverted,m["--n-item-text-color-horizontal"]=l.itemTextColorHorizontalInverted,m["--n-item-text-color-hover-horizontal"]=l.itemTextColorHoverHorizontalInverted,m["--n-item-text-color-active-horizontal"]=l.itemTextColorActiveHorizontalInverted,m["--n-item-text-color-child-active-horizontal"]=l.itemTextColorChildActiveHorizontalInverted,m["--n-item-text-color-child-active-hover-horizontal"]=l.itemTextColorChildActiveHoverHorizontalInverted,m["--n-item-text-color-active-hover-horizontal"]=l.itemTextColorActiveHoverHorizontalInverted,m["--n-item-icon-color-horizontal"]=l.itemIconColorHorizontalInverted,m["--n-item-icon-color-hover-horizontal"]=l.itemIconColorHoverHorizontalInverted,m["--n-item-icon-color-active-horizontal"]=l.itemIconColorActiveHorizontalInverted,m["--n-item-icon-color-active-hover-horizontal"]=l.itemIconColorActiveHoverHorizontalInverted,m["--n-item-icon-color-child-active-horizontal"]=l.itemIconColorChildActiveHorizontalInverted,m["--n-item-icon-color-child-active-hover-horizontal"]=l.itemIconColorChildActiveHoverHorizontalInverted,m["--n-arrow-color"]=l.arrowColorInverted,m["--n-arrow-color-hover"]=l.arrowColorHoverInverted,m["--n-arrow-color-active"]=l.arrowColorActiveInverted,m["--n-arrow-color-active-hover"]=l.arrowColorActiveHoverInverted,m["--n-arrow-color-child-active"]=l.arrowColorChildActiveInverted,m["--n-arrow-color-child-active-hover"]=l.arrowColorChildActiveHoverInverted,m["--n-item-color-hover"]=l.itemColorHoverInverted,m["--n-item-color-active"]=l.itemColorActiveInverted,m["--n-item-color-active-hover"]=l.itemColorActiveHoverInverted,m["--n-item-color-active-collapsed"]=l.itemColorActiveCollapsedInverted):(m["--n-group-text-color"]=l.groupTextColor,m["--n-color"]=l.color,m["--n-item-text-color"]=l.itemTextColor,m["--n-item-text-color-hover"]=l.itemTextColorHover,m["--n-item-text-color-active"]=l.itemTextColorActive,m["--n-item-text-color-child-active"]=l.itemTextColorChildActive,m["--n-item-text-color-child-active-hover"]=l.itemTextColorChildActiveHover,m["--n-item-text-color-active-hover"]=l.itemTextColorActiveHover,m["--n-item-icon-color"]=l.itemIconColor,m["--n-item-icon-color-hover"]=l.itemIconColorHover,m["--n-item-icon-color-active"]=l.itemIconColorActive,m["--n-item-icon-color-active-hover"]=l.itemIconColorActiveHover,m["--n-item-icon-color-child-active"]=l.itemIconColorChildActive,m["--n-item-icon-color-child-active-hover"]=l.itemIconColorChildActiveHover,m["--n-item-icon-color-collapsed"]=l.itemIconColorCollapsed,m["--n-item-text-color-horizontal"]=l.itemTextColorHorizontal,m["--n-item-text-color-hover-horizontal"]=l.itemTextColorHoverHorizontal,m["--n-item-text-color-active-horizontal"]=l.itemTextColorActiveHorizontal,m["--n-item-text-color-child-active-horizontal"]=l.itemTextColorChildActiveHorizontal,m["--n-item-text-color-child-active-hover-horizontal"]=l.itemTextColorChildActiveHoverHorizontal,m["--n-item-text-color-active-hover-horizontal"]=l.itemTextColorActiveHoverHorizontal,m["--n-item-icon-color-horizontal"]=l.itemIconColorHorizontal,m["--n-item-icon-color-hover-horizontal"]=l.itemIconColorHoverHorizontal,m["--n-item-icon-color-active-horizontal"]=l.itemIconColorActiveHorizontal,m["--n-item-icon-color-active-hover-horizontal"]=l.itemIconColorActiveHoverHorizontal,m["--n-item-icon-color-child-active-horizontal"]=l.itemIconColorChildActiveHorizontal,m["--n-item-icon-color-child-active-hover-horizontal"]=l.itemIconColorChildActiveHoverHorizontal,m["--n-arrow-color"]=l.arrowColor,m["--n-arrow-color-hover"]=l.arrowColorHover,m["--n-arrow-color-active"]=l.arrowColorActive,m["--n-arrow-color-active-hover"]=l.arrowColorActiveHover,m["--n-arrow-color-child-active"]=l.arrowColorChildActive,m["--n-arrow-color-child-active-hover"]=l.arrowColorChildActiveHover,m["--n-item-color-hover"]=l.itemColorHover,m["--n-item-color-active"]=l.itemColorActive,m["--n-item-color-active-hover"]=l.itemColorActiveHover,m["--n-item-color-active-collapsed"]=l.itemColorActiveCollapsed),m}),V=t?Re("menu",S(()=>e.inverted?"a":"b"),ae,e):void 0,ge=Vt(),Oe=A(null),vt=A(null);let Fe=!0;const Ke=()=>{var x;Fe?Fe=!1:(x=Oe.value)===null||x===void 0||x.sync({showAllItemsBeforeCalculate:!0})};function ft(){return document.getElementById(ge)}const le=A(-1);function pt(x){le.value=e.options.length-x}function _t(x){x||(le.value=-1)}const gt=S(()=>{const x=le.value;return{children:x===-1?[]:e.options.slice(x)}}),bt=S(()=>{const{childrenField:x,disabledField:N,keyField:l}=e;return xe([gt.value],{getIgnored(I){return $e(I)},getChildren(I){return I[x]},getDisabled(I){return I[N]},getKey(I){var H;return(H=I[l])!==null&&H!==void 0?H:I.name}})}),xt=S(()=>xe([{}]).treeNodes[0]);function yt(){var x;if(le.value===-1)return p(ke,{root:!0,level:0,key:"__ellpisisGroupPlaceholder__",internalKey:"__ellpisisGroupPlaceholder__",title:"···",tmNode:xt.value,domId:ge,isEllipsisPlaceholder:!0});const N=bt.value.treeNodes[0],l=R.value,I=!!(!((x=N.children)===null||x===void 0)&&x.some(H=>l.includes(H.key)));return p(ke,{level:0,root:!0,key:"__ellpisisGroup__",internalKey:"__ellpisisGroup__",title:"···",virtualChildActive:I,tmNode:N,domId:ge,rawNodes:N.rawNode.children||[],tmNodes:N.children||[],isEllipsisPlaceholder:!0})}return{mergedClsPrefix:o,controlledExpandedKeys:s,uncontrolledExpanededKeys:a,mergedExpandedKeys:_,uncontrolledValue:g,mergedValue:c,activePath:R,tmNodes:C,mergedTheme:i,mergedCollapsed:n,cssVars:t?void 0:ae,themeClass:V?.themeClass,overflowRef:Oe,counterRef:vt,updateCounter:()=>{},onResize:Ke,onUpdateOverflow:_t,onUpdateCount:pt,renderCounter:yt,getCounter:ft,onRender:V?.onRender,showOption:j,deriveResponsiveState:Ke}},render(){const{mergedClsPrefix:e,mode:o,themeClass:t,onRender:i}=this;i?.();const r=()=>this.tmNodes.map(v=>Ee(v,this.$props)),d=o==="horizontal"&&this.responsive,u=()=>p("div",{role:o==="horizontal"?"menubar":"menu",class:[`${e}-menu`,t,`${e}-menu--${o}`,d&&`${e}-menu--responsive`,this.mergedCollapsed&&`${e}-menu--collapsed`],style:this.cssVars},d?p(ao,{ref:"overflowRef",onUpdateOverflow:this.onUpdateOverflow,getCounter:this.getCounter,onUpdateCount:this.onUpdateCount,updateCounter:this.updateCounter,style:{width:"100%",display:"flex",overflow:"hidden"}},{default:r,counter:this.renderCounter}):r());return d?p(Dt,{onResize:this.onResize},{default:u}):u()}}),Ko={__name:"BreadCrumb",setup(e){const o=pe(),t=_e();function i(n){n!==t.path&&o.push(n)}function r(n){return n?.customIcon?tt(n.customIcon,{size:18}):n?.icon?U(n.icon,{size:18}):null}return(n,d)=>{const u=No,v=$o;return f(),M(v,null,{default:B(()=>[(f(!0),P(W,null,he(w(t).matched.filter(g=>!!g.meta?.title),g=>(f(),M(u,{key:g.path,onClick:h=>i(g.path)},{default:B(()=>[(f(),M(et(r(g.meta)))),J(" "+D(g.meta.title),1)]),_:2},1032,["onClick"]))),128))]),_:1})}}},Vo={class:"inline-block",viewBox:"0 0 24 24",width:"1em",height:"1em"},Do=$("path",{fill:"currentColor",d:"M11 13h10v-2H11m0-2h10V7H11M3 3v2h18V3M3 21h18v-2H3m0-7l4 4V8m4 9h10v-2H11z"},null,-1),jo=[Do];function Uo(e,o){return f(),P("svg",Vo,[...jo])}const Wo={name:"mdi-format-indent-decrease",render:Uo},qo={class:"inline-block",viewBox:"0 0 24 24",width:"1em",height:"1em"},Go=$("path",{fill:"currentColor",d:"M11 13h10v-2H11m0-2h10V7H11M3 3v2h18V3M11 17h10v-2H11M3 8v8l4-4m-4 9h18v-2H3z"},null,-1),Yo=[Go];function Xo(e,o){return f(),P("svg",qo,[...Yo])}const Zo={name:"mdi-format-indent-increase",render:Xo},Jo={__name:"MenuCollapse",setup(e){const o=X();return(t,i)=>{const r=Zo,n=Wo,d=Pe;return f(),M(d,{size:"20","cursor-pointer":"",onClick:w(o).switchCollapsed},{default:B(()=>[w(o).collapsed?(f(),M(r,{key:0})):(f(),M(n,{key:1}))]),_:1},8,["onClick"])}}},Qo={class:"inline-block",viewBox:"0 0 1024 1024",width:"1em",height:"1em"},en=$("path",{fill:"currentColor",d:"m290 236.4l43.9-43.9a8.01 8.01 0 0 0-4.7-13.6L169 160c-5.1-.6-9.5 3.7-8.9 8.9L179 329.1c.8 6.6 8.9 9.4 13.6 4.7l43.7-43.7L370 423.7c3.1 3.1 8.2 3.1 11.3 0l42.4-42.3c3.1-3.1 3.1-8.2 0-11.3zm352.7 187.3c3.1 3.1 8.2 3.1 11.3 0l133.7-133.6l43.7 43.7a8.01 8.01 0 0 0 13.6-4.7L863.9 169c.6-5.1-3.7-9.5-8.9-8.9L694.8 179c-6.6.8-9.4 8.9-4.7 13.6l43.9 43.9L600.3 370a8.03 8.03 0 0 0 0 11.3zM845 694.9c-.8-6.6-8.9-9.4-13.6-4.7l-43.7 43.7L654 600.3a8.03 8.03 0 0 0-11.3 0l-42.4 42.3a8.03 8.03 0 0 0 0 11.3L734 787.6l-43.9 43.9a8.01 8.01 0 0 0 4.7 13.6L855 864c5.1.6 9.5-3.7 8.9-8.9zm-463.7-94.6a8.03 8.03 0 0 0-11.3 0L236.3 733.9l-43.7-43.7a8.01 8.01 0 0 0-13.6 4.7L160.1 855c-.6 5.1 3.7 9.5 8.9 8.9L329.2 845c6.6-.8 9.4-8.9 4.7-13.6L290 787.6L423.7 654c3.1-3.1 3.1-8.2 0-11.3z"},null,-1),tn=[en];function on(e,o){return f(),P("svg",Qo,[...tn])}const nn={name:"ant-design-fullscreen-outlined",render:on},rn={class:"inline-block",viewBox:"0 0 1024 1024",width:"1em",height:"1em"},an=$("path",{fill:"currentColor",d:"M391 240.9c-.8-6.6-8.9-9.4-13.6-4.7l-43.7 43.7L200 146.3a8.03 8.03 0 0 0-11.3 0l-42.4 42.3a8.03 8.03 0 0 0 0 11.3L280 333.6l-43.9 43.9a8.01 8.01 0 0 0 4.7 13.6L401 410c5.1.6 9.5-3.7 8.9-8.9zm10.1 373.2L240.8 633c-6.6.8-9.4 8.9-4.7 13.6l43.9 43.9L146.3 824a8.03 8.03 0 0 0 0 11.3l42.4 42.3c3.1 3.1 8.2 3.1 11.3 0L333.7 744l43.7 43.7A8.01 8.01 0 0 0 391 783l18.9-160.1c.6-5.1-3.7-9.4-8.8-8.8m221.8-204.2L783.2 391c6.6-.8 9.4-8.9 4.7-13.6L744 333.6L877.7 200c3.1-3.1 3.1-8.2 0-11.3l-42.4-42.3a8.03 8.03 0 0 0-11.3 0L690.3 279.9l-43.7-43.7a8.01 8.01 0 0 0-13.6 4.7L614.1 401c-.6 5.2 3.7 9.5 8.8 8.9M744 690.4l43.9-43.9a8.01 8.01 0 0 0-4.7-13.6L623 614c-5.1-.6-9.5 3.7-8.9 8.9L633 783.1c.8 6.6 8.9 9.4 13.6 4.7l43.7-43.7L824 877.7c3.1 3.1 8.2 3.1 11.3 0l42.4-42.3c3.1-3.1 3.1-8.2 0-11.3z"},null,-1),ln=[an];function cn(e,o){return f(),P("svg",rn,[...ln])}const sn={name:"ant-design-fullscreen-exit-outlined",render:cn},dn={__name:"FullScreen",setup(e){const o=X(),{isFullscreen:t,toggle:i}=jt();return(r,n)=>{const d=sn,u=nn,v=Pe;return w(o).fullScreen?(f(),M(v,{key:0,mr20:"",size:"18",style:{cursor:"pointer"},onClick:w(i)},{default:B(()=>[w(t)?(f(),M(d,{key:0})):(f(),M(u,{key:1}))]),_:1},8,["onClick"])):oe("",!0)}}},un={flex:"","cursor-pointer":"","items-center":""},mn={__name:"UserAvatar",setup(e){const{t:o}=Ut(),t=pe(),i=Wt(),r=[{label:o("header.label_profile"),key:"profile",icon:U("mdi-account-arrow-right-outline",{size:"14px"})},{label:o("header.label_logout"),key:"logout",icon:U("mdi:exit-to-app",{size:"14px"})}];function n(d){d==="profile"?t.push("/profile"):d==="logout"&&$dialog.confirm({title:o("header.label_logout_dialog_title"),type:"warning",content:o("header.text_logout_confirm"),confirm(){i.logout(),$message.success("您已安全退出登录")}})}return(d,u)=>{const v=Ae;return f(),M(v,{options:r,onSelect:n},{default:B(()=>[$("div",un,[$("span",null,D(w(i).name),1)])]),_:1})}}},hn={class:"inline-block",viewBox:"0 0 24 24",width:"1em",height:"1em"},vn=$("path",{fill:"currentColor",d:"m3.55 19.09l1.41 1.41l1.8-1.79l-1.42-1.42M12 6c-3.31 0-6 2.69-6 6s2.69 6 6 6s6-2.69 6-6c0-3.32-2.69-6-6-6m8 7h3v-2h-3m-2.76 7.71l1.8 1.79l1.41-1.41l-1.79-1.8M20.45 5l-1.41-1.4l-1.8 1.79l1.42 1.42M13 1h-2v3h2M6.76 5.39L4.96 3.6L3.55 5l1.79 1.81zM1 13h3v-2H1m12 9h-2v3h2"},null,-1),fn=[vn];function pn(e,o){return f(),P("svg",hn,[...fn])}const _n={name:"mdi-white-balance-sunny",render:pn},gn={class:"inline-block",viewBox:"0 0 24 24",width:"1em",height:"1em"},bn=$("path",{fill:"currentColor",d:"M2 12a10 10 0 0 0 13 9.54a10 10 0 0 1 0-19.08A10 10 0 0 0 2 12"},null,-1),xn=[bn];function yn(e,o){return f(),P("svg",gn,[...xn])}const wn={name:"mdi-moon-waning-crescent",render:yn},Cn={__name:"ThemeMode",setup(e){const o=X(),t=qt(),i=()=>{o.toggleDark(),Gt(t)()};return(r,n)=>{const d=wn,u=_n,v=Pe;return f(),M(v,{"mr-20":"","cursor-pointer":"",size:"18",onClick:i},{default:B(()=>[w(t)?(f(),M(d,{key:0})):(f(),M(u,{key:1}))]),_:1})}}},zn={class:"inline-block",viewBox:"0 0 24 24",width:"1em",height:"1em"},In=$("path",{fill:"currentColor",d:"M10 21h4c0 1.1-.9 2-2 2s-2-.9-2-2m11-2v1H3v-1l2-2v-6c0-3.1 2-5.8 5-6.7V4c0-1.1.9-2 2-2s2 .9 2 2v.3c3 .9 5 3.6 5 6.7v6zm-4-8c0-2.8-2.2-5-5-5s-5 2.2-5 5v7h10z"},null,-1),kn=[In];function $n(e,o){return f(),P("svg",zn,[...kn])}const Sn={name:"mdi-bell-outline",render:$n};const ht=e=>(Xt("data-v-a39f80fa"),e=e(),Zt(),e),Rn={class:"notice-panel"},Nn={class:"notice-head"},Pn=ht(()=>$("strong",null,"消息通知",-1)),An={key:0,class:"notice-loading"},Ln={key:1,class:"notice-empty"},Mn={key:2,class:"notice-list"},Hn={class:"notice-item-head"},Tn={class:"notice-title"},Bn=["innerHTML"],En={class:"notice-preview-shell"},On={class:"notice-preview-list"},Fn=ht(()=>$("div",{class:"notice-preview-head"},"最近10条",-1)),Kn=["onClick"],Vn={class:"preview-item-title"},Dn={class:"preview-item-time"},jn={key:0,class:"notice-preview-detail"},Un={class:"preview-detail-head"},Wn={class:"preview-detail-time"},qn={class:"preview-detail-actions"},Gn=["innerHTML"],Yn={key:1,class:"notice-empty"},Xn={__name:"NoticeBell",setup(e){const o=A(0),t=A([]),i=A(!1),r=A(!1),n=A(null);async function d(){const c=await se.getNoticeUnreadCount();o.value=Number(c?.data?.unread_count||0)}async function u(){try{i.value=!0;const c=await se.getNoticeInbox({page:1,page_size:10});t.value=Array.isArray(c?.data)?c.data:[]}finally{i.value=!1}}function v(c){n.value=c}async function g(c){await se.readNotice({notice_id:c}),await Promise.all([d(),u()]),n.value&&n.value.notice_id===c&&(n.value.is_read=!0)}async function h(){await se.readAllNotice(),await Promise.all([d(),u()]),n.value&&(n.value.is_read=!0)}return ve(async()=>{if(await Promise.all([d(),u()]),o.value>0&&t.value.length){const c=t.value.find(a=>!a.is_read);n.value=c||t.value[0],r.value=!0}}),(c,a)=>{const z=Sn;return f(),P(W,null,[T(w(lo),{trigger:"click",placement:"bottom-end",width:420},{trigger:B(()=>[T(w(zo),{value:o.value,max:99,show:o.value>0},{default:B(()=>[T(w(ce),{quaternary:"",circle:""},{icon:B(()=>[T(z)]),_:1})]),_:1},8,["value","show"])]),default:B(()=>[$("div",Rn,[$("div",Nn,[Pn,T(w(ce),{text:"",size:"small",onClick:h},{default:B(()=>[J("全部已读")]),_:1})]),i.value?(f(),P("div",An,"加载中...")):t.value.length?(f(),P("div",Mn,[(f(!0),P(W,null,he(t.value,s=>(f(),P("div",{key:s.notice_id,class:Ce(["notice-item",{unread:!s.is_read}])},[$("div",Hn,[$("span",Tn,D(s.title||"系统通知"),1),s.is_read?oe("",!0):(f(),M(w(ce),{key:0,text:"",size:"tiny",onClick:_=>g(s.notice_id)},{default:B(()=>[J("已读")]),_:2},1032,["onClick"]))]),$("div",{class:"notice-content",innerHTML:w(We)(s.content_html||"")},null,8,Bn)],2))),128))])):(f(),P("div",Ln,"暂无通知"))])]),_:1}),T(w(Yt),{show:r.value,"onUpdate:show":a[1]||(a[1]=s=>r.value=s),preset:"card",title:"最新通知",style:{width:"840px"},"mask-closable":!0},{default:B(()=>[$("div",En,[$("div",On,[Fn,(f(!0),P(W,null,he(t.value,s=>(f(),P("div",{key:`preview-${s.notice_id}`,class:Ce(["notice-preview-item",{active:n.value?.notice_id===s.notice_id,unread:!s.is_read}]),onClick:_=>v(s)},[$("div",Vn,D(s.title||"系统通知"),1),$("div",Dn,D(s.created_at||"-"),1)],10,Kn))),128))]),n.value?(f(),P("div",jn,[$("div",Un,[$("div",null,[$("h3",null,D(n.value.title||"系统通知"),1),$("div",Wn,D(n.value.created_at||"-"),1)]),$("div",qn,[T(w(lt),{type:n.value.is_read?"default":"warning"},{default:B(()=>[J(D(n.value.is_read?"已读":"未读"),1)]),_:1},8,["type"]),n.value.is_read?oe("",!0):(f(),M(w(ce),{key:0,size:"small",type:"primary",ghost:"",onClick:a[0]||(a[0]=s=>g(n.value.notice_id))},{default:B(()=>[J("标记已读")]),_:1}))])]),$("div",{class:"preview-detail-content",innerHTML:w(We)(n.value.content_html||"")},null,8,Gn)])):(f(),P("div",Yn,"暂无通知"))])]),_:1},8,["show"])],64)}}},Zn=Le(Xn,[["__scopeId","data-v-a39f80fa"]]),Jn={flex:"","items-center":""},Qn={"ml-auto":"",flex:"","items-center":""},er={__name:"index",setup(e){return(o,t)=>(f(),P(W,null,[$("div",Jn,[T(Jo),T(Ko,{"ml-15":"",hidden:"","sm:block":""})]),$("div",Qn,[T(Cn),T(Zn),T(dn),T(mn)])],64))}},tr=["src"],or={__name:"SideLogo",setup(e){const o="安得和众用户服务中心",t=X();return(i,r)=>{const n=co,d=ot("router-link");return f(),M(d,{"h-60":"","f-c-c":"",to:"/"},{default:B(()=>[w(t).siteLogo?(f(),P("img",{key:0,src:w(t).siteLogo,alt:"logo",style:{height:"36px",width:"36px"}},null,8,tr)):(f(),M(n,{key:1,"text-36":"","color-primary":""})),nt($("h2",{"ml-2":"","mr-8":"","max-w-220":"","flex-shrink-0":"","text-14":"","font-bold":"","color-primary":"","whitespace-nowrap":"","overflow-hidden":"","text-ellipsis":""},D(w(t).siteTitle||w(o)),513),[[Jt,!w(t).collapsed]])]),_:1})}}};const nr={__name:"SideMenu",setup(e){const o=pe(),t=_e(),i=rt();X();const r=S(()=>t.meta?.activeMenu||t.name),n=S(()=>i.menus.map(h=>u(h)).sort((h,c)=>h.order-c.order));function d(h,c){return De(c)?c:"/"+[h,c].filter(a=>!!a&&a!=="/").map(a=>a.replace(/(^\/)|(\/$)/g,"")).join("/")}function u(h,c=""){let a={label:h.meta&&h.meta.title||h.name,key:h.name,path:d(c,h.path),icon:v(h.meta),order:h.meta?.order||0};const z=h.children?h.children.filter(s=>s.name&&!s.isHidden):[];if(!z.length)return a;if(z.length===1){const s=z[0];a={...a,label:s.meta?.title||s.name,key:s.name,path:d(a.path,s.path),icon:v(s.meta)};const _=s.children?s.children.filter(C=>C.name&&!C.isHidden):[];_.length===1?a=u(_[0],a.path):_.length>1&&(a.children=_.map(C=>u(C,a.path)).sort((C,R)=>C.order-R.order))}else a.children=z.map(s=>u(s,a.path)).sort((s,_)=>s.order-_.order),h.redirect&&(a.path=h.redirect);return a}function v(h){return h?.customIcon?tt(h.customIcon,{size:18}):h?.icon?U(h.icon,{size:18}):null}function g(h,c){if(c?.path)if(De(c.path))window.open(c.path);else{if(c.path===t.path)return;o.push(c.path).catch(a=>{console.warn("[SideMenu] router.push failed",a)})}}return(h,c)=>{const a=Fo;return f(),M(a,{ref:"menu",class:"side-menu",accordion:"",indent:18,"collapsed-icon-size":22,"collapsed-width":64,options:w(n),value:w(r),"onUpdate:value":g},null,8,["options","value"])}}},rr={__name:"index",setup(e){return(o,t)=>(f(),P(W,null,[T(or),T(nr)],64))}},ir={};function ar(e,o){const t=ot("router-view");return f(),M(t,null,{default:B(({Component:i,route:r})=>[(f(),M(et(i),{key:r.fullPath}))]),_:1})}const lr=Le(ir,[["render",ar]]),cr={__name:"ContextMenu",props:{show:{type:Boolean,default:!1},currentPath:{type:String,default:""},x:{type:Number,default:0},y:{type:Number,default:0}},emits:["update:show"],setup(e,{emit:o}){const t=e,i=o,r=it(),n=X(),d=S(()=>[{label:"重新加载",key:"reload",disabled:t.currentPath!==r.activeTag,icon:U("mdi:refresh",{size:"14px"})},{label:"关闭",key:"close",disabled:r.tags.length<=1,icon:U("mdi:close",{size:"14px"})},{label:"关闭其他",key:"close-other",disabled:r.tags.length<=1,icon:U("mdi:arrow-expand-horizontal",{size:"14px"})},{label:"关闭左侧",key:"close-left",disabled:r.tags.length<=1||t.currentPath===r.tags[0].path,icon:U("mdi:arrow-expand-left",{size:"14px"})},{label:"关闭右侧",key:"close-right",disabled:r.tags.length<=1||t.currentPath===r.tags[r.tags.length-1].path,icon:U("mdi:arrow-expand-right",{size:"14px"})}]),u=_e(),v=new Map([["reload",()=>{u.meta?.keepAlive&&n.setAliveKeys(u.name,+new Date),n.reloadPage()}],["close",()=>{r.removeTag(t.currentPath)}],["close-other",()=>{r.removeOther(t.currentPath)}],["close-left",()=>{r.removeLeft(t.currentPath)}],["close-right",()=>{r.removeRight(t.currentPath)}]]);function g(){i("update:show",!1)}function h(c){const a=v.get(c);a&&a(),g()}return(c,a)=>{const z=Ae;return f(),M(z,{show:e.show,options:w(d),x:e.x,y:e.y,placement:"bottom-start",onClickoutside:g,onSelect:h},null,8,["show","options","x","y"])}}},sr={class:"inline-block",viewBox:"0 0 24 24",width:"1em",height:"1em"},dr=$("path",{fill:"currentColor",d:"M8.59 16.59L13.17 12L8.59 7.41L10 6l6 6l-6 6z"},null,-1),ur=[dr];function mr(e,o){return f(),P("svg",sr,[...ur])}const hr={name:"ic-baseline-keyboard-arrow-right",render:mr},vr={class:"inline-block",viewBox:"0 0 24 24",width:"1em",height:"1em"},fr=$("path",{fill:"currentColor",d:"M15.41 16.59L10.83 12l4.58-4.59L14 6l-6 6l6 6z"},null,-1),pr=[fr];function _r(e,o){return f(),P("svg",vr,[...pr])}const gr={name:"ic-baseline-keyboard-arrow-left",render:_r};const br={__name:"ScrollX",props:{showArrow:{type:Boolean,default:!0}},setup(e,{expose:o}){const t=A(0),i=A(null),r=A(null),n=A(!1),d=Ge(()=>{const c=r.value?.offsetWidth,a=i.value?.offsetWidth;n.value=a>c,v(c,a)},200);function u(c){const{wheelDelta:a}=c,z=r.value?.offsetWidth,s=i.value?.offsetWidth;a<0&&(z>s&&t.value<-10||z<=s&&s+t.value-z<-10)||a>0&&t.value>10||(t.value+=a,v(z,s))}const v=Ge(function(c,a){n.value?-t.value>a-c?t.value=c-a:t.value>0&&(t.value=0):t.value=0},200),g=A(null);ve(()=>{d(),g.value=Qt(document.body,d)}),eo(()=>{g.value?.disconnect()});function h(c,a){const z=r.value?.offsetWidth,s=i.value?.offsetWidth;s<=z||(c<-t.value+150&&(t.value=-(c-150),v(z,s)),c+a>-t.value+z&&(t.value=z-(c+a),v(z,s)))}return o({handleScroll:h}),(c,a)=>{const z=gr,s=hr,_=to("resize");return f(),P("div",{ref_key:"wrapper",ref:r,class:"wrapper",onMousewheel:Ie(u,["prevent"])},[e.showArrow&&w(n)?(f(),P(W,{key:0},[$("div",{class:"left",onClick:a[0]||(a[0]=C=>u({wheelDelta:120}))},[T(z)]),$("div",{class:"right",onClick:a[1]||(a[1]=C=>u({wheelDelta:-120}))},[T(s)])],64)):oe("",!0),nt((f(),P("div",{ref_key:"content",ref:i,class:Ce(["content",{overflow:w(n)&&e.showArrow}]),style:ze({transform:`translateX(${w(t)}px)`})},[oo(c.$slots,"default",{},void 0,!0)],6)),[[_,w(d)]])],544)}}},xr=Le(br,[["__scopeId","data-v-235998f9"]]);const yr={__name:"index",setup(e){const o=_e(),t=pe(),i=it(),r=rt(),n=A([]),d=A(null),u=at({show:!1,x:0,y:0,currentPath:""});(()=>{const s=i.tags.filter(_=>!je.includes(_.path));s.length!==i.tags.length&&i.setTags(s)})(),ue(()=>o.path,()=>{const{name:s,fullPath:_}=o,C=o.meta?.title,R=(F=[],E=[])=>(F.forEach(j=>{j?.path&&E.push(j.path),Array.isArray(j?.children)&&j.children.length&&R(j.children,E)}),E);new Set(R(r.menus||[]).filter(F=>!je.includes(F))).has(_)&&i.addTag({name:s,path:_,title:C})},{immediate:!0}),ue(()=>i.activeIndex,async s=>{await me();const _=n.value[s]?.$el;if(!_)return;const{offsetLeft:C,offsetWidth:R}=_;d.value?.handleScroll(C+R,R)},{immediate:!0});const g=s=>{const _=(O=[],F=[])=>(O.forEach(E=>{E?.path&&F.push(E.path),Array.isArray(E?.children)&&E.children.length&&_(E.children,F)}),F);if(![...new Set(_(r.menus||[]))].includes(s)){$message.warning("当前账号无该页面权限，无法打开");return}i.setActiveTag(s),t.push(s)};function h(){u.show=!0}function c(){u.show=!1}function a(s,_,C){Object.assign(u,{x:s,y:_,currentPath:C})}async function z(s,_){const{clientX:C,clientY:R}=s;c(),a(C,R,_.path),await me(),h()}return(s,_)=>{const C=lt;return f(),M(xr,{ref_key:"scrollXRef",ref:d,class:"bg-white dark:bg-dark!"},{default:B(()=>[(f(!0),P(W,null,he(w(i).tags,R=>(f(),M(C,{ref_for:!0,ref_key:"tabRefs",ref:n,key:R.path,class:"mx-5 cursor-pointer rounded-4 px-15 hover:color-primary",type:w(i).activeTag===R.path?"primary":"default",closable:w(i).tags.length>1,onClick:O=>g(R.path),onClose:Ie(O=>w(i).removeTag(R.path),["stop"]),onContextmenu:Ie(O=>z(O,R),["prevent"])},{default:B(()=>[J(D(R.title),1)]),_:2},1032,["type","closable","onClick","onClose","onContextmenu"]))),128)),w(u).show?(f(),M(cr,{key:0,show:w(u).show,"onUpdate:show":_[0]||(_[0]=R=>w(u).show=R),"current-path":w(u).currentPath,x:w(u).x,y:w(u).y},null,8,["show","current-path","x","y"])):oe("",!0)]),_:1},512)}}},wr={"flex-col":"","flex-1":"","overflow-hidden":""},Cr={key:0,hidden:"","border-b":"","bc-eee":"","sm:block":"","dark:border-0":""},zr={"flex-1":"","overflow-hidden":"","bg-hex-f5f6fb":"","dark:bg-hex-101014":""},Or={__name:"index",setup(e){const o=X(),i=at(no({xl:1600,lg:1199,md:991,sm:666,xs:575})),r=i.smaller("sm"),n=i.between("sm","md"),d=i.greater("md");return we(()=>{r.value&&(o.setCollapsed(!0),o.setFullScreen(!1)),n.value&&(o.setCollapsed(!0),o.setFullScreen(!1)),d.value&&(o.setCollapsed(!1),o.setFullScreen(!0))}),(u,v)=>{const g=uo,h=mo;return f(),M(h,{"has-sider":"","wh-full":""},{default:B(()=>[T(g,{bordered:"","collapse-mode":"width","collapsed-width":64,width:220,"native-scrollbar":!1,collapsed:w(o).collapsed},{default:B(()=>[T(rr)]),_:1},8,["collapsed"]),$("article",wr,[$("header",{class:"flex items-center border-b bg-white px-15 bc-eee",dark:"bg-dark border-0",style:ze(`height: ${w(ro).height}px`)},[T(er)],4),w(Ue).visible?(f(),P("section",Cr,[T(yr,{style:ze({height:`${w(Ue).height}px`})},null,8,["style"])])):oe("",!0),$("section",zr,[T(lr)])])]),_:1})}}};export{Or as default};
