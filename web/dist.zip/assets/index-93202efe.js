var Rt=Object.defineProperty,Pt=Object.defineProperties;var At=Object.getOwnPropertyDescriptors;var De=Object.getOwnPropertySymbols;var Lt=Object.prototype.hasOwnProperty,Mt=Object.prototype.propertyIsEnumerable;var je=(e,o,t)=>o in e?Rt(e,o,{enumerable:!0,configurable:!0,writable:!0,value:t}):e[o]=t,Ue=(e,o)=>{for(var t in o||(o={}))Lt.call(o,t)&&je(e,t,o[t]);if(De)for(var t of De(o))Mt.call(o,t)&&je(e,t,o[t]);return e},We=(e,o)=>Pt(e,At(o));var q=(e,o,t)=>new Promise((i,r)=>{var n=m=>{try{s(t.next(m))}catch(_){r(_)}},d=m=>{try{s(t.throw(m))}catch(_){r(_)}},s=m=>m.done?i(m.value):Promise.resolve(m.value).then(n,d);s((t=t.apply(e,o)).next())});import{d as V,h as b,r as A,c as N,w as me,n as he,t as oe,a as x,b as Ht,e as w,f as Tt,g as L,i as $,u as Bt,N as nt,T as Et,j as Ot,k as qe,l as Ne,m as ie,o as Ft,p as fe,q as Kt,s as Vt,v as Re,x as Dt,y as jt,z as rt,A as Ut,B as Wt,C as ne,D as pe,E as qt,F as Gt,G,H as te,I as W,J as Yt,K as we,L as xe,M as Pe,O as ae,P as Xt,Q as Zt,R as Ce,S as X,U as Jt,V as Qt,W as _e,X as ge,Y as g,Z as H,_ as E,$ as P,a0 as ve,a1 as C,a2 as it,a3 as ee,a4 as j,a5 as S,a6 as J,a7 as eo,a8 as re,a9 as to,aa as oo,ab as no,ac as ro,ad as B,ae as se,af as ze,ag as io,ah as de,ai as ao,aj as lo,ak as at,al as lt,am as co,an as ct,ao as Ge,ap as st,aq as so,ar as uo,as as mo,at as Ie,au as ho,av as ke,aw as dt,ax as Ye,ay as vo,az as fo,aA as Xe}from"./index-77ac7330.js";import{r as ut,a as U}from"./icon-e8d03465.js";import{N as Ae}from"./Icon-119b9156.js";import{N as Le}from"./Dropdown-197b1e27.js";import{s as Ze}from"./sanitize-77706078.js";import{_ as Me}from"./_plugin-vue_export-helper-f253986a.js";import{g as po,c as ye,V as _o}from"./create-ea43bba2.js";import{N as go}from"./Popover-9c38d3b6.js";import{N as mt}from"./Tag-c279a17e.js";import{_ as bo}from"./logo-f1178aa9.js";import{l as xo,N as yo,a as wo}from"./LayoutSider-361f7ac2.js";import{N as Co}from"./Tooltip-d9e921e9.js";import{u as Je}from"./use-merged-state-85348d68.js";import{u as zo}from"./use-compitable-c5642804.js";import{d as Qe}from"./common-bc9c6ece.js";import"./get-dbe2fea6.js";const Io=V({name:"ChevronDownFilled",render(){return b("svg",{viewBox:"0 0 16 16",fill:"none",xmlns:"http://www.w3.org/2000/svg"},b("path",{d:"M3.20041 5.73966C3.48226 5.43613 3.95681 5.41856 4.26034 5.70041L8 9.22652L11.7397 5.70041C12.0432 5.41856 12.5177 5.43613 12.7996 5.73966C13.0815 6.0432 13.0639 6.51775 12.7603 6.7996L8.51034 10.7996C8.22258 11.0668 7.77743 11.0668 7.48967 10.7996L3.23966 6.7996C2.93613 6.51775 2.91856 6.0432 3.20041 5.73966Z",fill:"currentColor"}))}}),et=V({name:"SlotMachineNumber",props:{clsPrefix:{type:String,required:!0},value:{type:[Number,String],required:!0},oldOriginalNumber:{type:Number,default:void 0},newOriginalNumber:{type:Number,default:void 0}},setup(e){const o=A(null),t=A(e.value),i=A(e.value),r=A("up"),n=A(!1),d=N(()=>n.value?`${e.clsPrefix}-base-slot-machine-current-number--${r.value}-scroll`:null),s=N(()=>n.value?`${e.clsPrefix}-base-slot-machine-old-number--${r.value}-scroll`:null);me(oe(e,"value"),(u,c)=>{t.value=c,i.value=u,he(m)});function m(){const u=e.newOriginalNumber,c=e.oldOriginalNumber;c===void 0||u===void 0||(u>c?_("up"):c>u&&_("down"))}function _(u){r.value=u,n.value=!1,he(()=>{var c;(c=o.value)===null||c===void 0||c.offsetWidth,n.value=!0})}return()=>{const{clsPrefix:u}=e;return b("span",{ref:o,class:`${u}-base-slot-machine-number`},t.value!==null?b("span",{class:[`${u}-base-slot-machine-old-number ${u}-base-slot-machine-old-number--top`,s.value]},t.value):null,b("span",{class:[`${u}-base-slot-machine-current-number`,d.value]},b("span",{ref:"numberWrapper",class:[`${u}-base-slot-machine-current-number__inner`,typeof e.value!="number"&&`${u}-base-slot-machine-current-number__inner--not-number`]},i.value)),t.value!==null?b("span",{class:[`${u}-base-slot-machine-old-number ${u}-base-slot-machine-old-number--bottom`,s.value]},t.value):null)}}}),{cubicBezierEaseOut:Q}=Ht;function ko({duration:e=".2s"}={}){return[x("&.fade-up-width-expand-transition-leave-active",{transition:`
 opacity ${e} ${Q},
 max-width ${e} ${Q},
 transform ${e} ${Q}
 `}),x("&.fade-up-width-expand-transition-enter-active",{transition:`
 opacity ${e} ${Q},
 max-width ${e} ${Q},
 transform ${e} ${Q}
 `}),x("&.fade-up-width-expand-transition-enter-to",{opacity:1,transform:"translateX(0) translateY(0)"}),x("&.fade-up-width-expand-transition-enter-from",{maxWidth:"0 !important",opacity:0,transform:"translateY(60%)"}),x("&.fade-up-width-expand-transition-leave-from",{opacity:1,transform:"translateY(0)"}),x("&.fade-up-width-expand-transition-leave-to",{maxWidth:"0 !important",opacity:0,transform:"translateY(60%)"})]}const $o=x([x("@keyframes n-base-slot-machine-fade-up-in",`
 from {
 transform: translateY(60%);
 opacity: 0;
 }
 to {
 transform: translateY(0);
 opacity: 1;
 }
 `),x("@keyframes n-base-slot-machine-fade-down-in",`
 from {
 transform: translateY(-60%);
 opacity: 0;
 }
 to {
 transform: translateY(0);
 opacity: 1;
 }
 `),x("@keyframes n-base-slot-machine-fade-up-out",`
 from {
 transform: translateY(0%);
 opacity: 1;
 }
 to {
 transform: translateY(-60%);
 opacity: 0;
 }
 `),x("@keyframes n-base-slot-machine-fade-down-out",`
 from {
 transform: translateY(0%);
 opacity: 1;
 }
 to {
 transform: translateY(60%);
 opacity: 0;
 }
 `),w("base-slot-machine",`
 overflow: hidden;
 white-space: nowrap;
 display: inline-block;
 height: 18px;
 line-height: 18px;
 `,[w("base-slot-machine-number",`
 display: inline-block;
 position: relative;
 height: 18px;
 width: .6em;
 max-width: .6em;
 `,[ko({duration:".2s"}),Tt({duration:".2s",delay:"0s"}),w("base-slot-machine-old-number",`
 display: inline-block;
 opacity: 0;
 position: absolute;
 left: 0;
 right: 0;
 `,[L("top",{transform:"translateY(-100%)"}),L("bottom",{transform:"translateY(100%)"}),L("down-scroll",{animation:"n-base-slot-machine-fade-down-out .2s cubic-bezier(0, 0, .2, 1)",animationIterationCount:1}),L("up-scroll",{animation:"n-base-slot-machine-fade-up-out .2s cubic-bezier(0, 0, .2, 1)",animationIterationCount:1})]),w("base-slot-machine-current-number",`
 display: inline-block;
 position: absolute;
 left: 0;
 top: 0;
 bottom: 0;
 right: 0;
 opacity: 1;
 transform: translateY(0);
 width: .6em;
 `,[L("down-scroll",{animation:"n-base-slot-machine-fade-down-in .2s cubic-bezier(0, 0, .2, 1)",animationIterationCount:1}),L("up-scroll",{animation:"n-base-slot-machine-fade-up-in .2s cubic-bezier(0, 0, .2, 1)",animationIterationCount:1}),$("inner",`
 display: inline-block;
 position: absolute;
 right: 0;
 top: 0;
 width: .6em;
 `,[L("not-number",`
 right: unset;
 left: 0;
 `)])])])])]),So=V({name:"BaseSlotMachine",props:{clsPrefix:{type:String,required:!0},value:{type:[Number,String],default:0},max:{type:Number,default:void 0},appeared:{type:Boolean,required:!0}},setup(e){Bt("-base-slot-machine",$o,oe(e,"clsPrefix"));const o=A(),t=A(),i=N(()=>{if(typeof e.value=="string")return[];if(e.value<1)return[0];const r=[];let n=e.value;for(e.max!==void 0&&(n=Math.min(e.max,n));n>=1;)r.push(n%10),n/=10,n=Math.floor(n);return r.reverse(),r});return me(oe(e,"value"),(r,n)=>{typeof r=="string"?(t.value=void 0,o.value=void 0):typeof n=="string"?(t.value=r,o.value=void 0):(t.value=r,o.value=n)}),()=>{const{value:r,clsPrefix:n}=e;return typeof r=="number"?b("span",{class:`${n}-base-slot-machine`},b(Et,{name:"fade-up-width-expand-transition",tag:"span"},{default:()=>i.value.map((d,s)=>b(et,{clsPrefix:n,key:i.value.length-s-1,oldOriginalNumber:o.value,newOriginalNumber:t.value,value:d}))}),b(nt,{key:"+",width:!0},{default:()=>e.max!==void 0&&e.max<r?b(et,{clsPrefix:n,value:"+"}):null})):b("span",{class:`${n}-base-slot-machine`},r)}}});function No(e){const{errorColor:o,infoColor:t,successColor:i,warningColor:r,fontFamily:n}=e;return{color:o,colorInfo:t,colorSuccess:i,colorError:o,colorWarning:r,fontSize:"12px",fontFamily:n}}const Ro={name:"Badge",common:Ot,self:No},Po=Ro,Ao=x([x("@keyframes badge-wave-spread",{from:{boxShadow:"0 0 0.5px 0px var(--n-ripple-color)",opacity:.6},to:{boxShadow:"0 0 0.5px 4.5px var(--n-ripple-color)",opacity:0}}),w("badge",`
 display: inline-flex;
 position: relative;
 vertical-align: middle;
 font-family: var(--n-font-family);
 `,[L("as-is",[w("badge-sup",{position:"static",transform:"translateX(0)"},[qe({transformOrigin:"left bottom",originalTransform:"translateX(0)"})])]),L("dot",[w("badge-sup",`
 height: 8px;
 width: 8px;
 padding: 0;
 min-width: 8px;
 left: 100%;
 bottom: calc(100% - 4px);
 `,[x("::before","border-radius: 4px;")])]),w("badge-sup",`
 background: var(--n-color);
 transition:
 background-color .3s var(--n-bezier),
 color .3s var(--n-bezier);
 color: #FFF;
 position: absolute;
 height: 18px;
 line-height: 18px;
 border-radius: 9px;
 padding: 0 6px;
 text-align: center;
 font-size: var(--n-font-size);
 transform: translateX(-50%);
 left: 100%;
 bottom: calc(100% - 9px);
 font-variant-numeric: tabular-nums;
 z-index: 1;
 display: flex;
 align-items: center;
 `,[qe({transformOrigin:"left bottom",originalTransform:"translateX(-50%)"}),w("base-wave",{zIndex:1,animationDuration:"2s",animationIterationCount:"infinite",animationDelay:"1s",animationTimingFunction:"var(--n-ripple-bezier)",animationName:"badge-wave-spread"}),x("&::before",`
 opacity: 0;
 transform: scale(1);
 border-radius: 9px;
 content: "";
 position: absolute;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 `)])])]),Lo=Object.assign(Object.assign({},ie.props),{value:[String,Number],max:Number,dot:Boolean,type:{type:String,default:"default"},show:{type:Boolean,default:!0},showZero:Boolean,processing:Boolean,color:String,offset:Array}),Mo=V({name:"Badge",props:Lo,setup(e,{slots:o}){const{mergedClsPrefixRef:t,inlineThemeDisabled:i,mergedRtlRef:r}=Ne(e),n=ie("Badge","-badge",Ao,Po,e,t),d=A(!1),s=()=>{d.value=!0},m=()=>{d.value=!1},_=N(()=>e.show&&(e.dot||e.value!==void 0&&!(!e.showZero&&Number(e.value)<=0)||!Ft(o.value)));fe(()=>{_.value&&(d.value=!0)});const u=Kt("Badge",r,t),c=N(()=>{const{type:v,color:f}=e,{common:{cubicBezierEaseInOut:p,cubicBezierEaseOut:I},self:{[Vt("color",v)]:M,fontFamily:F,fontSize:O}}=n.value;return{"--n-font-size":O,"--n-font-family":F,"--n-color":f||M,"--n-ripple-color":f||M,"--n-bezier":p,"--n-ripple-bezier":I}}),a=i?Re("badge",N(()=>{let v="";const{type:f,color:p}=e;return f&&(v+=f[0]),p&&(v+=Dt(p)),v}),c,e):void 0,z=N(()=>{const{offset:v}=e;if(!v)return;const[f,p]=v,I=typeof f=="number"?`${f}px`:f,M=typeof p=="number"?`${p}px`:p;return{transform:`translate(calc(${u!=null&&u.value?"50%":"-50%"} + ${I}), ${M})`}});return{rtlEnabled:u,mergedClsPrefix:t,appeared:d,showBadge:_,handleAfterEnter:s,handleAfterLeave:m,cssVars:i?void 0:c,themeClass:a==null?void 0:a.themeClass,onRender:a==null?void 0:a.onRender,offsetStyle:z}},render(){var e;const{mergedClsPrefix:o,onRender:t,themeClass:i,$slots:r}=this;t==null||t();const n=(e=r.default)===null||e===void 0?void 0:e.call(r);return b("div",{class:[`${o}-badge`,this.rtlEnabled&&`${o}-badge--rtl`,i,{[`${o}-badge--dot`]:this.dot,[`${o}-badge--as-is`]:!n}],style:this.cssVars},n,b(jt,{name:"fade-in-scale-up-transition",onAfterEnter:this.handleAfterEnter,onAfterLeave:this.handleAfterLeave},{default:()=>this.showBadge?b("sup",{class:`${o}-badge-sup`,title:po(this.value),style:this.offsetStyle},rt(r.value,()=>[this.dot?null:b(So,{clsPrefix:o,appeared:this.appeared,max:this.max,value:this.value})]),this.processing?b(Ut,{clsPrefix:o}):null):null}))}}),Ho=w("breadcrumb",`
 white-space: nowrap;
 cursor: default;
 line-height: var(--n-item-line-height);
`,[x("ul",`
 list-style: none;
 padding: 0;
 margin: 0;
 `),x("a",`
 color: inherit;
 text-decoration: inherit;
 `),w("breadcrumb-item",`
 font-size: var(--n-font-size);
 transition: color .3s var(--n-bezier);
 display: inline-flex;
 align-items: center;
 `,[w("icon",`
 font-size: 18px;
 vertical-align: -.2em;
 transition: color .3s var(--n-bezier);
 color: var(--n-item-text-color);
 `),x("&:not(:last-child)",[L("clickable",[$("link",`
 cursor: pointer;
 `,[x("&:hover",`
 background-color: var(--n-item-color-hover);
 `),x("&:active",`
 background-color: var(--n-item-color-pressed); 
 `)])])]),$("link",`
 padding: 4px;
 border-radius: var(--n-item-border-radius);
 transition:
 background-color .3s var(--n-bezier),
 color .3s var(--n-bezier);
 color: var(--n-item-text-color);
 position: relative;
 `,[x("&:hover",`
 color: var(--n-item-text-color-hover);
 `,[w("icon",`
 color: var(--n-item-text-color-hover);
 `)]),x("&:active",`
 color: var(--n-item-text-color-pressed);
 `,[w("icon",`
 color: var(--n-item-text-color-pressed);
 `)])]),$("separator",`
 margin: 0 8px;
 color: var(--n-separator-color);
 transition: color .3s var(--n-bezier);
 user-select: none;
 -webkit-user-select: none;
 `),x("&:last-child",[$("link",`
 font-weight: var(--n-font-weight-active);
 cursor: unset;
 color: var(--n-item-text-color-active);
 `,[w("icon",`
 color: var(--n-item-text-color-active);
 `)]),$("separator",`
 display: none;
 `)])])]),ht=pe("n-breadcrumb"),To=Object.assign(Object.assign({},ie.props),{separator:{type:String,default:"/"}}),Bo=V({name:"Breadcrumb",props:To,setup(e){const{mergedClsPrefixRef:o,inlineThemeDisabled:t}=Ne(e),i=ie("Breadcrumb","-breadcrumb",Ho,Wt,e,o);ne(ht,{separatorRef:oe(e,"separator"),mergedClsPrefixRef:o});const r=N(()=>{const{common:{cubicBezierEaseInOut:d},self:{separatorColor:s,itemTextColor:m,itemTextColorHover:_,itemTextColorPressed:u,itemTextColorActive:c,fontSize:a,fontWeightActive:z,itemBorderRadius:v,itemColorHover:f,itemColorPressed:p,itemLineHeight:I}}=i.value;return{"--n-font-size":a,"--n-bezier":d,"--n-item-text-color":m,"--n-item-text-color-hover":_,"--n-item-text-color-pressed":u,"--n-item-text-color-active":c,"--n-separator-color":s,"--n-item-color-hover":f,"--n-item-color-pressed":p,"--n-item-border-radius":v,"--n-font-weight-active":z,"--n-item-line-height":I}}),n=t?Re("breadcrumb",void 0,r,e):void 0;return{mergedClsPrefix:o,cssVars:t?void 0:r,themeClass:n==null?void 0:n.themeClass,onRender:n==null?void 0:n.onRender}},render(){var e;return(e=this.onRender)===null||e===void 0||e.call(this),b("nav",{class:[`${this.mergedClsPrefix}-breadcrumb`,this.themeClass],style:this.cssVars,"aria-label":"Breadcrumb"},b("ul",null,this.$slots))}});function Eo(e=Gt?window:null){const o=()=>{const{hash:r,host:n,hostname:d,href:s,origin:m,pathname:_,port:u,protocol:c,search:a}=(e==null?void 0:e.location)||{};return{hash:r,host:n,hostname:d,href:s,origin:m,pathname:_,port:u,protocol:c,search:a}},t=A(o()),i=()=>{t.value=o()};return fe(()=>{e&&(e.addEventListener("popstate",i),e.addEventListener("hashchange",i))}),qt(()=>{e&&(e.removeEventListener("popstate",i),e.removeEventListener("hashchange",i))}),t}const Oo={separator:String,href:String,clickable:{type:Boolean,default:!0},onClick:Function},Fo=V({name:"BreadcrumbItem",props:Oo,setup(e,{slots:o}){const t=G(ht,null);if(!t)return()=>null;const{separatorRef:i,mergedClsPrefixRef:r}=t,n=Eo(),d=N(()=>e.href?"a":"span"),s=N(()=>n.value.href===e.href?"location":null);return()=>{const{value:m}=r;return b("li",{class:[`${m}-breadcrumb-item`,e.clickable&&`${m}-breadcrumb-item--clickable`]},b(d.value,{class:`${m}-breadcrumb-item__link`,"aria-current":s.value,href:e.href,onClick:e.onClick},o),b("span",{class:`${m}-breadcrumb-item__separator`,"aria-hidden":"true"},rt(o.separator,()=>{var _;return[(_=e.separator)!==null&&_!==void 0?_:i.value]})))}}}),le=pe("n-menu"),He=pe("n-submenu"),Te=pe("n-menu-item-group"),ue=8;function Be(e){const o=G(le),{props:t,mergedCollapsedRef:i}=o,r=G(He,null),n=G(Te,null),d=N(()=>t.mode==="horizontal"),s=N(()=>d.value?t.dropdownPlacement:"tmNodes"in e?"right-start":"right"),m=N(()=>{var a;return Math.max((a=t.collapsedIconSize)!==null&&a!==void 0?a:t.iconSize,t.iconSize)}),_=N(()=>{var a;return!d.value&&e.root&&i.value&&(a=t.collapsedIconSize)!==null&&a!==void 0?a:t.iconSize}),u=N(()=>{if(d.value)return;const{collapsedWidth:a,indent:z,rootIndent:v}=t,{root:f,isGroup:p}=e,I=v===void 0?z:v;return f?i.value?a/2-m.value/2:I:n&&typeof n.paddingLeftRef.value=="number"?z/2+n.paddingLeftRef.value:r&&typeof r.paddingLeftRef.value=="number"?(p?z/2:z)+r.paddingLeftRef.value:0}),c=N(()=>{const{collapsedWidth:a,indent:z,rootIndent:v}=t,{value:f}=m,{root:p}=e;return d.value||!p||!i.value?ue:(v===void 0?z:v)+f+ue-(a+f)/2});return{dropdownPlacement:s,activeIconSize:_,maxIconSize:m,paddingLeft:u,iconMarginRight:c,NMenu:o,NSubmenu:r}}const Ee={internalKey:{type:[String,Number],required:!0},root:Boolean,isGroup:Boolean,level:{type:Number,required:!0},title:[String,Function],extra:[String,Function]},vt=Object.assign(Object.assign({},Ee),{tmNode:{type:Object,required:!0},tmNodes:{type:Array,required:!0}}),Ko=V({name:"MenuOptionGroup",props:vt,setup(e){ne(He,null);const o=Be(e);ne(Te,{paddingLeftRef:o.paddingLeft});const{mergedClsPrefixRef:t,props:i}=G(le);return function(){const{value:r}=t,n=o.paddingLeft.value,{nodeProps:d}=i,s=d==null?void 0:d(e.tmNode.rawNode);return b("div",{class:`${r}-menu-item-group`,role:"group"},b("div",Object.assign({},s,{class:[`${r}-menu-item-group-title`,s==null?void 0:s.class],style:[(s==null?void 0:s.style)||"",n!==void 0?`padding-left: ${n}px;`:""]}),te(e.title),e.extra?b(W,null," ",te(e.extra)):null),b("div",null,e.tmNodes.map(m=>Oe(m,i))))}}}),ft=V({name:"MenuOptionContent",props:{collapsed:Boolean,disabled:Boolean,title:[String,Function],icon:Function,extra:[String,Function],showArrow:Boolean,childActive:Boolean,hover:Boolean,paddingLeft:Number,selected:Boolean,maxIconSize:{type:Number,required:!0},activeIconSize:{type:Number,required:!0},iconMarginRight:{type:Number,required:!0},clsPrefix:{type:String,required:!0},onClick:Function,tmNode:{type:Object,required:!0},isEllipsisPlaceholder:Boolean},setup(e){const{props:o}=G(le);return{menuProps:o,style:N(()=>{const{paddingLeft:t}=e;return{paddingLeft:t&&`${t}px`}}),iconStyle:N(()=>{const{maxIconSize:t,activeIconSize:i,iconMarginRight:r}=e;return{width:`${t}px`,height:`${t}px`,fontSize:`${i}px`,marginRight:`${r}px`}})}},render(){const{clsPrefix:e,tmNode:o,menuProps:{renderIcon:t,renderLabel:i,renderExtra:r,expandIcon:n}}=this,d=t?t(o.rawNode):te(this.icon);return b("div",{onClick:s=>{var m;(m=this.onClick)===null||m===void 0||m.call(this,s)},role:"none",class:[`${e}-menu-item-content`,{[`${e}-menu-item-content--selected`]:this.selected,[`${e}-menu-item-content--collapsed`]:this.collapsed,[`${e}-menu-item-content--child-active`]:this.childActive,[`${e}-menu-item-content--disabled`]:this.disabled,[`${e}-menu-item-content--hover`]:this.hover}],style:this.style},d&&b("div",{class:`${e}-menu-item-content__icon`,style:this.iconStyle,role:"none"},[d]),b("div",{class:`${e}-menu-item-content-header`,role:"none"},this.isEllipsisPlaceholder?this.title:i?i(o.rawNode):te(this.title),this.extra||r?b("span",{class:`${e}-menu-item-content-header__extra`}," ",r?r(o.rawNode):te(this.extra)):null),this.showArrow?b(Yt,{ariaHidden:!0,class:`${e}-menu-item-content__arrow`,clsPrefix:e},{default:()=>n?n(o.rawNode):b(Io,null)}):null)}}),pt=Object.assign(Object.assign({},Ee),{rawNodes:{type:Array,default:()=>[]},tmNodes:{type:Array,default:()=>[]},tmNode:{type:Object,required:!0},disabled:Boolean,icon:Function,onClick:Function,domId:String,virtualChildActive:{type:Boolean,default:void 0},isEllipsisPlaceholder:Boolean}),$e=V({name:"Submenu",props:pt,setup(e){const o=Be(e),{NMenu:t,NSubmenu:i}=o,{props:r,mergedCollapsedRef:n,mergedThemeRef:d}=t,s=N(()=>{const{disabled:a}=e;return i!=null&&i.mergedDisabledRef.value||r.disabled?!0:a}),m=A(!1);ne(He,{paddingLeftRef:o.paddingLeft,mergedDisabledRef:s}),ne(Te,null);function _(){const{onClick:a}=e;a&&a()}function u(){s.value||(n.value||t.toggleExpand(e.internalKey),_())}function c(a){m.value=a}return{menuProps:r,mergedTheme:d,doSelect:t.doSelect,inverted:t.invertedRef,isHorizontal:t.isHorizontalRef,mergedClsPrefix:t.mergedClsPrefixRef,maxIconSize:o.maxIconSize,activeIconSize:o.activeIconSize,iconMarginRight:o.iconMarginRight,dropdownPlacement:o.dropdownPlacement,dropdownShow:m,paddingLeft:o.paddingLeft,mergedDisabled:s,mergedValue:t.mergedValueRef,childActive:we(()=>{var a;return(a=e.virtualChildActive)!==null&&a!==void 0?a:t.activePathRef.value.includes(e.internalKey)}),collapsed:N(()=>r.mode==="horizontal"?!1:n.value?!0:!t.mergedExpandedKeysRef.value.includes(e.internalKey)),dropdownEnabled:N(()=>!s.value&&(r.mode==="horizontal"||n.value)),handlePopoverShowChange:c,handleClick:u}},render(){var e;const{mergedClsPrefix:o,menuProps:{renderIcon:t,renderLabel:i}}=this,r=()=>{const{isHorizontal:d,paddingLeft:s,collapsed:m,mergedDisabled:_,maxIconSize:u,activeIconSize:c,title:a,childActive:z,icon:v,handleClick:f,menuProps:{nodeProps:p},dropdownShow:I,iconMarginRight:M,tmNode:F,mergedClsPrefix:O,isEllipsisPlaceholder:Y,extra:K}=this,D=p==null?void 0:p(F.rawNode);return b("div",Object.assign({},D,{class:[`${O}-menu-item`,D==null?void 0:D.class],role:"menuitem"}),b(ft,{tmNode:F,paddingLeft:s,collapsed:m,disabled:_,iconMarginRight:M,maxIconSize:u,activeIconSize:c,title:a,extra:K,showArrow:!d,childActive:z,clsPrefix:O,icon:v,hover:I,onClick:f,isEllipsisPlaceholder:Y}))},n=()=>b(nt,null,{default:()=>{const{tmNodes:d,collapsed:s}=this;return s?null:b("div",{class:`${o}-submenu-children`,role:"menu"},d.map(m=>Oe(m,this.menuProps)))}});return this.root?b(Le,Object.assign({size:"large",trigger:"hover"},(e=this.menuProps)===null||e===void 0?void 0:e.dropdownProps,{themeOverrides:this.mergedTheme.peerOverrides.Dropdown,theme:this.mergedTheme.peers.Dropdown,builtinThemeOverrides:{fontSizeLarge:"14px",optionIconSizeLarge:"18px"},value:this.mergedValue,disabled:!this.dropdownEnabled,placement:this.dropdownPlacement,keyField:this.menuProps.keyField,labelField:this.menuProps.labelField,childrenField:this.menuProps.childrenField,onUpdateShow:this.handlePopoverShowChange,options:this.rawNodes,onSelect:this.doSelect,inverted:this.inverted,renderIcon:t,renderLabel:i}),{default:()=>b("div",{class:`${o}-submenu`,role:"menu","aria-expanded":!this.collapsed,id:this.domId},r(),this.isHorizontal?null:n())}):b("div",{class:`${o}-submenu`,role:"menu","aria-expanded":!this.collapsed,id:this.domId},r(),n())}}),_t=Object.assign(Object.assign({},Ee),{tmNode:{type:Object,required:!0},disabled:Boolean,icon:Function,onClick:Function}),Vo=V({name:"MenuOption",props:_t,setup(e){const o=Be(e),{NSubmenu:t,NMenu:i}=o,{props:r,mergedClsPrefixRef:n,mergedCollapsedRef:d}=i,s=t?t.mergedDisabledRef:{value:!1},m=N(()=>s.value||e.disabled);function _(c){const{onClick:a}=e;a&&a(c)}function u(c){m.value||(i.doSelect(e.internalKey,e.tmNode.rawNode),_(c))}return{mergedClsPrefix:n,dropdownPlacement:o.dropdownPlacement,paddingLeft:o.paddingLeft,iconMarginRight:o.iconMarginRight,maxIconSize:o.maxIconSize,activeIconSize:o.activeIconSize,mergedTheme:i.mergedThemeRef,menuProps:r,dropdownEnabled:we(()=>e.root&&d.value&&r.mode!=="horizontal"&&!m.value),selected:we(()=>i.mergedValueRef.value===e.internalKey),mergedDisabled:m,handleClick:u}},render(){const{mergedClsPrefix:e,mergedTheme:o,tmNode:t,menuProps:{renderLabel:i,nodeProps:r}}=this,n=r==null?void 0:r(t.rawNode);return b("div",Object.assign({},n,{role:"menuitem",class:[`${e}-menu-item`,n==null?void 0:n.class]}),b(Co,{theme:o.peers.Tooltip,themeOverrides:o.peerOverrides.Tooltip,trigger:"hover",placement:this.dropdownPlacement,disabled:!this.dropdownEnabled||this.title===void 0,internalExtraClass:["menu-tooltip"]},{default:()=>i?i(t.rawNode):te(this.title),trigger:()=>b(ft,{tmNode:t,clsPrefix:e,paddingLeft:this.paddingLeft,iconMarginRight:this.iconMarginRight,maxIconSize:this.maxIconSize,activeIconSize:this.activeIconSize,selected:this.selected,title:this.title,extra:this.extra,disabled:this.mergedDisabled,icon:this.icon,onClick:this.handleClick})}))}}),Do=V({name:"MenuDivider",setup(){const e=G(le),{mergedClsPrefixRef:o,isHorizontalRef:t}=e;return()=>t.value?null:b("div",{class:`${o.value}-menu-divider`})}}),jo=Pe(vt),Uo=Pe(_t),Wo=Pe(pt);function Se(e){return e.type==="divider"||e.type==="render"}function qo(e){return e.type==="divider"}function Oe(e,o){const{rawNode:t}=e,{show:i}=t;if(i===!1)return null;if(Se(t))return qo(t)?b(Do,Object.assign({key:e.key},t.props)):null;const{labelField:r}=o,{key:n,level:d,isGroup:s}=e,m=Object.assign(Object.assign({},t),{title:t.title||t[r],extra:t.titleExtra||t.extra,key:n,internalKey:n,level:d,root:d===0,isGroup:s});return e.children?e.isGroup?b(Ko,xe(m,jo,{tmNode:e,tmNodes:e.children,key:n})):b($e,xe(m,Wo,{key:n,rawNodes:t[o.childrenField],tmNodes:e.children,tmNode:e})):b(Vo,xe(m,Uo,{key:n,tmNode:e}))}const tt=[x("&::before","background-color: var(--n-item-color-hover);"),$("arrow",`
 color: var(--n-arrow-color-hover);
 `),$("icon",`
 color: var(--n-item-icon-color-hover);
 `),w("menu-item-content-header",`
 color: var(--n-item-text-color-hover);
 `,[x("a",`
 color: var(--n-item-text-color-hover);
 `),$("extra",`
 color: var(--n-item-text-color-hover);
 `)])],ot=[$("icon",`
 color: var(--n-item-icon-color-hover-horizontal);
 `),w("menu-item-content-header",`
 color: var(--n-item-text-color-hover-horizontal);
 `,[x("a",`
 color: var(--n-item-text-color-hover-horizontal);
 `),$("extra",`
 color: var(--n-item-text-color-hover-horizontal);
 `)])],Go=x([w("menu",`
 background-color: var(--n-color);
 color: var(--n-item-text-color);
 overflow: hidden;
 transition: background-color .3s var(--n-bezier);
 box-sizing: border-box;
 font-size: var(--n-font-size);
 padding-bottom: 6px;
 `,[L("horizontal",`
 max-width: 100%;
 width: 100%;
 display: flex;
 overflow: hidden;
 padding-bottom: 0;
 `,[w("submenu","margin: 0;"),w("menu-item","margin: 0;"),w("menu-item-content",`
 padding: 0 20px;
 border-bottom: 2px solid #0000;
 `,[x("&::before","display: none;"),L("selected","border-bottom: 2px solid var(--n-border-color-horizontal)")]),w("menu-item-content",[L("selected",[$("icon","color: var(--n-item-icon-color-active-horizontal);"),w("menu-item-content-header",`
 color: var(--n-item-text-color-active-horizontal);
 `,[x("a","color: var(--n-item-text-color-active-horizontal);"),$("extra","color: var(--n-item-text-color-active-horizontal);")])]),L("child-active",`
 border-bottom: 2px solid var(--n-border-color-horizontal);
 `,[w("menu-item-content-header",`
 color: var(--n-item-text-color-child-active-horizontal);
 `,[x("a",`
 color: var(--n-item-text-color-child-active-horizontal);
 `),$("extra",`
 color: var(--n-item-text-color-child-active-horizontal);
 `)]),$("icon",`
 color: var(--n-item-icon-color-child-active-horizontal);
 `)]),ae("disabled",[ae("selected, child-active",[x("&:focus-within",ot)]),L("selected",[Z(null,[$("icon","color: var(--n-item-icon-color-active-hover-horizontal);"),w("menu-item-content-header",`
 color: var(--n-item-text-color-active-hover-horizontal);
 `,[x("a","color: var(--n-item-text-color-active-hover-horizontal);"),$("extra","color: var(--n-item-text-color-active-hover-horizontal);")])])]),L("child-active",[Z(null,[$("icon","color: var(--n-item-icon-color-child-active-hover-horizontal);"),w("menu-item-content-header",`
 color: var(--n-item-text-color-child-active-hover-horizontal);
 `,[x("a","color: var(--n-item-text-color-child-active-hover-horizontal);"),$("extra","color: var(--n-item-text-color-child-active-hover-horizontal);")])])]),Z("border-bottom: 2px solid var(--n-border-color-horizontal);",ot)]),w("menu-item-content-header",[x("a","color: var(--n-item-text-color-horizontal);")])])]),ae("responsive",[w("menu-item-content-header",`
 overflow: hidden;
 text-overflow: ellipsis;
 `)]),L("collapsed",[w("menu-item-content",[L("selected",[x("&::before",`
 background-color: var(--n-item-color-active-collapsed) !important;
 `)]),w("menu-item-content-header","opacity: 0;"),$("arrow","opacity: 0;"),$("icon","color: var(--n-item-icon-color-collapsed);")])]),w("menu-item",`
 height: var(--n-item-height);
 margin-top: 6px;
 position: relative;
 `),w("menu-item-content",`
 box-sizing: border-box;
 line-height: 1.75;
 height: 100%;
 display: grid;
 grid-template-areas: "icon content arrow";
 grid-template-columns: auto 1fr auto;
 align-items: center;
 cursor: pointer;
 position: relative;
 padding-right: 18px;
 transition:
 background-color .3s var(--n-bezier),
 padding-left .3s var(--n-bezier),
 border-color .3s var(--n-bezier);
 `,[x("> *","z-index: 1;"),x("&::before",`
 z-index: auto;
 content: "";
 background-color: #0000;
 position: absolute;
 left: 8px;
 right: 8px;
 top: 0;
 bottom: 0;
 pointer-events: none;
 border-radius: var(--n-border-radius);
 transition: background-color .3s var(--n-bezier);
 `),L("disabled",`
 opacity: .45;
 cursor: not-allowed;
 `),L("collapsed",[$("arrow","transform: rotate(0);")]),L("selected",[x("&::before","background-color: var(--n-item-color-active);"),$("arrow","color: var(--n-arrow-color-active);"),$("icon","color: var(--n-item-icon-color-active);"),w("menu-item-content-header",`
 color: var(--n-item-text-color-active);
 `,[x("a","color: var(--n-item-text-color-active);"),$("extra","color: var(--n-item-text-color-active);")])]),L("child-active",[w("menu-item-content-header",`
 color: var(--n-item-text-color-child-active);
 `,[x("a",`
 color: var(--n-item-text-color-child-active);
 `),$("extra",`
 color: var(--n-item-text-color-child-active);
 `)]),$("arrow",`
 color: var(--n-arrow-color-child-active);
 `),$("icon",`
 color: var(--n-item-icon-color-child-active);
 `)]),ae("disabled",[ae("selected, child-active",[x("&:focus-within",tt)]),L("selected",[Z(null,[$("arrow","color: var(--n-arrow-color-active-hover);"),$("icon","color: var(--n-item-icon-color-active-hover);"),w("menu-item-content-header",`
 color: var(--n-item-text-color-active-hover);
 `,[x("a","color: var(--n-item-text-color-active-hover);"),$("extra","color: var(--n-item-text-color-active-hover);")])])]),L("child-active",[Z(null,[$("arrow","color: var(--n-arrow-color-child-active-hover);"),$("icon","color: var(--n-item-icon-color-child-active-hover);"),w("menu-item-content-header",`
 color: var(--n-item-text-color-child-active-hover);
 `,[x("a","color: var(--n-item-text-color-child-active-hover);"),$("extra","color: var(--n-item-text-color-child-active-hover);")])])]),L("selected",[Z(null,[x("&::before","background-color: var(--n-item-color-active-hover);")])]),Z(null,tt)]),$("icon",`
 grid-area: icon;
 color: var(--n-item-icon-color);
 transition:
 color .3s var(--n-bezier),
 font-size .3s var(--n-bezier),
 margin-right .3s var(--n-bezier);
 box-sizing: content-box;
 display: inline-flex;
 align-items: center;
 justify-content: center;
 `),$("arrow",`
 grid-area: arrow;
 font-size: 16px;
 color: var(--n-arrow-color);
 transform: rotate(180deg);
 opacity: 1;
 transition:
 color .3s var(--n-bezier),
 transform 0.2s var(--n-bezier),
 opacity 0.2s var(--n-bezier);
 `),w("menu-item-content-header",`
 grid-area: content;
 transition:
 color .3s var(--n-bezier),
 opacity .3s var(--n-bezier);
 opacity: 1;
 white-space: nowrap;
 color: var(--n-item-text-color);
 `,[x("a",`
 outline: none;
 text-decoration: none;
 transition: color .3s var(--n-bezier);
 color: var(--n-item-text-color);
 `,[x("&::before",`
 content: "";
 position: absolute;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 `)]),$("extra",`
 font-size: .93em;
 color: var(--n-group-text-color);
 transition: color .3s var(--n-bezier);
 `)])]),w("submenu",`
 cursor: pointer;
 position: relative;
 margin-top: 6px;
 `,[w("menu-item-content",`
 height: var(--n-item-height);
 `),w("submenu-children",`
 overflow: hidden;
 padding: 0;
 `,[Xt({duration:".2s"})])]),w("menu-item-group",[w("menu-item-group-title",`
 margin-top: 6px;
 color: var(--n-group-text-color);
 cursor: default;
 font-size: .93em;
 height: 36px;
 display: flex;
 align-items: center;
 transition:
 padding-left .3s var(--n-bezier),
 color .3s var(--n-bezier);
 `)])]),w("menu-tooltip",[x("a",`
 color: inherit;
 text-decoration: none;
 `)]),w("menu-divider",`
 transition: background-color .3s var(--n-bezier);
 background-color: var(--n-divider-color);
 height: 1px;
 margin: 6px 18px;
 `)]);function Z(e,o){return[L("hover",e,o),x("&:hover",e,o)]}const Yo=Object.assign(Object.assign({},ie.props),{options:{type:Array,default:()=>[]},collapsed:{type:Boolean,default:void 0},collapsedWidth:{type:Number,default:48},iconSize:{type:Number,default:20},collapsedIconSize:{type:Number,default:24},rootIndent:Number,indent:{type:Number,default:32},labelField:{type:String,default:"label"},keyField:{type:String,default:"key"},childrenField:{type:String,default:"children"},disabledField:{type:String,default:"disabled"},defaultExpandAll:Boolean,defaultExpandedKeys:Array,expandedKeys:Array,value:[String,Number],defaultValue:{type:[String,Number],default:null},mode:{type:String,default:"vertical"},watchProps:{type:Array,default:void 0},disabled:Boolean,show:{type:Boolean,default:!0},inverted:Boolean,"onUpdate:expandedKeys":[Function,Array],onUpdateExpandedKeys:[Function,Array],onUpdateValue:[Function,Array],"onUpdate:value":[Function,Array],expandIcon:Function,renderIcon:Function,renderLabel:Function,renderExtra:Function,dropdownProps:Object,accordion:Boolean,nodeProps:Function,dropdownPlacement:{type:String,default:"bottom"},responsive:Boolean,items:Array,onOpenNamesChange:[Function,Array],onSelect:[Function,Array],onExpandedNamesChange:[Function,Array],expandedNames:Array,defaultExpandedNames:Array}),Xo=V({name:"Menu",props:Yo,setup(e){const{mergedClsPrefixRef:o,inlineThemeDisabled:t}=Ne(e),i=ie("Menu","-menu",Go,Zt,e,o),r=G(xo,null),n=N(()=>{var y;const{collapsed:R}=e;if(R!==void 0)return R;if(r){const{collapseModeRef:l,collapsedRef:k}=r;if(l.value==="width")return(y=k.value)!==null&&y!==void 0?y:!1}return!1}),d=N(()=>{const{keyField:y,childrenField:R,disabledField:l}=e;return ye(e.items||e.options,{getIgnored(k){return Se(k)},getChildren(k){return k[R]},getDisabled(k){return k[l]},getKey(k){var T;return(T=k[y])!==null&&T!==void 0?T:k.name}})}),s=N(()=>new Set(d.value.treeNodes.map(y=>y.key))),{watchProps:m}=e,_=A(null);m!=null&&m.includes("defaultValue")?Ce(()=>{_.value=e.defaultValue}):_.value=e.defaultValue;const u=oe(e,"value"),c=Je(u,_),a=A([]),z=()=>{a.value=e.defaultExpandAll?d.value.getNonLeafKeys():e.defaultExpandedNames||e.defaultExpandedKeys||d.value.getPath(c.value,{includeSelf:!1}).keyPath};m!=null&&m.includes("defaultExpandedKeys")?Ce(z):z();const v=zo(e,["expandedNames","expandedKeys"]),f=Je(v,a),p=N(()=>d.value.treeNodes),I=N(()=>d.value.getPath(c.value).keyPath);ne(le,{props:e,mergedCollapsedRef:n,mergedThemeRef:i,mergedValueRef:c,mergedExpandedKeysRef:f,activePathRef:I,mergedClsPrefixRef:o,isHorizontalRef:N(()=>e.mode==="horizontal"),invertedRef:oe(e,"inverted"),doSelect:M,toggleExpand:O});function M(y,R){const{"onUpdate:value":l,onUpdateValue:k,onSelect:T}=e;k&&X(k,y,R),l&&X(l,y,R),T&&X(T,y,R),_.value=y}function F(y){const{"onUpdate:expandedKeys":R,onUpdateExpandedKeys:l,onExpandedNamesChange:k,onOpenNamesChange:T}=e;R&&X(R,y),l&&X(l,y),k&&X(k,y),T&&X(T,y),a.value=y}function O(y){const R=Array.from(f.value),l=R.findIndex(k=>k===y);if(~l)R.splice(l,1);else{if(e.accordion&&s.value.has(y)){const k=R.findIndex(T=>s.value.has(T));k>-1&&R.splice(k,1)}R.push(y)}F(R)}const Y=y=>{const R=d.value.getPath(y!=null?y:c.value,{includeSelf:!1}).keyPath;if(!R.length)return;const l=Array.from(f.value),k=new Set([...l,...R]);e.accordion&&s.value.forEach(T=>{k.has(T)&&!R.includes(T)&&k.delete(T)}),F(Array.from(k))},K=N(()=>{const{inverted:y}=e,{common:{cubicBezierEaseInOut:R},self:l}=i.value,{borderRadius:k,borderColorHorizontal:T,fontSize:$t,itemHeight:St,dividerColor:Nt}=l,h={"--n-divider-color":Nt,"--n-bezier":R,"--n-font-size":$t,"--n-border-color-horizontal":T,"--n-border-radius":k,"--n-item-height":St};return y?(h["--n-group-text-color"]=l.groupTextColorInverted,h["--n-color"]=l.colorInverted,h["--n-item-text-color"]=l.itemTextColorInverted,h["--n-item-text-color-hover"]=l.itemTextColorHoverInverted,h["--n-item-text-color-active"]=l.itemTextColorActiveInverted,h["--n-item-text-color-child-active"]=l.itemTextColorChildActiveInverted,h["--n-item-text-color-child-active-hover"]=l.itemTextColorChildActiveInverted,h["--n-item-text-color-active-hover"]=l.itemTextColorActiveHoverInverted,h["--n-item-icon-color"]=l.itemIconColorInverted,h["--n-item-icon-color-hover"]=l.itemIconColorHoverInverted,h["--n-item-icon-color-active"]=l.itemIconColorActiveInverted,h["--n-item-icon-color-active-hover"]=l.itemIconColorActiveHoverInverted,h["--n-item-icon-color-child-active"]=l.itemIconColorChildActiveInverted,h["--n-item-icon-color-child-active-hover"]=l.itemIconColorChildActiveHoverInverted,h["--n-item-icon-color-collapsed"]=l.itemIconColorCollapsedInverted,h["--n-item-text-color-horizontal"]=l.itemTextColorHorizontalInverted,h["--n-item-text-color-hover-horizontal"]=l.itemTextColorHoverHorizontalInverted,h["--n-item-text-color-active-horizontal"]=l.itemTextColorActiveHorizontalInverted,h["--n-item-text-color-child-active-horizontal"]=l.itemTextColorChildActiveHorizontalInverted,h["--n-item-text-color-child-active-hover-horizontal"]=l.itemTextColorChildActiveHoverHorizontalInverted,h["--n-item-text-color-active-hover-horizontal"]=l.itemTextColorActiveHoverHorizontalInverted,h["--n-item-icon-color-horizontal"]=l.itemIconColorHorizontalInverted,h["--n-item-icon-color-hover-horizontal"]=l.itemIconColorHoverHorizontalInverted,h["--n-item-icon-color-active-horizontal"]=l.itemIconColorActiveHorizontalInverted,h["--n-item-icon-color-active-hover-horizontal"]=l.itemIconColorActiveHoverHorizontalInverted,h["--n-item-icon-color-child-active-horizontal"]=l.itemIconColorChildActiveHorizontalInverted,h["--n-item-icon-color-child-active-hover-horizontal"]=l.itemIconColorChildActiveHoverHorizontalInverted,h["--n-arrow-color"]=l.arrowColorInverted,h["--n-arrow-color-hover"]=l.arrowColorHoverInverted,h["--n-arrow-color-active"]=l.arrowColorActiveInverted,h["--n-arrow-color-active-hover"]=l.arrowColorActiveHoverInverted,h["--n-arrow-color-child-active"]=l.arrowColorChildActiveInverted,h["--n-arrow-color-child-active-hover"]=l.arrowColorChildActiveHoverInverted,h["--n-item-color-hover"]=l.itemColorHoverInverted,h["--n-item-color-active"]=l.itemColorActiveInverted,h["--n-item-color-active-hover"]=l.itemColorActiveHoverInverted,h["--n-item-color-active-collapsed"]=l.itemColorActiveCollapsedInverted):(h["--n-group-text-color"]=l.groupTextColor,h["--n-color"]=l.color,h["--n-item-text-color"]=l.itemTextColor,h["--n-item-text-color-hover"]=l.itemTextColorHover,h["--n-item-text-color-active"]=l.itemTextColorActive,h["--n-item-text-color-child-active"]=l.itemTextColorChildActive,h["--n-item-text-color-child-active-hover"]=l.itemTextColorChildActiveHover,h["--n-item-text-color-active-hover"]=l.itemTextColorActiveHover,h["--n-item-icon-color"]=l.itemIconColor,h["--n-item-icon-color-hover"]=l.itemIconColorHover,h["--n-item-icon-color-active"]=l.itemIconColorActive,h["--n-item-icon-color-active-hover"]=l.itemIconColorActiveHover,h["--n-item-icon-color-child-active"]=l.itemIconColorChildActive,h["--n-item-icon-color-child-active-hover"]=l.itemIconColorChildActiveHover,h["--n-item-icon-color-collapsed"]=l.itemIconColorCollapsed,h["--n-item-text-color-horizontal"]=l.itemTextColorHorizontal,h["--n-item-text-color-hover-horizontal"]=l.itemTextColorHoverHorizontal,h["--n-item-text-color-active-horizontal"]=l.itemTextColorActiveHorizontal,h["--n-item-text-color-child-active-horizontal"]=l.itemTextColorChildActiveHorizontal,h["--n-item-text-color-child-active-hover-horizontal"]=l.itemTextColorChildActiveHoverHorizontal,h["--n-item-text-color-active-hover-horizontal"]=l.itemTextColorActiveHoverHorizontal,h["--n-item-icon-color-horizontal"]=l.itemIconColorHorizontal,h["--n-item-icon-color-hover-horizontal"]=l.itemIconColorHoverHorizontal,h["--n-item-icon-color-active-horizontal"]=l.itemIconColorActiveHorizontal,h["--n-item-icon-color-active-hover-horizontal"]=l.itemIconColorActiveHoverHorizontal,h["--n-item-icon-color-child-active-horizontal"]=l.itemIconColorChildActiveHorizontal,h["--n-item-icon-color-child-active-hover-horizontal"]=l.itemIconColorChildActiveHoverHorizontal,h["--n-arrow-color"]=l.arrowColor,h["--n-arrow-color-hover"]=l.arrowColorHover,h["--n-arrow-color-active"]=l.arrowColorActive,h["--n-arrow-color-active-hover"]=l.arrowColorActiveHover,h["--n-arrow-color-child-active"]=l.arrowColorChildActive,h["--n-arrow-color-child-active-hover"]=l.arrowColorChildActiveHover,h["--n-item-color-hover"]=l.itemColorHover,h["--n-item-color-active"]=l.itemColorActive,h["--n-item-color-active-hover"]=l.itemColorActiveHover,h["--n-item-color-active-collapsed"]=l.itemColorActiveCollapsed),h}),D=t?Re("menu",N(()=>e.inverted?"a":"b"),K,e):void 0,be=Jt(),Fe=A(null),bt=A(null);let Ke=!0;const Ve=()=>{var y;Ke?Ke=!1:(y=Fe.value)===null||y===void 0||y.sync({showAllItemsBeforeCalculate:!0})};function xt(){return document.getElementById(be)}const ce=A(-1);function yt(y){ce.value=e.options.length-y}function wt(y){y||(ce.value=-1)}const Ct=N(()=>{const y=ce.value;return{children:y===-1?[]:e.options.slice(y)}}),zt=N(()=>{const{childrenField:y,disabledField:R,keyField:l}=e;return ye([Ct.value],{getIgnored(k){return Se(k)},getChildren(k){return k[y]},getDisabled(k){return k[R]},getKey(k){var T;return(T=k[l])!==null&&T!==void 0?T:k.name}})}),It=N(()=>ye([{}]).treeNodes[0]);function kt(){var y;if(ce.value===-1)return b($e,{root:!0,level:0,key:"__ellpisisGroupPlaceholder__",internalKey:"__ellpisisGroupPlaceholder__",title:"···",tmNode:It.value,domId:be,isEllipsisPlaceholder:!0});const R=zt.value.treeNodes[0],l=I.value,k=!!(!((y=R.children)===null||y===void 0)&&y.some(T=>l.includes(T.key)));return b($e,{level:0,root:!0,key:"__ellpisisGroup__",internalKey:"__ellpisisGroup__",title:"···",virtualChildActive:k,tmNode:R,domId:be,rawNodes:R.rawNode.children||[],tmNodes:R.children||[],isEllipsisPlaceholder:!0})}return{mergedClsPrefix:o,controlledExpandedKeys:v,uncontrolledExpanededKeys:a,mergedExpandedKeys:f,uncontrolledValue:_,mergedValue:c,activePath:I,tmNodes:p,mergedTheme:i,mergedCollapsed:n,cssVars:t?void 0:K,themeClass:D==null?void 0:D.themeClass,overflowRef:Fe,counterRef:bt,updateCounter:()=>{},onResize:Ve,onUpdateOverflow:wt,onUpdateCount:yt,renderCounter:kt,getCounter:xt,onRender:D==null?void 0:D.onRender,showOption:Y,deriveResponsiveState:Ve}},render(){const{mergedClsPrefix:e,mode:o,themeClass:t,onRender:i}=this;i==null||i();const r=()=>this.tmNodes.map(m=>Oe(m,this.$props)),d=o==="horizontal"&&this.responsive,s=()=>b("div",{role:o==="horizontal"?"menubar":"menu",class:[`${e}-menu`,t,`${e}-menu--${o}`,d&&`${e}-menu--responsive`,this.mergedCollapsed&&`${e}-menu--collapsed`],style:this.cssVars},d?b(_o,{ref:"overflowRef",onUpdateOverflow:this.onUpdateOverflow,getCounter:this.getCounter,onUpdateCount:this.onUpdateCount,updateCounter:this.updateCounter,style:{width:"100%",display:"flex",overflow:"hidden"}},{default:r,counter:this.renderCounter}):r());return d?b(Qt,{onResize:this.onResize},{default:s}):s()}}),Zo={__name:"BreadCrumb",setup(e){const o=_e(),t=ge();function i(n){n!==t.path&&o.push(n)}function r(n){return n!=null&&n.customIcon?ut(n.customIcon,{size:18}):n!=null&&n.icon?U(n.icon,{size:18}):null}return(n,d)=>{const s=Fo,m=Bo;return g(),H(m,null,{default:E(()=>[(g(!0),P(W,null,ve(C(t).matched.filter(_=>{var u;return!!((u=_.meta)!=null&&u.title)}),_=>(g(),H(s,{key:_.path,onClick:u=>i(_.path)},{default:E(()=>[(g(),H(it(r(_.meta)))),ee(" "+j(_.meta.title),1)]),_:2},1032,["onClick"]))),128))]),_:1})}}},Jo={class:"inline-block",viewBox:"0 0 24 24",width:"1em",height:"1em"},Qo=S("path",{fill:"currentColor",d:"M11 13h10v-2H11m0-2h10V7H11M3 3v2h18V3M3 21h18v-2H3m0-7l4 4V8m4 9h10v-2H11z"},null,-1),en=[Qo];function tn(e,o){return g(),P("svg",Jo,[...en])}const on={name:"mdi-format-indent-decrease",render:tn},nn={class:"inline-block",viewBox:"0 0 24 24",width:"1em",height:"1em"},rn=S("path",{fill:"currentColor",d:"M11 13h10v-2H11m0-2h10V7H11M3 3v2h18V3M11 17h10v-2H11M3 8v8l4-4m-4 9h18v-2H3z"},null,-1),an=[rn];function ln(e,o){return g(),P("svg",nn,[...an])}const cn={name:"mdi-format-indent-increase",render:ln},sn={__name:"MenuCollapse",setup(e){const o=J();return(t,i)=>{const r=cn,n=on,d=Ae;return g(),H(d,{size:"20","cursor-pointer":"",onClick:C(o).switchCollapsed},{default:E(()=>[C(o).collapsed?(g(),H(r,{key:0})):(g(),H(n,{key:1}))]),_:1},8,["onClick"])}}},dn={class:"inline-block",viewBox:"0 0 1024 1024",width:"1em",height:"1em"},un=S("path",{fill:"currentColor",d:"m290 236.4l43.9-43.9a8.01 8.01 0 0 0-4.7-13.6L169 160c-5.1-.6-9.5 3.7-8.9 8.9L179 329.1c.8 6.6 8.9 9.4 13.6 4.7l43.7-43.7L370 423.7c3.1 3.1 8.2 3.1 11.3 0l42.4-42.3c3.1-3.1 3.1-8.2 0-11.3zm352.7 187.3c3.1 3.1 8.2 3.1 11.3 0l133.7-133.6l43.7 43.7a8.01 8.01 0 0 0 13.6-4.7L863.9 169c.6-5.1-3.7-9.5-8.9-8.9L694.8 179c-6.6.8-9.4 8.9-4.7 13.6l43.9 43.9L600.3 370a8.03 8.03 0 0 0 0 11.3zM845 694.9c-.8-6.6-8.9-9.4-13.6-4.7l-43.7 43.7L654 600.3a8.03 8.03 0 0 0-11.3 0l-42.4 42.3a8.03 8.03 0 0 0 0 11.3L734 787.6l-43.9 43.9a8.01 8.01 0 0 0 4.7 13.6L855 864c5.1.6 9.5-3.7 8.9-8.9zm-463.7-94.6a8.03 8.03 0 0 0-11.3 0L236.3 733.9l-43.7-43.7a8.01 8.01 0 0 0-13.6 4.7L160.1 855c-.6 5.1 3.7 9.5 8.9 8.9L329.2 845c6.6-.8 9.4-8.9 4.7-13.6L290 787.6L423.7 654c3.1-3.1 3.1-8.2 0-11.3z"},null,-1),mn=[un];function hn(e,o){return g(),P("svg",dn,[...mn])}const vn={name:"ant-design-fullscreen-outlined",render:hn},fn={class:"inline-block",viewBox:"0 0 1024 1024",width:"1em",height:"1em"},pn=S("path",{fill:"currentColor",d:"M391 240.9c-.8-6.6-8.9-9.4-13.6-4.7l-43.7 43.7L200 146.3a8.03 8.03 0 0 0-11.3 0l-42.4 42.3a8.03 8.03 0 0 0 0 11.3L280 333.6l-43.9 43.9a8.01 8.01 0 0 0 4.7 13.6L401 410c5.1.6 9.5-3.7 8.9-8.9zm10.1 373.2L240.8 633c-6.6.8-9.4 8.9-4.7 13.6l43.9 43.9L146.3 824a8.03 8.03 0 0 0 0 11.3l42.4 42.3c3.1 3.1 8.2 3.1 11.3 0L333.7 744l43.7 43.7A8.01 8.01 0 0 0 391 783l18.9-160.1c.6-5.1-3.7-9.4-8.8-8.8m221.8-204.2L783.2 391c6.6-.8 9.4-8.9 4.7-13.6L744 333.6L877.7 200c3.1-3.1 3.1-8.2 0-11.3l-42.4-42.3a8.03 8.03 0 0 0-11.3 0L690.3 279.9l-43.7-43.7a8.01 8.01 0 0 0-13.6 4.7L614.1 401c-.6 5.2 3.7 9.5 8.8 8.9M744 690.4l43.9-43.9a8.01 8.01 0 0 0-4.7-13.6L623 614c-5.1-.6-9.5 3.7-8.9 8.9L633 783.1c.8 6.6 8.9 9.4 13.6 4.7l43.7-43.7L824 877.7c3.1 3.1 8.2 3.1 11.3 0l42.4-42.3c3.1-3.1 3.1-8.2 0-11.3z"},null,-1),_n=[pn];function gn(e,o){return g(),P("svg",fn,[..._n])}const bn={name:"ant-design-fullscreen-exit-outlined",render:gn},xn={__name:"FullScreen",setup(e){const o=J(),{isFullscreen:t,toggle:i}=eo();return(r,n)=>{const d=bn,s=vn,m=Ae;return C(o).fullScreen?(g(),H(m,{key:0,mr20:"",size:"18",style:{cursor:"pointer"},onClick:C(i)},{default:E(()=>[C(t)?(g(),H(d,{key:0})):(g(),H(s,{key:1}))]),_:1},8,["onClick"])):re("",!0)}}},yn={flex:"","cursor-pointer":"","items-center":""},wn={__name:"UserAvatar",setup(e){const{t:o}=to(),t=_e(),i=oo(),r=[{label:o("header.label_profile"),key:"profile",icon:U("mdi-account-arrow-right-outline",{size:"14px"})},{label:o("header.label_logout"),key:"logout",icon:U("mdi:exit-to-app",{size:"14px"})}];function n(d){d==="profile"?t.push("/profile"):d==="logout"&&$dialog.confirm({title:o("header.label_logout_dialog_title"),type:"warning",content:o("header.text_logout_confirm"),confirm(){i.logout(),$message.success("您已安全退出登录")}})}return(d,s)=>{const m=Le;return g(),H(m,{options:r,onSelect:n},{default:E(()=>[S("div",yn,[S("span",null,j(C(i).name),1)])]),_:1})}}},Cn={class:"inline-block",viewBox:"0 0 24 24",width:"1em",height:"1em"},zn=S("path",{fill:"currentColor",d:"m3.55 19.09l1.41 1.41l1.8-1.79l-1.42-1.42M12 6c-3.31 0-6 2.69-6 6s2.69 6 6 6s6-2.69 6-6c0-3.32-2.69-6-6-6m8 7h3v-2h-3m-2.76 7.71l1.8 1.79l1.41-1.41l-1.79-1.8M20.45 5l-1.41-1.4l-1.8 1.79l1.42 1.42M13 1h-2v3h2M6.76 5.39L4.96 3.6L3.55 5l1.79 1.81zM1 13h3v-2H1m12 9h-2v3h2"},null,-1),In=[zn];function kn(e,o){return g(),P("svg",Cn,[...In])}const $n={name:"mdi-white-balance-sunny",render:kn},Sn={class:"inline-block",viewBox:"0 0 24 24",width:"1em",height:"1em"},Nn=S("path",{fill:"currentColor",d:"M2 12a10 10 0 0 0 13 9.54a10 10 0 0 1 0-19.08A10 10 0 0 0 2 12"},null,-1),Rn=[Nn];function Pn(e,o){return g(),P("svg",Sn,[...Rn])}const An={name:"mdi-moon-waning-crescent",render:Pn},Ln={__name:"ThemeMode",setup(e){const o=J(),t=no(),i=()=>{o.toggleDark(),ro(t)()};return(r,n)=>{const d=An,s=$n,m=Ae;return g(),H(m,{"mr-20":"","cursor-pointer":"",size:"18",onClick:i},{default:E(()=>[C(t)?(g(),H(d,{key:0})):(g(),H(s,{key:1}))]),_:1})}}},Mn={class:"inline-block",viewBox:"0 0 24 24",width:"1em",height:"1em"},Hn=S("path",{fill:"currentColor",d:"M10 21h4c0 1.1-.9 2-2 2s-2-.9-2-2m11-2v1H3v-1l2-2v-6c0-3.1 2-5.8 5-6.7V4c0-1.1.9-2 2-2s2 .9 2 2v.3c3 .9 5 3.6 5 6.7v6zm-4-8c0-2.8-2.2-5-5-5s-5 2.2-5 5v7h10z"},null,-1),Tn=[Hn];function Bn(e,o){return g(),P("svg",Mn,[...Tn])}const En={name:"mdi-bell-outline",render:Bn};const gt=e=>(ao("data-v-a39f80fa"),e=e(),lo(),e),On={class:"notice-panel"},Fn={class:"notice-head"},Kn=gt(()=>S("strong",null,"消息通知",-1)),Vn={key:0,class:"notice-loading"},Dn={key:1,class:"notice-empty"},jn={key:2,class:"notice-list"},Un={class:"notice-item-head"},Wn={class:"notice-title"},qn=["innerHTML"],Gn={class:"notice-preview-shell"},Yn={class:"notice-preview-list"},Xn=gt(()=>S("div",{class:"notice-preview-head"},"最近10条",-1)),Zn=["onClick"],Jn={class:"preview-item-title"},Qn={class:"preview-item-time"},er={key:0,class:"notice-preview-detail"},tr={class:"preview-detail-head"},or={class:"preview-detail-time"},nr={class:"preview-detail-actions"},rr=["innerHTML"],ir={key:1,class:"notice-empty"},ar={__name:"NoticeBell",setup(e){const o=A(0),t=A([]),i=A(!1),r=A(!1),n=A(null);function d(){return q(this,null,function*(){var a;const c=yield de.getNoticeUnreadCount();o.value=Number(((a=c==null?void 0:c.data)==null?void 0:a.unread_count)||0)})}function s(){return q(this,null,function*(){try{i.value=!0;const c=yield de.getNoticeInbox({page:1,page_size:10});t.value=Array.isArray(c==null?void 0:c.data)?c.data:[]}finally{i.value=!1}})}function m(c){n.value=c}function _(c){return q(this,null,function*(){yield de.readNotice({notice_id:c}),yield Promise.all([d(),s()]),n.value&&n.value.notice_id===c&&(n.value.is_read=!0)})}function u(){return q(this,null,function*(){yield de.readAllNotice(),yield Promise.all([d(),s()]),n.value&&(n.value.is_read=!0)})}return fe(()=>q(this,null,function*(){if(yield Promise.all([d(),s()]),o.value>0&&t.value.length){const c=t.value.find(a=>!a.is_read);n.value=c||t.value[0],r.value=!0}})),(c,a)=>{const z=En;return g(),P(W,null,[B(C(go),{trigger:"click",placement:"bottom-end",width:420},{trigger:E(()=>[B(C(Mo),{value:o.value,max:99,show:o.value>0},{default:E(()=>[B(C(se),{quaternary:"",circle:""},{icon:E(()=>[B(z)]),_:1})]),_:1},8,["value","show"])]),default:E(()=>[S("div",On,[S("div",Fn,[Kn,B(C(se),{text:"",size:"small",onClick:u},{default:E(()=>[ee("全部已读")]),_:1})]),i.value?(g(),P("div",Vn,"加载中...")):t.value.length?(g(),P("div",jn,[(g(!0),P(W,null,ve(t.value,v=>(g(),P("div",{key:v.notice_id,class:ze(["notice-item",{unread:!v.is_read}])},[S("div",Un,[S("span",Wn,j(v.title||"系统通知"),1),v.is_read?re("",!0):(g(),H(C(se),{key:0,text:"",size:"tiny",onClick:f=>_(v.notice_id)},{default:E(()=>[ee("已读")]),_:2},1032,["onClick"]))]),S("div",{class:"notice-content",innerHTML:C(Ze)(v.content_html||"")},null,8,qn)],2))),128))])):(g(),P("div",Dn,"暂无通知"))])]),_:1}),B(C(io),{show:r.value,"onUpdate:show":a[1]||(a[1]=v=>r.value=v),preset:"card",title:"最新通知",style:{width:"840px"},"mask-closable":!0},{default:E(()=>[S("div",Gn,[S("div",Yn,[Xn,(g(!0),P(W,null,ve(t.value,v=>{var f;return g(),P("div",{key:`preview-${v.notice_id}`,class:ze(["notice-preview-item",{active:((f=n.value)==null?void 0:f.notice_id)===v.notice_id,unread:!v.is_read}]),onClick:p=>m(v)},[S("div",Jn,j(v.title||"系统通知"),1),S("div",Qn,j(v.created_at||"-"),1)],10,Zn)}),128))]),n.value?(g(),P("div",er,[S("div",tr,[S("div",null,[S("h3",null,j(n.value.title||"系统通知"),1),S("div",or,j(n.value.created_at||"-"),1)]),S("div",nr,[B(C(mt),{type:n.value.is_read?"default":"warning"},{default:E(()=>[ee(j(n.value.is_read?"已读":"未读"),1)]),_:1},8,["type"]),n.value.is_read?re("",!0):(g(),H(C(se),{key:0,size:"small",type:"primary",ghost:"",onClick:a[0]||(a[0]=v=>_(n.value.notice_id))},{default:E(()=>[ee("标记已读")]),_:1}))])]),S("div",{class:"preview-detail-content",innerHTML:C(Ze)(n.value.content_html||"")},null,8,rr)])):(g(),P("div",ir,"暂无通知"))])]),_:1},8,["show"])],64)}}},lr=Me(ar,[["__scopeId","data-v-a39f80fa"]]),cr={flex:"","items-center":""},sr={"ml-auto":"",flex:"","items-center":""},dr={__name:"index",setup(e){return(o,t)=>(g(),P(W,null,[S("div",cr,[B(sn),B(Zo,{"ml-15":"",hidden:"","sm:block":""})]),S("div",sr,[B(Ln),B(lr),B(xn),B(wn)])],64))}},ur=["src"],mr={__name:"SideLogo",setup(e){const o="安得和众用户服务中心",t=J();return(i,r)=>{const n=bo,d=at("router-link");return g(),H(d,{"h-60":"","f-c-c":"",to:"/"},{default:E(()=>[C(t).siteLogo?(g(),P("img",{key:0,src:C(t).siteLogo,alt:"logo",style:{height:"36px",width:"36px"}},null,8,ur)):(g(),H(n,{key:1,"text-36":"","color-primary":""})),lt(S("h2",{"ml-2":"","mr-8":"","max-w-220":"","flex-shrink-0":"","text-14":"","font-bold":"","color-primary":"","whitespace-nowrap":"","overflow-hidden":"","text-ellipsis":""},j(C(t).siteTitle||C(o)),513),[[co,!C(t).collapsed]])]),_:1})}}};const hr={__name:"SideMenu",setup(e){const o=_e(),t=ge(),i=ct();J();const r=N(()=>{var u;return((u=t.meta)==null?void 0:u.activeMenu)||t.name}),n=N(()=>i.menus.map(u=>s(u)).sort((u,c)=>u.order-c.order));function d(u,c){return Ge(c)?c:"/"+[u,c].filter(a=>!!a&&a!=="/").map(a=>a.replace(/(^\/)|(\/$)/g,"")).join("/")}function s(u,c=""){var v,f;let a={label:u.meta&&u.meta.title||u.name,key:u.name,path:d(c,u.path),icon:m(u.meta),order:((v=u.meta)==null?void 0:v.order)||0};const z=u.children?u.children.filter(p=>p.name&&!p.isHidden):[];if(!z.length)return a;if(z.length===1){const p=z[0];a=We(Ue({},a),{label:((f=p.meta)==null?void 0:f.title)||p.name,key:p.name,path:d(a.path,p.path),icon:m(p.meta)});const I=p.children?p.children.filter(M=>M.name&&!M.isHidden):[];I.length===1?a=s(I[0],a.path):I.length>1&&(a.children=I.map(M=>s(M,a.path)).sort((M,F)=>M.order-F.order))}else a.children=z.map(p=>s(p,a.path)).sort((p,I)=>p.order-I.order),u.redirect&&(a.path=u.redirect);return a}function m(u){return u!=null&&u.customIcon?ut(u.customIcon,{size:18}):u!=null&&u.icon?U(u.icon,{size:18}):null}function _(u,c){if(c!=null&&c.path)if(Ge(c.path))window.open(c.path);else{if(c.path===t.path)return;o.push(c.path).catch(a=>{console.warn("[SideMenu] router.push failed",a)})}}return(u,c)=>{const a=Xo;return g(),H(a,{ref:"menu",class:"side-menu",accordion:"",indent:18,"collapsed-icon-size":22,"collapsed-width":64,options:C(n),value:C(r),"onUpdate:value":_},null,8,["options","value"])}}},vr={__name:"index",setup(e){return(o,t)=>(g(),P(W,null,[B(mr),B(hr)],64))}},fr={};function pr(e,o){const t=at("router-view");return g(),H(t,null,{default:E(({Component:i,route:r})=>[(g(),H(it(i),{key:r.fullPath}))]),_:1})}const _r=Me(fr,[["render",pr]]),gr={__name:"ContextMenu",props:{show:{type:Boolean,default:!1},currentPath:{type:String,default:""},x:{type:Number,default:0},y:{type:Number,default:0}},emits:["update:show"],setup(e,{emit:o}){const t=e,i=o,r=st(),n=J(),d=N(()=>[{label:"重新加载",key:"reload",disabled:t.currentPath!==r.activeTag,icon:U("mdi:refresh",{size:"14px"})},{label:"关闭",key:"close",disabled:r.tags.length<=1,icon:U("mdi:close",{size:"14px"})},{label:"关闭其他",key:"close-other",disabled:r.tags.length<=1,icon:U("mdi:arrow-expand-horizontal",{size:"14px"})},{label:"关闭左侧",key:"close-left",disabled:r.tags.length<=1||t.currentPath===r.tags[0].path,icon:U("mdi:arrow-expand-left",{size:"14px"})},{label:"关闭右侧",key:"close-right",disabled:r.tags.length<=1||t.currentPath===r.tags[r.tags.length-1].path,icon:U("mdi:arrow-expand-right",{size:"14px"})}]),s=ge(),m=new Map([["reload",()=>{var c;(c=s.meta)!=null&&c.keepAlive&&n.setAliveKeys(s.name,+new Date),n.reloadPage()}],["close",()=>{r.removeTag(t.currentPath)}],["close-other",()=>{r.removeOther(t.currentPath)}],["close-left",()=>{r.removeLeft(t.currentPath)}],["close-right",()=>{r.removeRight(t.currentPath)}]]);function _(){i("update:show",!1)}function u(c){const a=m.get(c);a&&a(),_()}return(c,a)=>{const z=Le;return g(),H(z,{show:e.show,options:C(d),x:e.x,y:e.y,placement:"bottom-start",onClickoutside:_,onSelect:u},null,8,["show","options","x","y"])}}},br={class:"inline-block",viewBox:"0 0 24 24",width:"1em",height:"1em"},xr=S("path",{fill:"currentColor",d:"M8.59 16.59L13.17 12L8.59 7.41L10 6l6 6l-6 6z"},null,-1),yr=[xr];function wr(e,o){return g(),P("svg",br,[...yr])}const Cr={name:"ic-baseline-keyboard-arrow-right",render:wr},zr={class:"inline-block",viewBox:"0 0 24 24",width:"1em",height:"1em"},Ir=S("path",{fill:"currentColor",d:"M15.41 16.59L10.83 12l4.58-4.59L14 6l-6 6l6 6z"},null,-1),kr=[Ir];function $r(e,o){return g(),P("svg",zr,[...kr])}const Sr={name:"ic-baseline-keyboard-arrow-left",render:$r};const Nr={__name:"ScrollX",props:{showArrow:{type:Boolean,default:!0}},setup(e,{expose:o}){const t=A(0),i=A(null),r=A(null),n=A(!1),d=Qe(()=>{var z,v;const c=(z=r.value)==null?void 0:z.offsetWidth,a=(v=i.value)==null?void 0:v.offsetWidth;n.value=a>c,m(c,a)},200);function s(c){var f,p;const{wheelDelta:a}=c,z=(f=r.value)==null?void 0:f.offsetWidth,v=(p=i.value)==null?void 0:p.offsetWidth;a<0&&(z>v&&t.value<-10||z<=v&&v+t.value-z<-10)||a>0&&t.value>10||(t.value+=a,m(z,v))}const m=Qe(function(c,a){n.value?-t.value>a-c?t.value=c-a:t.value>0&&(t.value=0):t.value=0},200),_=A(null);fe(()=>{d(),_.value=so(document.body,d)}),uo(()=>{var c;(c=_.value)==null||c.disconnect()});function u(c,a){var f,p;const z=(f=r.value)==null?void 0:f.offsetWidth,v=(p=i.value)==null?void 0:p.offsetWidth;v<=z||(c<-t.value+150&&(t.value=-(c-150),m(z,v)),c+a>-t.value+z&&(t.value=z-(c+a),m(z,v)))}return o({handleScroll:u}),(c,a)=>{const z=Sr,v=Cr,f=mo("resize");return g(),P("div",{ref_key:"wrapper",ref:r,class:"wrapper",onMousewheel:ke(s,["prevent"])},[e.showArrow&&C(n)?(g(),P(W,{key:0},[S("div",{class:"left",onClick:a[0]||(a[0]=p=>s({wheelDelta:120}))},[B(z)]),S("div",{class:"right",onClick:a[1]||(a[1]=p=>s({wheelDelta:-120}))},[B(v)])],64)):re("",!0),lt((g(),P("div",{ref_key:"content",ref:i,class:ze(["content",{overflow:C(n)&&e.showArrow}]),style:Ie({transform:`translateX(${C(t)}px)`})},[ho(c.$slots,"default",{},void 0,!0)],6)),[[f,C(d)]])],544)}}},Rr=Me(Nr,[["__scopeId","data-v-235998f9"]]);const Pr={__name:"index",setup(e){const o=ge(),t=_e(),i=st(),r=ct(),n=A([]),d=A(null),s=dt({show:!1,x:0,y:0,currentPath:""});(()=>{const v=i.tags.filter(f=>!Ye.includes(f.path));v.length!==i.tags.length&&i.setTags(v)})(),me(()=>o.path,()=>{var F;const{name:v,fullPath:f}=o,p=(F=o.meta)==null?void 0:F.title,I=(O=[],Y=[])=>(O.forEach(K=>{K!=null&&K.path&&Y.push(K.path),Array.isArray(K==null?void 0:K.children)&&K.children.length&&I(K.children,Y)}),Y);new Set(I(r.menus||[]).filter(O=>!Ye.includes(O))).has(f)&&i.addTag({name:v,path:f,title:p})},{immediate:!0}),me(()=>i.activeIndex,v=>q(this,null,function*(){var M,F;yield he();const f=(M=n.value[v])==null?void 0:M.$el;if(!f)return;const{offsetLeft:p,offsetWidth:I}=f;(F=d.value)==null||F.handleScroll(p+I,I)}),{immediate:!0});const _=v=>{const f=(M=[],F=[])=>(M.forEach(O=>{O!=null&&O.path&&F.push(O.path),Array.isArray(O==null?void 0:O.children)&&O.children.length&&f(O.children,F)}),F);if(![...new Set(f(r.menus||[]))].includes(v)){$message.warning("当前账号无该页面权限，无法打开");return}i.setActiveTag(v),t.push(v)};function u(){s.show=!0}function c(){s.show=!1}function a(v,f,p){Object.assign(s,{x:v,y:f,currentPath:p})}function z(v,f){return q(this,null,function*(){const{clientX:p,clientY:I}=v;c(),a(p,I,f.path),yield he(),u()})}return(v,f)=>{const p=mt;return g(),H(Rr,{ref_key:"scrollXRef",ref:d,class:"bg-white dark:bg-dark!"},{default:E(()=>[(g(!0),P(W,null,ve(C(i).tags,I=>(g(),H(p,{ref_for:!0,ref_key:"tabRefs",ref:n,key:I.path,class:"mx-5 cursor-pointer rounded-4 px-15 hover:color-primary",type:C(i).activeTag===I.path?"primary":"default",closable:C(i).tags.length>1,onClick:M=>_(I.path),onClose:ke(M=>C(i).removeTag(I.path),["stop"]),onContextmenu:ke(M=>z(M,I),["prevent"])},{default:E(()=>[ee(j(I.title),1)]),_:2},1032,["type","closable","onClick","onClose","onContextmenu"]))),128)),C(s).show?(g(),H(gr,{key:0,show:C(s).show,"onUpdate:show":f[0]||(f[0]=I=>C(s).show=I),"current-path":C(s).currentPath,x:C(s).x,y:C(s).y},null,8,["show","current-path","x","y"])):re("",!0)]),_:1},512)}}},Ar={"flex-col":"","flex-1":"","overflow-hidden":""},Lr={key:0,hidden:"","border-b":"","bc-eee":"","sm:block":"","dark:border-0":""},Mr={"flex-1":"","overflow-hidden":"","bg-hex-f5f6fb":"","dark:bg-hex-101014":""},Jr={__name:"index",setup(e){const o=J(),i=dt(vo({xl:1600,lg:1199,md:991,sm:666,xs:575})),r=i.smaller("sm"),n=i.between("sm","md"),d=i.greater("md");return Ce(()=>{r.value&&(o.setCollapsed(!0),o.setFullScreen(!1)),n.value&&(o.setCollapsed(!0),o.setFullScreen(!1)),d.value&&(o.setCollapsed(!1),o.setFullScreen(!0))}),(s,m)=>{const _=yo,u=wo;return g(),H(u,{"has-sider":"","wh-full":""},{default:E(()=>[B(_,{bordered:"","collapse-mode":"width","collapsed-width":64,width:220,"native-scrollbar":!1,collapsed:C(o).collapsed},{default:E(()=>[B(vr)]),_:1},8,["collapsed"]),S("article",Ar,[S("header",{class:"flex items-center border-b bg-white px-15 bc-eee",dark:"bg-dark border-0",style:Ie(`height: ${C(fo).height}px`)},[B(dr)],4),C(Xe).visible?(g(),P("section",Lr,[B(Pr,{style:Ie({height:`${C(Xe).height}px`})},null,8,["style"])])):re("",!0),S("section",Mr,[B(_r)])])]),_:1})}}};export{Jr as default};
