import{w as i,c as a}from"./index-133a0582.js";function s(u,e){return i(u,r=>{r!==void 0&&(e.value=r)}),a(()=>u.value===void 0?e.value:u.value)}export{s as u};
