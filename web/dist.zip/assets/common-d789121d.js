import{bI as e}from"./index-5b5f01f8.js";function n(t=void 0,a="YYYY-MM-DD HH:mm:ss"){return e(t).format(a)}function f(t=void 0,a="YYYY-MM-DD"){return n(t,a)}export{f as a,n as f};
