import{_ as xe}from"./CrudModal-f7549c5a.js";import{F as ze,j as Ce,d6 as Se,e as v,g as M,a as A,i as p,d as de,l as me,m as ue,C as $e,h as w,D as Te,G as je,a_ as Ie,c as T,s as L,bp as Be,v as Me,bF as oe,z as se,r as j,w as Ae,ak as P,au as Le,Y as r,$ as u,ag as $,_ as z,a7 as e,a4 as l,a1 as g,a3 as R,I as U,a0 as X,ab as O,Z as I,ah as ee,ai as Pe,aj as Re,al as Ue,am as Oe}from"./index-ad7b4e66.js";import{i as ae,s as te}from"./sanitize-0635dc57.js";import{_ as Ne}from"./_plugin-vue_export-helper-c27b6911.js";import{N as ie}from"./Spin-19a29119.js";import{b as ce}from"./Select-3b30635f.js";import{N as De}from"./Tag-dd8bd7cf.js";let re=!1;function Ee(){if(ze&&window.CSS&&!re&&(re=!0,"registerProperty"in window?.CSS))try{CSS.registerProperty({name:"--n-color-start",syntax:"<color>",inherits:!1,initialValue:"#0000"}),CSS.registerProperty({name:"--n-color-end",syntax:"<color>",inherits:!1,initialValue:"#0000"})}catch{}}function Fe(t){const{textColor3:a,infoColor:h,errorColor:_,successColor:d,warningColor:f,textColor1:k,textColor2:b,railColor:x,fontWeightStrong:C,fontSize:S}=t;return Object.assign(Object.assign({},Se),{contentFontSize:S,titleFontWeight:C,circleBorder:`2px solid ${a}`,circleBorderInfo:`2px solid ${h}`,circleBorderError:`2px solid ${_}`,circleBorderSuccess:`2px solid ${d}`,circleBorderWarning:`2px solid ${f}`,iconColor:a,iconColorInfo:h,iconColorError:_,iconColorSuccess:d,iconColorWarning:f,titleTextColor:k,contentTextColor:b,metaTextColor:a,lineColor:x})}const Ve={name:"Timeline",common:Ce,self:Fe},He=Ve,le=1.25,We=v("timeline",`
 position: relative;
 width: 100%;
 display: flex;
 flex-direction: column;
 line-height: ${le};
`,[M("horizontal",`
 flex-direction: row;
 `,[A(">",[v("timeline-item",`
 flex-shrink: 0;
 padding-right: 40px;
 `,[M("dashed-line-type",[A(">",[v("timeline-item-timeline",[p("line",`
 background-image: linear-gradient(90deg, var(--n-color-start), var(--n-color-start) 50%, transparent 50%, transparent 100%);
 background-size: 10px 1px;
 `)])])]),A(">",[v("timeline-item-content",`
 margin-top: calc(var(--n-icon-size) + 12px);
 `,[A(">",[p("meta",`
 margin-top: 6px;
 margin-bottom: unset;
 `)])]),v("timeline-item-timeline",`
 width: 100%;
 height: calc(var(--n-icon-size) + 12px);
 `,[p("line",`
 left: var(--n-icon-size);
 top: calc(var(--n-icon-size) / 2 - 1px);
 right: 0px;
 width: unset;
 height: 2px;
 `)])])])])]),M("right-placement",[v("timeline-item",[v("timeline-item-content",`
 text-align: right;
 margin-right: calc(var(--n-icon-size) + 12px);
 `),v("timeline-item-timeline",`
 width: var(--n-icon-size);
 right: 0;
 `)])]),M("left-placement",[v("timeline-item",[v("timeline-item-content",`
 margin-left: calc(var(--n-icon-size) + 12px);
 `),v("timeline-item-timeline",`
 left: 0;
 `)])]),v("timeline-item",`
 position: relative;
 `,[A("&:last-child",[v("timeline-item-timeline",[p("line",`
 display: none;
 `)]),v("timeline-item-content",[p("meta",`
 margin-bottom: 0;
 `)])]),v("timeline-item-content",[p("title",`
 margin: var(--n-title-margin);
 font-size: var(--n-title-font-size);
 transition: color .3s var(--n-bezier);
 font-weight: var(--n-title-font-weight);
 color: var(--n-title-text-color);
 `),p("content",`
 transition: color .3s var(--n-bezier);
 font-size: var(--n-content-font-size);
 color: var(--n-content-text-color);
 `),p("meta",`
 transition: color .3s var(--n-bezier);
 font-size: 12px;
 margin-top: 6px;
 margin-bottom: 20px;
 color: var(--n-meta-text-color);
 `)]),M("dashed-line-type",[v("timeline-item-timeline",[p("line",`
 --n-color-start: var(--n-line-color);
 transition: --n-color-start .3s var(--n-bezier);
 background-color: transparent;
 background-image: linear-gradient(180deg, var(--n-color-start), var(--n-color-start) 50%, transparent 50%, transparent 100%);
 background-size: 1px 10px;
 `)])]),v("timeline-item-timeline",`
 width: calc(var(--n-icon-size) + 12px);
 position: absolute;
 top: calc(var(--n-title-font-size) * ${le} / 2 - var(--n-icon-size) / 2);
 height: 100%;
 `,[p("circle",`
 border: var(--n-circle-border);
 transition:
 background-color .3s var(--n-bezier),
 border-color .3s var(--n-bezier);
 width: var(--n-icon-size);
 height: var(--n-icon-size);
 border-radius: var(--n-icon-size);
 box-sizing: border-box;
 `),p("icon",`
 color: var(--n-icon-color);
 font-size: var(--n-icon-size);
 height: var(--n-icon-size);
 width: var(--n-icon-size);
 display: flex;
 align-items: center;
 justify-content: center;
 `),p("line",`
 transition: background-color .3s var(--n-bezier);
 position: absolute;
 top: var(--n-icon-size);
 left: calc(var(--n-icon-size) / 2 - 1px);
 bottom: 0px;
 width: 2px;
 background-color: var(--n-line-color);
 `)])])]),qe=Object.assign(Object.assign({},ue.props),{horizontal:Boolean,itemPlacement:{type:String,default:"left"},size:{type:String,default:"medium"},iconSize:Number}),he=Te("n-timeline"),Ke=de({name:"Timeline",props:qe,setup(t,{slots:a}){const{mergedClsPrefixRef:h}=me(t),_=ue("Timeline","-timeline",We,He,t,h);return $e(he,{props:t,mergedThemeRef:_,mergedClsPrefixRef:h}),()=>{const{value:d}=h;return w("div",{class:[`${d}-timeline`,t.horizontal&&`${d}-timeline--horizontal`,`${d}-timeline--${t.size}-size`,!t.horizontal&&`${d}-timeline--${t.itemPlacement}-placement`]},a)}}}),Ge={time:[String,Number],title:String,content:String,color:String,lineType:{type:String,default:"default"},type:{type:String,default:"default"}},Ye=de({name:"TimelineItem",props:Ge,setup(t){const a=je(he);a||Ie("timeline-item","`n-timeline-item` must be placed inside `n-timeline`."),Ee();const{inlineThemeDisabled:h}=me(),_=T(()=>{const{props:{size:f,iconSize:k},mergedThemeRef:b}=a,{type:x}=t,{self:{titleTextColor:C,contentTextColor:S,metaTextColor:H,lineColor:W,titleFontWeight:q,contentFontSize:K,[L("iconSize",f)]:B,[L("titleMargin",f)]:N,[L("titleFontSize",f)]:G,[L("circleBorder",x)]:D,[L("iconColor",x)]:Y},common:{cubicBezierEaseInOut:E}}=b.value;return{"--n-bezier":E,"--n-circle-border":D,"--n-icon-color":Y,"--n-content-font-size":K,"--n-content-text-color":S,"--n-line-color":W,"--n-meta-text-color":H,"--n-title-font-size":G,"--n-title-font-weight":q,"--n-title-margin":N,"--n-title-text-color":C,"--n-icon-size":Be(k)||B}}),d=h?Me("timeline-item",T(()=>{const{props:{size:f,iconSize:k}}=a,{type:b}=t;return`${f[0]}${k||"a"}${b[0]}`}),_,a.props):void 0;return{mergedClsPrefix:a.mergedClsPrefixRef,cssVars:h?void 0:_,themeClass:d?.themeClass,onRender:d?.onRender}},render(){const{mergedClsPrefix:t,color:a,onRender:h,$slots:_}=this;return h?.(),w("div",{class:[`${t}-timeline-item`,this.themeClass,`${t}-timeline-item--${this.type}-type`,`${t}-timeline-item--${this.lineType}-line-type`],style:this.cssVars},w("div",{class:`${t}-timeline-item-timeline`},w("div",{class:`${t}-timeline-item-timeline__line`}),oe(_.icon,d=>d?w("div",{class:`${t}-timeline-item-timeline__icon`,style:{color:a}},d):w("div",{class:`${t}-timeline-item-timeline__circle`,style:{borderColor:a}}))),w("div",{class:`${t}-timeline-item-content`},oe(_.header,d=>d||this.title?w("div",{class:`${t}-timeline-item-content__title`},d||this.title):null),w("div",{class:`${t}-timeline-item-content__content`},se(_.default,()=>[this.content])),w("div",{class:`${t}-timeline-item-content__meta`},se(_.footer,()=>[this.time]))))}}),Ze={pending_review:"warning",cs_rejected:"error",tech_processing:"info",field_verification:"warning",pending_close:"success",tech_rejected:"error",done:"success"},_e={pending_review:"审核中",cs_rejected:"客服驳回",tech_processing:"技术处理中",field_verification:"现场验证",pending_close:"待关闭",tech_rejected:"技术驳回",done:"已关闭"},Ri=Object.entries(_e).map(([t,a])=>({value:t,label:a}));function Je(t){return{submit:"提交工单",resubmit:"重新提交",cs_approve:"客服通过",cs_reject:"客服驳回",tech_start:"技术接手",tech_assign:"改派技术",tech_note:"处理备注",field_verify:"现场验证",field_reject:"验证不通过",tech_reject:"技术驳回",finish:"处理完成",close:"关闭工单"}[t]||t||"-"}const s=t=>(Ue("data-v-876328d9"),t=t(),Oe(),t),Qe={class:"detail-header"},Xe={class:"detail-no"},et={class:"detail-title"},tt={class:"detail-grid"},it={class:"detail-card"},nt=s(()=>e("span",null,"项目名称",-1)),ot={class:"detail-card"},st=s(()=>e("span",null,"联系人",-1)),at={class:"detail-card"},ct=s(()=>e("span",null,"联系方式",-1)),rt={class:"detail-card"},lt=s(()=>e("span",null,"项目阶段",-1)),dt={class:"detail-card"},mt=s(()=>e("span",null,"跟踪",-1)),ut={class:"detail-card"},ht=s(()=>e("span",null,"影响范围",-1)),_t={class:"detail-card"},vt=s(()=>e("span",null,"问题分类",-1)),gt={class:"detail-card"},ft=s(()=>e("span",null,"创建时间",-1)),pt={class:"detail-card"},kt=s(()=>e("span",null,"提交人",-1)),bt={class:"detail-card"},yt=s(()=>e("span",null,"附件数量",-1)),wt={class:"detail-card"},xt=s(()=>e("span",null,"客服审核人",-1)),zt={class:"detail-card"},Ct=s(()=>e("span",null,"指派技术",-1)),St={class:"detail-card"},$t=s(()=>e("span",null,"问题根因",-1)),Tt={class:"detail-card detail-card-wide"},jt=s(()=>e("span",null,"完成时间",-1)),It={class:"detail-card"},Bt=s(()=>e("span",null,"Redmine工单",-1)),Mt=["href"],At={class:"detail-card"},Lt=s(()=>e("span",null,"Redmine状态",-1)),Pt={class:"detail-card"},Rt=s(()=>e("span",null,"Redmine同步时间",-1)),Ut={class:"description-card"},Ot=s(()=>e("div",{class:"section-title"},"问题描述",-1)),Nt={key:0,class:"detail-loading"},Dt=s(()=>e("span",null,"详情加载中...",-1)),Et=["innerHTML"],Ft={class:"detail-secondary-grid"},Vt={class:"attachment-card"},Ht=s(()=>e("div",{class:"section-title"},"附件列表",-1)),Wt={key:0,class:"detail-loading"},qt=s(()=>e("span",null,"附件加载中...",-1)),Kt={key:1,class:"image-preview-grid"},Gt=["href"],Yt=["src","alt"],Zt={key:2,class:"attachment-list"},Jt={class:"attachment-name"},Qt={class:"attachment-meta"},Xt={class:"attachment-actions"},ei={class:"timeline-card"},ti=s(()=>e("div",{class:"section-title"},"流转日志",-1)),ii={key:0,class:"detail-loading"},ni=s(()=>e("span",null,"流转日志加载中...",-1)),oi={key:0,viewBox:"0 0 24 24","aria-hidden":"true"},si=s(()=>e("path",{d:"M5 12.5l3.2 3.2L14 10"},null,-1)),ai=s(()=>e("path",{d:"M10 12.5l3.2 3.2L19 10"},null,-1)),ci=[si,ai],ri={key:1,viewBox:"0 0 24 24","aria-hidden":"true"},li=s(()=>e("circle",{cx:"12",cy:"12",r:"3.5",fill:"currentColor",stroke:"none"},null,-1)),di=[li],mi={key:2,viewBox:"0 0 24 24","aria-hidden":"true"},ui=s(()=>e("path",{d:"M16.5 7.5A6 6 0 1 0 18 12"},null,-1)),hi=s(()=>e("path",{d:"M16.5 4.5v3h-3"},null,-1)),_i=[ui,hi],vi={key:3,viewBox:"0 0 24 24","aria-hidden":"true"},gi=s(()=>e("path",{d:"M8 8l8 8"},null,-1)),fi=s(()=>e("path",{d:"M16 8l-8 8"},null,-1)),pi=[gi,fi],ki={key:4,viewBox:"0 0 24 24","aria-hidden":"true"},bi=s(()=>e("path",{d:"M6 12.5l4 4L18 8.5"},null,-1)),yi=[bi],wi={class:"timeline-content"},xi=["innerHTML"],zi={class:"timeline-meta"},Ci={key:0,class:"timeline-meta"},Si={class:"description-image-preview"},$i=["src","alt"],Ti={__name:"TicketDetailModal",props:{visible:{type:Boolean,default:!1},ticket:{type:Object,default(){return{}}},loading:{type:Boolean,default:!1}},emits:["update:visible"],setup(t){const a=t,h=T(()=>a.ticket?.attachments||[]),_=T(()=>h.value.filter(i=>ae(i.origin_name||i.file_path||""))),d=new Set(["docx","pptx","xlsx"]),f=j(null),k=j({}),b=j({}),x=j(!1),C=j(""),S=j(""),H=T(()=>te(a.ticket?.description||"-")),W=T(()=>Array.isArray(a.ticket?.actions)&&a.ticket.actions.length>0),q={never:"未同步",success:"同步成功",failed:"同步失败",syncing:"同步中"},K=T(()=>a.ticket?.redmine_status_name||q[a.ticket?.redmine_sync_status]||"-");function B(){Object.values(k.value||{}).forEach(i=>{i&&URL.revokeObjectURL(i)}),Object.values(b.value||{}).forEach(i=>{i&&URL.revokeObjectURL(i)})}function N(i){return k.value[i.id]||""}function G(){x.value=!1,C.value="",S.value=""}function D(i){const o=i?.target;if(!(o instanceof HTMLImageElement))return;const c=o.currentSrc||o.src;c&&(i.preventDefault(),C.value=c,S.value=o.alt||"问题描述图片",x.value=!0)}function Y(i){D(i)}function E(i){const c=String(i||"").match(/[?&]attachment_id=(\d+)/);return c?Number(c[1]):null}function ne(i,o){return`${i||"action"}:${o}`}function ve(i){const o=[],c=new Set;for(const m of i||[]){const n=String(m?.comment||""),V=new DOMParser().parseFromString(n,"text/html");for(const we of Array.from(V.querySelectorAll("img[src]"))){const J=E(we.getAttribute("src"));if(!J)continue;const Q=ne(m.id,J);c.has(Q)||(c.add(Q),o.push({key:Q,attachmentId:J}))}}return o}Ae(()=>[a.visible,a.ticket?.id,_.value.map(i=>i.id).join(","),(a.ticket?.actions||[]).map(i=>`${i.id}:${i.updated_at||i.created_at||""}`).join(",")],async([i])=>{if(!i){B(),k.value={},b.value={},G();return}B();const o={};for(const m of _.value)try{const n=await P.downloadTicketAttachment({attachment_id:m.id}),y=n instanceof Blob?n:new Blob([n]);o[m.id]=URL.createObjectURL(y)}catch{o[m.id]=""}k.value=o;const c={};for(const m of ve(a.ticket?.actions||[]))try{const n=await P.downloadTicketAttachment({attachment_id:m.attachmentId}),y=n instanceof Blob?n:new Blob([n]);c[m.key]=URL.createObjectURL(y)}catch{c[m.key]=""}b.value=c},{immediate:!0}),Le(()=>{B(),k.value={},b.value={}});async function ge(i){if(!i?.id)return;const o=await P.downloadTicketAttachment({attachment_id:i.id}),c=o instanceof Blob?o:new Blob([o]),m=window.URL.createObjectURL(c),n=document.createElement("a");n.href=m,n.download=i.origin_name||`attachment-${i.id}`,document.body.appendChild(n),n.click(),n.remove(),window.URL.revokeObjectURL(m)}function fe(i){const c=String(i?.origin_name||i?.file_path||"").split(".").pop()?.toLowerCase();return d.has(c)}async function pe(i){if(i?.id){f.value=i.id;try{const c=(await P.previewTicketAttachment({attachment_id:i.id}))?.data?.preview_url||"";if(!c){$message.error("预览链接生成失败，请稍后重试");return}const m=`/public/webdav/preview?${new URLSearchParams({name:i.origin_name||`attachment-${i.id}`,url:c}).toString()}`;window.open(m,"_blank","noopener,noreferrer")}finally{f.value=null}}}async function ke(i){const o=await P.downloadTicketAttachment({attachment_id:i.id}),c=o instanceof Blob?o:new Blob([o]);if(!c.type.startsWith("image/")){$message.warning("仅支持复制图片附件");return}await navigator.clipboard.write([new ClipboardItem({[c.type]:c})]),$message.success("图片已复制")}function be(i){if(!i)return"-";if(i.action==="finish"&&a.ticket?.root_cause){const n=i.comment?.trim()||"处理完成";return te(`${n}（根因：${a.ticket.root_cause}）`)}const o=te(i.comment||"-"),m=new DOMParser().parseFromString(o,"text/html");for(const n of Array.from(m.querySelectorAll("img[src]"))){const y=E(n.getAttribute("src"));if(!y)continue;const V=b.value[ne(i.id,y)];V&&n.setAttribute("src",V)}return m.body.innerHTML}function Z(i){return i==="cs_reject"||i==="tech_reject"}function F(i){return i==="finish"?"finish":i==="submit"||i==="resubmit"?"submit":i==="tech_start"?"handle":Z(i)?"reject":"pass"}function ye(i){return Z(i)?"is-reject":i==="finish"?"is-finish":i==="submit"||i==="resubmit"?"is-submit":i==="tech_start"?"is-handle":"is-pass"}return(i,o)=>{const c=Ye,m=Ke;return r(),u(U,null,[$(xe,{visible:t.visible,title:"工单详情",width:"min(96vw, 1280px)","show-footer":!1,"onUpdate:visible":o[0]||(o[0]=n=>i.$emit("update:visible",n))},{default:z(()=>[e("div",Qe,[e("div",null,[e("div",Xe,l(t.ticket.ticket_no),1),e("div",et,l(t.ticket.title),1)]),$(g(De),{type:g(Ze)[t.ticket.status]||"default"},{default:z(()=>[R(l(g(_e)[t.ticket.status]||"-"),1)]),_:1},8,["type"])]),e("div",tt,[e("div",it,[nt,e("strong",null,l(t.ticket.company_name||"-"),1)]),e("div",ot,[st,e("strong",null,l(t.ticket.contact_name||"-"),1)]),e("div",at,[ct,e("strong",null,l(t.ticket.phone||"-"),1)]),e("div",rt,[lt,e("strong",null,l(t.ticket.project_phase||"-"),1)]),e("div",dt,[mt,e("strong",null,l(t.ticket.issue_type||"-"),1)]),e("div",ut,[ht,e("strong",null,l(t.ticket.impact_scope||"-"),1)]),e("div",_t,[vt,e("strong",null,l(t.ticket.category||"-"),1)]),e("div",gt,[ft,e("strong",null,l(t.ticket.created_at||"-"),1)]),e("div",pt,[kt,e("strong",null,l(t.ticket.submitter_name||t.ticket.submitter_id||"-"),1)]),e("div",bt,[yt,e("strong",null,l(t.ticket.attachment_count??h.value.length),1)]),e("div",wt,[xt,e("strong",null,l(t.ticket.reviewer_name||t.ticket.reviewer_id||"-"),1)]),e("div",zt,[Ct,e("strong",null,l(t.ticket.tech_name||t.ticket.tech_id||"-"),1)]),e("div",St,[$t,e("strong",null,l(t.ticket.root_cause||"-"),1)]),e("div",Tt,[jt,e("strong",null,l(t.ticket.finished_at||"-"),1)]),e("div",It,[Bt,e("strong",null,[t.ticket.redmine_issue_url?(r(),u("a",{key:0,href:t.ticket.redmine_issue_url,target:"_blank",rel:"noopener"}," #"+l(t.ticket.redmine_issue_id),9,Mt)):(r(),u(U,{key:1},[R(l(t.ticket.redmine_issue_id?`#${t.ticket.redmine_issue_id}`:"-"),1)],64))])]),e("div",At,[Lt,e("strong",null,l(K.value),1)]),e("div",Pt,[Rt,e("strong",null,l(t.ticket.redmine_synced_at||"-"),1)])]),e("div",Ut,[Ot,t.loading?(r(),u("div",Nt,[$(g(ie),{size:"small"}),Dt])):(r(),u("div",{key:1,class:"description-content",onClick:D,innerHTML:H.value},null,8,Et))]),e("div",Ft,[e("div",Vt,[Ht,t.loading?(r(),u("div",Wt,[$(g(ie),{size:"small"}),qt])):_.value.length?(r(),u("div",Kt,[(r(!0),u(U,null,X(_.value,n=>(r(),u("a",{key:`img-${n.id}`,href:N(n),target:"_blank",rel:"noopener",class:"image-preview-item"},[e("img",{src:N(n),alt:n.origin_name||`image-${n.id}`},null,8,Yt)],8,Gt))),128))])):O("",!0),!t.loading&&h.value.length?(r(),u("div",Zt,[(r(!0),u(U,null,X(h.value,n=>(r(),u("div",{key:n.id,class:"attachment-item"},[e("div",null,[e("div",Jt,l(n.origin_name||n.file_path),1),e("div",Qt,l(n.mime_type||"application/octet-stream")+" / "+l(n.file_size||0)+" bytes",1)]),e("div",Xt,[g(ae)(n.origin_name||n.file_path||"")?(r(),I(g(ee),{key:0,size:"small",type:"info",quaternary:"",onClick:y=>ke(n)},{default:z(()=>[R("复制图片")]),_:2},1032,["onClick"])):O("",!0),fe(n)?(r(),I(g(ee),{key:1,size:"small",type:"info",quaternary:"",loading:f.value===n.id,onClick:y=>pe(n)},{default:z(()=>[R(" 预览 ")]),_:2},1032,["loading","onClick"])):O("",!0),$(g(ee),{size:"small",type:"primary",quaternary:"",onClick:y=>ge(n)},{default:z(()=>[R("下载")]),_:2},1032,["onClick"])])]))),128))])):t.loading?O("",!0):(r(),I(g(ce),{key:3,description:"暂无附件",size:"small"}))]),e("div",ei,[ti,t.loading?(r(),u("div",ii,[$(g(ie),{size:"small"}),ni])):W.value?(r(),I(m,{key:1,class:"ticket-timeline"},{default:z(()=>[(r(!0),u(U,null,X(t.ticket.actions||[],n=>(r(),I(c,{key:n.id,title:g(Je)(n.action),type:Z(n.action)?"error":"success"},{icon:z(()=>[e("span",{class:Pe(["timeline-icon",ye(n.action)])},[F(n.action)==="finish"?(r(),u("svg",oi,ci)):F(n.action)==="submit"?(r(),u("svg",ri,di)):F(n.action)==="handle"?(r(),u("svg",mi,_i)):F(n.action)==="reject"?(r(),u("svg",vi,pi)):(r(),u("svg",ki,yi))],2)]),default:z(()=>[e("div",wi,[e("div",{class:"timeline-comment",onClick:Y,innerHTML:be(n)},null,8,xi),e("div",zi,"操作者："+l(n.operator_display||n.operator_name||n.operator_id||"-"),1),n.created_at?(r(),u("div",Ci,"时间："+l(n.created_at),1)):O("",!0)])]),_:2},1032,["title","type"]))),128))]),_:1})):(r(),I(g(ce),{key:2,description:"暂无流转日志",size:"small"}))])])]),_:1},8,["visible"]),$(g(Re),{show:x.value,"onUpdate:show":o[1]||(o[1]=n=>x.value=n),preset:"card",title:"图片预览",class:"description-image-modal"},{default:z(()=>[e("div",Si,[e("img",{src:C.value,alt:S.value},null,8,$i)])]),_:1},8,["show"])],64)}}},Ui=Ne(Ti,[["__scopeId","data-v-876328d9"]]);export{Ui as T,Ze as a,Ri as b,_e as t};
