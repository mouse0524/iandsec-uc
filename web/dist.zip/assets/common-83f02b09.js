import{bE as n}from"./index-a0d8da7b.js";function r(t=void 0,e="YYYY-MM-DD HH:mm:ss"){return n(t).format(e)}function a(t=void 0,e="YYYY-MM-DD"){return r(t,e)}export{a as f};
