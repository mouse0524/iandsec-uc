import{c as t}from"./index-a0d8da7b.js";function f(n,o){return t(()=>{for(const r of o)if(n[r]!==void 0)return n[r];return n[o[o.length-1]]})}export{f as u};
