import{b8 as te,h as t,d as Q,F as Ne,m as he,D as Oe,aV as rt,j as lt,cw as at,a as M,e as w,bu as _e,k as st,O as dt,t as S,r as H,w as ut,bV as Ce,bT as se,aA as Ae,G as ne,c as $,l as ge,v as Ve,bb as ct,J as F,by as ft,ao as Me,bx as ht,y as xe,I as fe,ap as gt,au as vt,d6 as mt,U as Le,bk as pt,C as Se,p as Fe,R as ke,ax as ve,z as wt,N as Xe,K as bt,ah as de,bJ as Ct,bi as xt,g as A,P as Ue,i as J,bM as yt,d7 as Rt,aY as Tt,aR as Lt,n as kt,S as je}from"./index-92d9d798.js";import{A as Pt}from"./Add-d779feea.js";import{_ as Ot}from"./Progress-cda9b7d7.js";import{u as St}from"./use-locale-28dc41a7.js";import{_ as It}from"./Tooltip-49a259ad.js";import{c as Bt}from"./Popover-09bb4e0e.js";import{d as Ze}from"./download-953ccaa2.js";import{E as zt}from"./Input-14da3799.js";import{u as Dt}from"./use-merged-state-25d54541.js";const _t=te("attach",t("svg",{viewBox:"0 0 16 16",version:"1.1",xmlns:"http://www.w3.org/2000/svg"},t("g",{stroke:"none","stroke-width":"1",fill:"none","fill-rule":"evenodd"},t("g",{fill:"currentColor","fill-rule":"nonzero"},t("path",{d:"M3.25735931,8.70710678 L7.85355339,4.1109127 C8.82986412,3.13460197 10.4127766,3.13460197 11.3890873,4.1109127 C12.365398,5.08722343 12.365398,6.67013588 11.3890873,7.64644661 L6.08578644,12.9497475 C5.69526215,13.3402718 5.06209717,13.3402718 4.67157288,12.9497475 C4.28104858,12.5592232 4.28104858,11.9260582 4.67157288,11.5355339 L9.97487373,6.23223305 C10.1701359,6.0369709 10.1701359,5.72038841 9.97487373,5.52512627 C9.77961159,5.32986412 9.4630291,5.32986412 9.26776695,5.52512627 L3.96446609,10.8284271 C3.18341751,11.6094757 3.18341751,12.8758057 3.96446609,13.6568542 C4.74551468,14.4379028 6.01184464,14.4379028 6.79289322,13.6568542 L12.0961941,8.35355339 C13.4630291,6.98671837 13.4630291,4.77064094 12.0961941,3.40380592 C10.7293591,2.0369709 8.51328163,2.0369709 7.14644661,3.40380592 L2.55025253,8 C2.35499039,8.19526215 2.35499039,8.51184464 2.55025253,8.70710678 C2.74551468,8.90236893 3.06209717,8.90236893 3.25735931,8.70710678 Z"}))))),Mt=te("trash",t("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 512 512"},t("path",{d:"M432,144,403.33,419.74A32,32,0,0,1,371.55,448H140.46a32,32,0,0,1-31.78-28.26L80,144",style:"fill: none; stroke: currentcolor; stroke-linecap: round; stroke-linejoin: round; stroke-width: 32px;"}),t("rect",{x:"32",y:"64",width:"448",height:"80",rx:"16",ry:"16",style:"fill: none; stroke: currentcolor; stroke-linecap: round; stroke-linejoin: round; stroke-width: 32px;"}),t("line",{x1:"312",y1:"240",x2:"200",y2:"352",style:"fill: none; stroke: currentcolor; stroke-linecap: round; stroke-linejoin: round; stroke-width: 32px;"}),t("line",{x1:"312",y1:"352",x2:"200",y2:"240",style:"fill: none; stroke: currentcolor; stroke-linecap: round; stroke-linejoin: round; stroke-width: 32px;"}))),We=te("download",t("svg",{viewBox:"0 0 16 16",version:"1.1",xmlns:"http://www.w3.org/2000/svg"},t("g",{stroke:"none","stroke-width":"1",fill:"none","fill-rule":"evenodd"},t("g",{fill:"currentColor","fill-rule":"nonzero"},t("path",{d:"M3.5,13 L12.5,13 C12.7761424,13 13,13.2238576 13,13.5 C13,13.7454599 12.8231248,13.9496084 12.5898756,13.9919443 L12.5,14 L3.5,14 C3.22385763,14 3,13.7761424 3,13.5 C3,13.2545401 3.17687516,13.0503916 3.41012437,13.0080557 L3.5,13 L12.5,13 L3.5,13 Z M7.91012437,1.00805567 L8,1 C8.24545989,1 8.44960837,1.17687516 8.49194433,1.41012437 L8.5,1.5 L8.5,10.292 L11.1819805,7.6109127 C11.3555469,7.43734635 11.6249713,7.4180612 11.8198394,7.55305725 L11.8890873,7.6109127 C12.0626536,7.78447906 12.0819388,8.05390346 11.9469427,8.2487716 L11.8890873,8.31801948 L8.35355339,11.8535534 C8.17998704,12.0271197 7.91056264,12.0464049 7.7156945,11.9114088 L7.64644661,11.8535534 L4.1109127,8.31801948 C3.91565056,8.12275734 3.91565056,7.80617485 4.1109127,7.6109127 C4.28447906,7.43734635 4.55390346,7.4180612 4.7487716,7.55305725 L4.81801948,7.6109127 L7.5,10.292 L7.5,1.5 C7.5,1.25454011 7.67687516,1.05039163 7.91012437,1.00805567 L8,1 L7.91012437,1.00805567 Z"}))))),Ft=te("cancel",t("svg",{viewBox:"0 0 16 16",version:"1.1",xmlns:"http://www.w3.org/2000/svg"},t("g",{stroke:"none","stroke-width":"1",fill:"none","fill-rule":"evenodd"},t("g",{fill:"currentColor","fill-rule":"nonzero"},t("path",{d:"M2.58859116,2.7156945 L2.64644661,2.64644661 C2.82001296,2.47288026 3.08943736,2.45359511 3.2843055,2.58859116 L3.35355339,2.64644661 L8,7.293 L12.6464466,2.64644661 C12.8417088,2.45118446 13.1582912,2.45118446 13.3535534,2.64644661 C13.5488155,2.84170876 13.5488155,3.15829124 13.3535534,3.35355339 L8.707,8 L13.3535534,12.6464466 C13.5271197,12.820013 13.5464049,13.0894374 13.4114088,13.2843055 L13.3535534,13.3535534 C13.179987,13.5271197 12.9105626,13.5464049 12.7156945,13.4114088 L12.6464466,13.3535534 L8,8.707 L3.35355339,13.3535534 C3.15829124,13.5488155 2.84170876,13.5488155 2.64644661,13.3535534 C2.45118446,13.1582912 2.45118446,12.8417088 2.64644661,12.6464466 L7.293,8 L2.64644661,3.35355339 C2.47288026,3.17998704 2.45359511,2.91056264 2.58859116,2.7156945 L2.64644661,2.64644661 L2.58859116,2.7156945 Z"}))))),Ut=te("retry",t("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 512 512"},t("path",{d:"M320,146s24.36-12-64-12A160,160,0,1,0,416,294",style:"fill: none; stroke: currentcolor; stroke-linecap: round; stroke-miterlimit: 10; stroke-width: 32px;"}),t("polyline",{points:"256 58 336 138 256 218",style:"fill: none; stroke: currentcolor; stroke-linecap: round; stroke-linejoin: round; stroke-width: 32px;"}))),jt=te("rotateClockwise",t("svg",{viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg"},t("path",{d:"M3 10C3 6.13401 6.13401 3 10 3C13.866 3 17 6.13401 17 10C17 12.7916 15.3658 15.2026 13 16.3265V14.5C13 14.2239 12.7761 14 12.5 14C12.2239 14 12 14.2239 12 14.5V17.5C12 17.7761 12.2239 18 12.5 18H15.5C15.7761 18 16 17.7761 16 17.5C16 17.2239 15.7761 17 15.5 17H13.8758C16.3346 15.6357 18 13.0128 18 10C18 5.58172 14.4183 2 10 2C5.58172 2 2 5.58172 2 10C2 10.2761 2.22386 10.5 2.5 10.5C2.77614 10.5 3 10.2761 3 10Z",fill:"currentColor"}),t("path",{d:"M10 12C11.1046 12 12 11.1046 12 10C12 8.89543 11.1046 8 10 8C8.89543 8 8 8.89543 8 10C8 11.1046 8.89543 12 10 12ZM10 11C9.44772 11 9 10.5523 9 10C9 9.44772 9.44772 9 10 9C10.5523 9 11 9.44772 11 10C11 10.5523 10.5523 11 10 11Z",fill:"currentColor"}))),Et=te("rotateClockwise",t("svg",{viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg"},t("path",{d:"M17 10C17 6.13401 13.866 3 10 3C6.13401 3 3 6.13401 3 10C3 12.7916 4.63419 15.2026 7 16.3265V14.5C7 14.2239 7.22386 14 7.5 14C7.77614 14 8 14.2239 8 14.5V17.5C8 17.7761 7.77614 18 7.5 18H4.5C4.22386 18 4 17.7761 4 17.5C4 17.2239 4.22386 17 4.5 17H6.12422C3.66539 15.6357 2 13.0128 2 10C2 5.58172 5.58172 2 10 2C14.4183 2 18 5.58172 18 10C18 10.2761 17.7761 10.5 17.5 10.5C17.2239 10.5 17 10.2761 17 10Z",fill:"currentColor"}),t("path",{d:"M10 12C8.89543 12 8 11.1046 8 10C8 8.89543 8.89543 8 10 8C11.1046 8 12 8.89543 12 10C12 11.1046 11.1046 12 10 12ZM10 11C10.5523 11 11 10.5523 11 10C11 9.44772 10.5523 9 10 9C9.44772 9 9 9.44772 9 10C9 10.5523 9.44772 11 10 11Z",fill:"currentColor"}))),$t=te("zoomIn",t("svg",{viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg"},t("path",{d:"M11.5 8.5C11.5 8.22386 11.2761 8 11 8H9V6C9 5.72386 8.77614 5.5 8.5 5.5C8.22386 5.5 8 5.72386 8 6V8H6C5.72386 8 5.5 8.22386 5.5 8.5C5.5 8.77614 5.72386 9 6 9H8V11C8 11.2761 8.22386 11.5 8.5 11.5C8.77614 11.5 9 11.2761 9 11V9H11C11.2761 9 11.5 8.77614 11.5 8.5Z",fill:"currentColor"}),t("path",{d:"M8.5 3C11.5376 3 14 5.46243 14 8.5C14 9.83879 13.5217 11.0659 12.7266 12.0196L16.8536 16.1464C17.0488 16.3417 17.0488 16.6583 16.8536 16.8536C16.68 17.0271 16.4106 17.0464 16.2157 16.9114L16.1464 16.8536L12.0196 12.7266C11.0659 13.5217 9.83879 14 8.5 14C5.46243 14 3 11.5376 3 8.5C3 5.46243 5.46243 3 8.5 3ZM8.5 4C6.01472 4 4 6.01472 4 8.5C4 10.9853 6.01472 13 8.5 13C10.9853 13 13 10.9853 13 8.5C13 6.01472 10.9853 4 8.5 4Z",fill:"currentColor"}))),Ht=te("zoomOut",t("svg",{viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg"},t("path",{d:"M11 8C11.2761 8 11.5 8.22386 11.5 8.5C11.5 8.77614 11.2761 9 11 9H6C5.72386 9 5.5 8.77614 5.5 8.5C5.5 8.22386 5.72386 8 6 8H11Z",fill:"currentColor"}),t("path",{d:"M14 8.5C14 5.46243 11.5376 3 8.5 3C5.46243 3 3 5.46243 3 8.5C3 11.5376 5.46243 14 8.5 14C9.83879 14 11.0659 13.5217 12.0196 12.7266L16.1464 16.8536L16.2157 16.9114C16.4106 17.0464 16.68 17.0271 16.8536 16.8536C17.0488 16.6583 17.0488 16.3417 16.8536 16.1464L12.7266 12.0196C13.5217 11.0659 14 9.83879 14 8.5ZM4 8.5C4 6.01472 6.01472 4 8.5 4C10.9853 4 13 6.01472 13 8.5C13 10.9853 10.9853 13 8.5 13C6.01472 13 4 10.9853 4 8.5Z",fill:"currentColor"}))),Nt=Q({name:"ResizeSmall",render(){return t("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 20 20"},t("g",{fill:"none"},t("path",{d:"M5.5 4A1.5 1.5 0 0 0 4 5.5v1a.5.5 0 0 1-1 0v-1A2.5 2.5 0 0 1 5.5 3h1a.5.5 0 0 1 0 1h-1zM16 5.5A1.5 1.5 0 0 0 14.5 4h-1a.5.5 0 0 1 0-1h1A2.5 2.5 0 0 1 17 5.5v1a.5.5 0 0 1-1 0v-1zm0 9a1.5 1.5 0 0 1-1.5 1.5h-1a.5.5 0 0 0 0 1h1a2.5 2.5 0 0 0 2.5-2.5v-1a.5.5 0 0 0-1 0v1zm-12 0A1.5 1.5 0 0 0 5.5 16h1.25a.5.5 0 0 1 0 1H5.5A2.5 2.5 0 0 1 3 14.5v-1.25a.5.5 0 0 1 1 0v1.25zM8.5 7A1.5 1.5 0 0 0 7 8.5v3A1.5 1.5 0 0 0 8.5 13h3a1.5 1.5 0 0 0 1.5-1.5v-3A1.5 1.5 0 0 0 11.5 7h-3zM8 8.5a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 .5.5v3a.5.5 0 0 1-.5.5h-3a.5.5 0 0 1-.5-.5v-3z",fill:"currentColor"})))}}),At=Ne&&"loading"in document.createElement("img");function Vt(e={}){var i;const{root:o=null}=e;return{hash:`${e.rootMargin||"0px 0px 0px 0px"}-${Array.isArray(e.threshold)?e.threshold.join(","):(i=e.threshold)!==null&&i!==void 0?i:"0"}`,options:Object.assign(Object.assign({},e),{root:(typeof o=="string"?document.querySelector(o):o)||document.documentElement})}}const ye=new WeakMap,Re=new WeakMap,Te=new WeakMap,Xt=(e,i,o)=>{if(!e)return()=>{};const n=Vt(i),{root:a}=n.options;let s;const u=ye.get(a);u?s=u:(s=new Map,ye.set(a,s));let c,d;s.has(n.hash)?(d=s.get(n.hash),d[1].has(e)||(c=d[0],d[1].add(e),c.observe(e))):(c=new IntersectionObserver(h=>{h.forEach(b=>{if(b.isIntersecting){const L=Re.get(b.target),x=Te.get(b.target);L&&L(),x&&(x.value=!0)}})},n.options),c.observe(e),d=[c,new Set([e])],s.set(n.hash,d));let r=!1;const l=()=>{r||(Re.delete(e),Te.delete(e),r=!0,d[1].has(e)&&(d[0].unobserve(e),d[1].delete(e)),d[1].size<=0&&s.delete(n.hash),s.size||ye.delete(a))};return Re.set(e,l),Te.set(e,o),l},Ie=Object.assign(Object.assign({},he.props),{onPreviewPrev:Function,onPreviewNext:Function,showToolbar:{type:Boolean,default:!0},showToolbarTooltip:Boolean,renderToolbar:Function}),Ye=Oe("n-image");function Zt(){return{toolbarIconColor:"rgba(255, 255, 255, .9)",toolbarColor:"rgba(0, 0, 0, .35)",toolbarBoxShadow:"none",toolbarBorderRadius:"24px"}}const Wt=rt({name:"Image",common:lt,peers:{Tooltip:at},self:Zt}),Yt=t("svg",{viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg"},t("path",{d:"M6 5C5.75454 5 5.55039 5.17688 5.50806 5.41012L5.5 5.5V14.5C5.5 14.7761 5.72386 15 6 15C6.24546 15 6.44961 14.8231 6.49194 14.5899L6.5 14.5V5.5C6.5 5.22386 6.27614 5 6 5ZM13.8536 5.14645C13.68 4.97288 13.4106 4.9536 13.2157 5.08859L13.1464 5.14645L8.64645 9.64645C8.47288 9.82001 8.4536 10.0894 8.58859 10.2843L8.64645 10.3536L13.1464 14.8536C13.3417 15.0488 13.6583 15.0488 13.8536 14.8536C14.0271 14.68 14.0464 14.4106 13.9114 14.2157L13.8536 14.1464L9.70711 10L13.8536 5.85355C14.0488 5.65829 14.0488 5.34171 13.8536 5.14645Z",fill:"currentColor"})),qt=t("svg",{viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg"},t("path",{d:"M13.5 5C13.7455 5 13.9496 5.17688 13.9919 5.41012L14 5.5V14.5C14 14.7761 13.7761 15 13.5 15C13.2545 15 13.0504 14.8231 13.0081 14.5899L13 14.5V5.5C13 5.22386 13.2239 5 13.5 5ZM5.64645 5.14645C5.82001 4.97288 6.08944 4.9536 6.28431 5.08859L6.35355 5.14645L10.8536 9.64645C11.0271 9.82001 11.0464 10.0894 10.9114 10.2843L10.8536 10.3536L6.35355 14.8536C6.15829 15.0488 5.84171 15.0488 5.64645 14.8536C5.47288 14.68 5.4536 14.4106 5.58859 14.2157L5.64645 14.1464L9.79289 10L5.64645 5.85355C5.45118 5.65829 5.45118 5.34171 5.64645 5.14645Z",fill:"currentColor"})),Gt=t("svg",{viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg"},t("path",{d:"M4.089 4.216l.057-.07a.5.5 0 0 1 .638-.057l.07.057L10 9.293l5.146-5.147a.5.5 0 0 1 .638-.057l.07.057a.5.5 0 0 1 .057.638l-.057.07L10.707 10l5.147 5.146a.5.5 0 0 1 .057.638l-.057.07a.5.5 0 0 1-.638.057l-.07-.057L10 10.707l-5.146 5.147a.5.5 0 0 1-.638.057l-.07-.057a.5.5 0 0 1-.057-.638l.057-.07L9.293 10L4.146 4.854a.5.5 0 0 1-.057-.638l.057-.07l-.057.07z",fill:"currentColor"})),Kt=M([M("body >",[w("image-container","position: fixed;")]),w("image-preview-container",`
 position: fixed;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 display: flex;
 `),w("image-preview-overlay",`
 z-index: -1;
 position: absolute;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 background: rgba(0, 0, 0, .3);
 `,[_e()]),w("image-preview-toolbar",`
 z-index: 1;
 position: absolute;
 left: 50%;
 transform: translateX(-50%);
 border-radius: var(--n-toolbar-border-radius);
 height: 48px;
 bottom: 40px;
 padding: 0 12px;
 background: var(--n-toolbar-color);
 box-shadow: var(--n-toolbar-box-shadow);
 color: var(--n-toolbar-icon-color);
 transition: color .3s var(--n-bezier);
 display: flex;
 align-items: center;
 `,[w("base-icon",`
 padding: 0 8px;
 font-size: 28px;
 cursor: pointer;
 `),_e()]),w("image-preview-wrapper",`
 position: absolute;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 display: flex;
 pointer-events: none;
 `,[st()]),w("image-preview",`
 user-select: none;
 -webkit-user-select: none;
 pointer-events: all;
 margin: auto;
 max-height: calc(100vh - 32px);
 max-width: calc(100vw - 32px);
 transition: transform .3s var(--n-bezier);
 `),w("image",`
 display: inline-flex;
 max-height: 100%;
 max-width: 100%;
 `,[dt("preview-disabled",`
 cursor: pointer;
 `),M("img",`
 border-radius: inherit;
 `)])]),ue=32,qe=Q({name:"ImagePreview",props:Object.assign(Object.assign({},Ie),{onNext:Function,onPrev:Function,clsPrefix:{type:String,required:!0}}),setup(e){const i=he("Image","-image",Kt,Wt,e,S(e,"clsPrefix"));let o=null;const n=H(null),a=H(null),s=H(void 0),u=H(!1),c=H(!1),{localeRef:d}=St("Image");function r(){const{value:f}=a;if(!o||!f)return;const{style:p}=f,g=o.getBoundingClientRect(),P=g.left+g.width/2,O=g.top+g.height/2;p.transformOrigin=`${P}px ${O}px`}function l(f){var p,g;switch(f.key){case" ":f.preventDefault();break;case"ArrowLeft":(p=e.onPrev)===null||p===void 0||p.call(e);break;case"ArrowRight":(g=e.onNext)===null||g===void 0||g.call(e);break;case"Escape":Be();break}}ut(u,f=>{f?Ce("keydown",document,l):se("keydown",document,l)}),Ae(()=>{se("keydown",document,l)});let h=0,b=0,L=0,x=0,j=0,X=0,E=0,U=0,q=!1;function B(f){const{clientX:p,clientY:g}=f;L=p-h,x=g-b,Bt(G)}function m(f){const{mouseUpClientX:p,mouseUpClientY:g,mouseDownClientX:P,mouseDownClientY:O}=f,V=P-p,Y=O-g,K=`vertical${Y>0?"Top":"Bottom"}`,oe=`horizontal${V>0?"Left":"Right"}`;return{moveVerticalDirection:K,moveHorizontalDirection:oe,deltaHorizontal:V,deltaVertical:Y}}function y(f){const{value:p}=n;if(!p)return{offsetX:0,offsetY:0};const g=p.getBoundingClientRect(),{moveVerticalDirection:P,moveHorizontalDirection:O,deltaHorizontal:V,deltaVertical:Y}=f||{};let K=0,oe=0;return g.width<=window.innerWidth?K=0:g.left>0?K=(g.width-window.innerWidth)/2:g.right<window.innerWidth?K=-(g.width-window.innerWidth)/2:O==="horizontalRight"?K=Math.min((g.width-window.innerWidth)/2,j-(V??0)):K=Math.max(-((g.width-window.innerWidth)/2),j-(V??0)),g.height<=window.innerHeight?oe=0:g.top>0?oe=(g.height-window.innerHeight)/2:g.bottom<window.innerHeight?oe=-(g.height-window.innerHeight)/2:P==="verticalBottom"?oe=Math.min((g.height-window.innerHeight)/2,X-(Y??0)):oe=Math.max(-((g.height-window.innerHeight)/2),X-(Y??0)),{offsetX:K,offsetY:oe}}function C(f){se("mousemove",document,B),se("mouseup",document,C);const{clientX:p,clientY:g}=f;q=!1;const P=m({mouseUpClientX:p,mouseUpClientY:g,mouseDownClientX:E,mouseDownClientY:U}),O=y(P);L=O.offsetX,x=O.offsetY,G()}const z=ne(Ye,null);function v(f){var p,g;if((g=(p=z?.previewedImgPropsRef.value)===null||p===void 0?void 0:p.onMousedown)===null||g===void 0||g.call(p,f),f.button!==0)return;const{clientX:P,clientY:O}=f;q=!0,h=P-L,b=O-x,j=L,X=x,E=P,U=O,G(),Ce("mousemove",document,B),Ce("mouseup",document,C)}const k=1.5;let R=0,T=1,D=0;function N(f){var p,g;(g=(p=z?.previewedImgPropsRef.value)===null||p===void 0?void 0:p.onDblclick)===null||g===void 0||g.call(p,f);const P=ae();T=T===P?1:P,G()}function _(){T=1,R=0}function I(){var f;_(),D=0,(f=e.onPrev)===null||f===void 0||f.call(e)}function W(){var f;_(),D=0,(f=e.onNext)===null||f===void 0||f.call(e)}function Z(){D-=90,G()}function ee(){D+=90,G()}function me(){const{value:f}=n;if(!f)return 1;const{innerWidth:p,innerHeight:g}=window,P=Math.max(1,f.naturalHeight/(g-ue)),O=Math.max(1,f.naturalWidth/(p-ue));return Math.max(3,P*2,O*2)}function ae(){const{value:f}=n;if(!f)return 1;const{innerWidth:p,innerHeight:g}=window,P=f.naturalHeight/(g-ue),O=f.naturalWidth/(p-ue);return P<1&&O<1?1:Math.max(P,O)}function pe(){const f=me();T<f&&(R+=1,T=Math.min(f,Math.pow(k,R)),G())}function we(){if(T>.5){const f=T;R-=1,T=Math.max(.5,Math.pow(k,R));const p=f-T;G(!1);const g=y();T+=p,G(!1),T-=p,L=g.offsetX,x=g.offsetY,G()}}function be(){const f=s.value;f&&Ze(f,void 0)}function G(f=!0){var p;const{value:g}=n;if(!g)return;const{style:P}=g,O=vt((p=z?.previewedImgPropsRef.value)===null||p===void 0?void 0:p.style);let V="";if(typeof O=="string")V=`${O};`;else for(const K in O)V+=`${mt(K)}: ${O[K]};`;const Y=`transform-origin: center; transform: translateX(${L}px) translateY(${x}px) rotate(${D}deg) scale(${T});`;q?P.cssText=`${V}cursor: grabbing; transition: none;${Y}`:P.cssText=`${V}cursor: grab;${Y}${f?"":"transition: none;"}`,f||g.offsetHeight}function Be(){u.value=!u.value,c.value=!0}function ot(){T=ae(),R=Math.ceil(Math.log(T)/Math.log(k)),L=0,x=0,G()}const nt={setPreviewSrc:f=>{s.value=f},setThumbnailEl:f=>{o=f},toggleShow:Be};function it(f,p){if(e.showToolbarTooltip){const{value:g}=i;return t(It,{to:!1,theme:g.peers.Tooltip,themeOverrides:g.peerOverrides.Tooltip,keepAliveOnHover:!1},{default:()=>d.value[p],trigger:()=>f})}else return f}const ze=$(()=>{const{common:{cubicBezierEaseInOut:f},self:{toolbarIconColor:p,toolbarBorderRadius:g,toolbarBoxShadow:P,toolbarColor:O}}=i.value;return{"--n-bezier":f,"--n-toolbar-icon-color":p,"--n-toolbar-color":O,"--n-toolbar-border-radius":g,"--n-toolbar-box-shadow":P}}),{inlineThemeDisabled:De}=ge(),ie=De?Ve("image-preview",void 0,ze,e):void 0;return Object.assign({previewRef:n,previewWrapperRef:a,previewSrc:s,show:u,appear:ct(),displayed:c,previewedImgProps:z?.previewedImgPropsRef,handleWheel(f){f.preventDefault()},handlePreviewMousedown:v,handlePreviewDblclick:N,syncTransformOrigin:r,handleAfterLeave:()=>{_(),D=0,c.value=!1},handleDragStart:f=>{var p,g;(g=(p=z?.previewedImgPropsRef.value)===null||p===void 0?void 0:p.onDragstart)===null||g===void 0||g.call(p,f),f.preventDefault()},zoomIn:pe,zoomOut:we,handleDownloadClick:be,rotateCounterclockwise:Z,rotateClockwise:ee,handleSwitchPrev:I,handleSwitchNext:W,withTooltip:it,resizeToOrignalImageSize:ot,cssVars:De?void 0:ze,themeClass:ie?.themeClass,onRender:ie?.onRender},nt)},render(){var e,i;const{clsPrefix:o,renderToolbar:n,withTooltip:a}=this,s=a(t(F,{clsPrefix:o,onClick:this.handleSwitchPrev},{default:()=>Yt}),"tipPrevious"),u=a(t(F,{clsPrefix:o,onClick:this.handleSwitchNext},{default:()=>qt}),"tipNext"),c=a(t(F,{clsPrefix:o,onClick:this.rotateCounterclockwise},{default:()=>t(Et,null)}),"tipCounterclockwise"),d=a(t(F,{clsPrefix:o,onClick:this.rotateClockwise},{default:()=>t(jt,null)}),"tipClockwise"),r=a(t(F,{clsPrefix:o,onClick:this.resizeToOrignalImageSize},{default:()=>t(Nt,null)}),"tipOriginalSize"),l=a(t(F,{clsPrefix:o,onClick:this.zoomOut},{default:()=>t(Ht,null)}),"tipZoomOut"),h=a(t(F,{clsPrefix:o,onClick:this.handleDownloadClick},{default:()=>t(We,null)}),"tipDownload"),b=a(t(F,{clsPrefix:o,onClick:this.toggleShow},{default:()=>Gt}),"tipClose"),L=a(t(F,{clsPrefix:o,onClick:this.zoomIn},{default:()=>t($t,null)}),"tipZoomIn");return t(fe,null,(i=(e=this.$slots).default)===null||i===void 0?void 0:i.call(e),t(ft,{show:this.show},{default:()=>{var x;return this.show||this.displayed?((x=this.onRender)===null||x===void 0||x.call(this),Me(t("div",{class:[`${o}-image-preview-container`,this.themeClass],style:this.cssVars,onWheel:this.handleWheel},t(xe,{name:"fade-in-transition",appear:this.appear},{default:()=>this.show?t("div",{class:`${o}-image-preview-overlay`,onClick:this.toggleShow}):null}),this.showToolbar?t(xe,{name:"fade-in-transition",appear:this.appear},{default:()=>this.show?t("div",{class:`${o}-image-preview-toolbar`},n?n({nodes:{prev:s,next:u,rotateCounterclockwise:c,rotateClockwise:d,resizeToOriginalSize:r,zoomOut:l,zoomIn:L,download:h,close:b}}):t(fe,null,this.onPrev?t(fe,null,s,u):null,c,d,r,l,L,h,b)):null}):null,t(xe,{name:"fade-in-scale-up-transition",onAfterLeave:this.handleAfterLeave,appear:this.appear,onEnter:this.syncTransformOrigin,onBeforeLeave:this.syncTransformOrigin},{default:()=>{const{previewedImgProps:j={}}=this;return Me(t("div",{class:`${o}-image-preview-wrapper`,ref:"previewWrapperRef"},t("img",Object.assign({},j,{draggable:!1,onMousedown:this.handlePreviewMousedown,onDblclick:this.handlePreviewDblclick,class:[`${o}-image-preview`,j.class],key:this.previewSrc,src:this.previewSrc,ref:"previewRef",onDragstart:this.handleDragStart}))),[[gt,this.show]])}})),[[ht,{enabled:this.show}]])):null}}))}}),Ge=Oe("n-image-group"),Jt=Ie,Qt=Q({name:"ImageGroup",props:Jt,setup(e){let i;const{mergedClsPrefixRef:o}=ge(e),n=`c${Le()}`,a=pt(),s=H(null),u=d=>{var r;i=d,(r=s.value)===null||r===void 0||r.setPreviewSrc(d)};function c(d){var r,l;if(!a?.proxy)return;const b=a.proxy.$el.parentElement.querySelectorAll(`[data-group-id=${n}]:not([data-error=true])`);if(!b.length)return;const L=Array.from(b).findIndex(x=>x.dataset.previewSrc===i);~L?u(b[(L+d+b.length)%b.length].dataset.previewSrc):u(b[0].dataset.previewSrc),d===1?(r=e.onPreviewNext)===null||r===void 0||r.call(e):(l=e.onPreviewPrev)===null||l===void 0||l.call(e)}return Se(Ge,{mergedClsPrefixRef:o,setPreviewSrc:u,setThumbnailEl:d=>{var r;(r=s.value)===null||r===void 0||r.setThumbnailEl(d)},toggleShow:()=>{var d;(d=s.value)===null||d===void 0||d.toggleShow()},groupId:n,renderToolbarRef:S(e,"renderToolbar")}),{mergedClsPrefix:o,previewInstRef:s,next:()=>{c(1)},prev:()=>{c(-1)}}},render(){return t(qe,{theme:this.theme,themeOverrides:this.themeOverrides,clsPrefix:this.mergedClsPrefix,ref:"previewInstRef",onPrev:this.prev,onNext:this.next,showToolbar:this.showToolbar,showToolbarTooltip:this.showToolbarTooltip,renderToolbar:this.renderToolbar},this.$slots)}}),eo=Object.assign({alt:String,height:[String,Number],imgProps:Object,previewedImgProps:Object,lazy:Boolean,intersectionObserverOptions:Object,objectFit:{type:String,default:"fill"},previewSrc:String,fallbackSrc:String,width:[String,Number],src:String,previewDisabled:Boolean,loadDescription:String,onError:Function,onLoad:Function},Ie),to=Q({name:"Image",props:eo,inheritAttrs:!1,setup(e){const i=H(null),o=H(!1),n=H(null),a=ne(Ge,null),{mergedClsPrefixRef:s}=a||ge(e),u={click:()=>{if(e.previewDisabled||o.value)return;const r=e.previewSrc||e.src;if(a){a.setPreviewSrc(r),a.setThumbnailEl(i.value),a.toggleShow();return}const{value:l}=n;l&&(l.setPreviewSrc(r),l.setThumbnailEl(i.value),l.toggleShow())}},c=H(!e.lazy);Fe(()=>{var r;(r=i.value)===null||r===void 0||r.setAttribute("data-group-id",a?.groupId||"")}),Fe(()=>{if(e.lazy&&e.intersectionObserverOptions){let r;const l=ke(()=>{r?.(),r=void 0,r=Xt(i.value,e.intersectionObserverOptions,c)});Ae(()=>{l(),r?.()})}}),ke(()=>{var r;e.src||((r=e.imgProps)===null||r===void 0||r.src),o.value=!1});const d=H(!1);return Se(Ye,{previewedImgPropsRef:S(e,"previewedImgProps")}),Object.assign({mergedClsPrefix:s,groupId:a?.groupId,previewInstRef:n,imageRef:i,showError:o,shouldStartLoading:c,loaded:d,mergedOnClick:r=>{var l,h;u.click(),(h=(l=e.imgProps)===null||l===void 0?void 0:l.onClick)===null||h===void 0||h.call(l,r)},mergedOnError:r=>{if(!c.value)return;o.value=!0;const{onError:l,imgProps:{onError:h}={}}=e;l?.(r),h?.(r)},mergedOnLoad:r=>{const{onLoad:l,imgProps:{onLoad:h}={}}=e;l?.(r),h?.(r),d.value=!0}},u)},render(){var e,i;const{mergedClsPrefix:o,imgProps:n={},loaded:a,$attrs:s,lazy:u}=this,c=(i=(e=this.$slots).placeholder)===null||i===void 0?void 0:i.call(e),d=this.src||n.src,r=t("img",Object.assign(Object.assign({},n),{ref:"imageRef",width:this.width||n.width,height:this.height||n.height,src:this.showError?this.fallbackSrc:u&&this.intersectionObserverOptions?this.shouldStartLoading?d:void 0:d,alt:this.alt||n.alt,"aria-label":this.alt||n.alt,onClick:this.mergedOnClick,onError:this.mergedOnError,onLoad:this.mergedOnLoad,loading:At&&u&&!this.intersectionObserverOptions?"lazy":"eager",style:[n.style||"",c&&!a?{height:"0",width:"0",visibility:"hidden"}:"",{objectFit:this.objectFit}],"data-error":this.showError,"data-preview-src":this.previewSrc||this.src}));return t("div",Object.assign({},s,{role:"none",class:[s.class,`${o}-image`,(this.previewDisabled||this.showError)&&`${o}-image--preview-disabled`]}),this.groupId?r:t(qe,{theme:this.theme,themeOverrides:this.themeOverrides,clsPrefix:o,ref:"previewInstRef",showToolbar:this.showToolbar,showToolbarTooltip:this.showToolbarTooltip,renderToolbar:this.renderToolbar},{default:()=>r,toolbar:()=>{var l,h;return(h=(l=this.$slots).toolbar)===null||h===void 0?void 0:h.call(l)}}),!a&&c)}}),re=Oe("n-upload"),Ke="__UPLOAD_DRAGGER__",oo=Q({name:"UploadDragger",[Ke]:!0,setup(e,{slots:i}){const o=ne(re,null);return o||ve("upload-dragger","`n-upload-dragger` must be placed inside `n-upload`."),()=>{const{mergedClsPrefixRef:{value:n},mergedDisabledRef:{value:a},maxReachedRef:{value:s}}=o;return t("div",{class:[`${n}-upload-dragger`,(a||s)&&`${n}-upload-dragger--disabled`]},i)}}});var Pe=globalThis&&globalThis.__awaiter||function(e,i,o,n){function a(s){return s instanceof o?s:new o(function(u){u(s)})}return new(o||(o=Promise))(function(s,u){function c(l){try{r(n.next(l))}catch(h){u(h)}}function d(l){try{r(n.throw(l))}catch(h){u(h)}}function r(l){l.done?s(l.value):a(l.value).then(c,d)}r((n=n.apply(e,i||[])).next())})};function Je(e){return e.includes("image/")}function Ee(e=""){const i=e.split("/"),n=i[i.length-1].split(/#|\?/)[0];return(/\.[^./\\]*$/.exec(n)||[""])[0]}const $e=/(webp|svg|png|gif|jpg|jpeg|jfif|bmp|dpg|ico)$/i,Qe=e=>{if(e.type)return Je(e.type);const i=Ee(e.name||"");if($e.test(i))return!0;const o=e.thumbnailUrl||e.url||"",n=Ee(o);return!!(/^data:image\//.test(o)||$e.test(n))};function no(e){return Pe(this,void 0,void 0,function*(){return yield new Promise(i=>{if(!e.type||!Je(e.type)){i("");return}i(window.URL.createObjectURL(e))})})}const io=Ne&&window.FileReader&&window.File;function ro(e){return e.isDirectory}function lo(e){return e.isFile}function ao(e,i){return Pe(this,void 0,void 0,function*(){const o=[];function n(a){return Pe(this,void 0,void 0,function*(){for(const s of a)if(s){if(i&&ro(s)){const u=s.createReader();try{const c=yield new Promise((d,r)=>{u.readEntries(d,r)});yield n(c)}catch{}}else if(lo(s))try{const u=yield new Promise((c,d)=>{s.file(c,d)});o.push({file:u,entry:s,source:"dnd"})}catch{}}})}return yield n(e),o})}function le(e){const{id:i,name:o,percentage:n,status:a,url:s,file:u,thumbnailUrl:c,type:d,fullPath:r,batchId:l}=e;return{id:i,name:o,percentage:n??null,status:a,url:s??null,file:u??null,thumbnailUrl:c??null,type:d??null,fullPath:r??null,batchId:l??null}}function so(e,i,o){return e=e.toLowerCase(),i=i.toLocaleLowerCase(),o=o.toLocaleLowerCase(),o.split(",").map(a=>a.trim()).filter(Boolean).some(a=>{if(a.startsWith(".")){if(e.endsWith(a))return!0}else if(a.includes("/")){const[s,u]=i.split("/"),[c,d]=a.split("/");if((c==="*"||s&&c&&c===s)&&(d==="*"||u&&d&&d===u))return!0}else return!0;return!1})}const et=Q({name:"UploadTrigger",props:{abstract:Boolean},setup(e,{slots:i}){const o=ne(re,null);o||ve("upload-trigger","`n-upload-trigger` must be placed inside `n-upload`.");const{mergedClsPrefixRef:n,mergedDisabledRef:a,maxReachedRef:s,listTypeRef:u,dragOverRef:c,openOpenFileDialog:d,draggerInsideRef:r,handleFileAddition:l,mergedDirectoryDndRef:h,triggerClassRef:b,triggerStyleRef:L}=o,x=$(()=>u.value==="image-card");function j(){a.value||s.value||d()}function X(B){B.preventDefault(),c.value=!0}function E(B){B.preventDefault(),c.value=!0}function U(B){B.preventDefault(),c.value=!1}function q(B){var m;if(B.preventDefault(),!r.value||a.value||s.value){c.value=!1;return}const y=(m=B.dataTransfer)===null||m===void 0?void 0:m.items;y?.length?ao(Array.from(y).map(C=>C.webkitGetAsEntry()),h.value).then(C=>{l(C)}).finally(()=>{c.value=!1}):c.value=!1}return()=>{var B;const{value:m}=n;return e.abstract?(B=i.default)===null||B===void 0?void 0:B.call(i,{handleClick:j,handleDrop:q,handleDragOver:X,handleDragEnter:E,handleDragLeave:U}):t("div",{class:[`${m}-upload-trigger`,(a.value||s.value)&&`${m}-upload-trigger--disabled`,x.value&&`${m}-upload-trigger--image-card`,b.value],style:L.value,onClick:j,onDrop:q,onDragover:X,onDragenter:E,onDragleave:U},x.value?t(oo,null,{default:()=>wt(i.default,()=>[t(F,{clsPrefix:m},{default:()=>t(Pt,null)})])}):i)}}}),uo=Q({name:"UploadProgress",props:{show:Boolean,percentage:{type:Number,required:!0},status:{type:String,required:!0}},setup(){return{mergedTheme:ne(re).mergedThemeRef}},render(){return t(Xe,null,{default:()=>this.show?t(Ot,{type:"line",showIndicator:!1,percentage:this.percentage,status:this.status,height:2,theme:this.mergedTheme.peers.Progress,themeOverrides:this.mergedTheme.peerOverrides.Progress}):null})}}),co=t("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 28 28"},t("g",{fill:"none"},t("path",{d:"M21.75 3A3.25 3.25 0 0 1 25 6.25v15.5A3.25 3.25 0 0 1 21.75 25H6.25A3.25 3.25 0 0 1 3 21.75V6.25A3.25 3.25 0 0 1 6.25 3h15.5zm.583 20.4l-7.807-7.68a.75.75 0 0 0-.968-.07l-.084.07l-7.808 7.68c.183.065.38.1.584.1h15.5c.204 0 .4-.035.583-.1l-7.807-7.68l7.807 7.68zM21.75 4.5H6.25A1.75 1.75 0 0 0 4.5 6.25v15.5c0 .208.036.408.103.593l7.82-7.692a2.25 2.25 0 0 1 3.026-.117l.129.117l7.82 7.692c.066-.185.102-.385.102-.593V6.25a1.75 1.75 0 0 0-1.75-1.75zm-3.25 3a2.5 2.5 0 1 1 0 5a2.5 2.5 0 0 1 0-5zm0 1.5a1 1 0 1 0 0 2a1 1 0 0 0 0-2z",fill:"currentColor"}))),fo=t("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 28 28"},t("g",{fill:"none"},t("path",{d:"M6.4 2A2.4 2.4 0 0 0 4 4.4v19.2A2.4 2.4 0 0 0 6.4 26h15.2a2.4 2.4 0 0 0 2.4-2.4V11.578c0-.729-.29-1.428-.805-1.944l-6.931-6.931A2.4 2.4 0 0 0 14.567 2H6.4zm-.9 2.4a.9.9 0 0 1 .9-.9H14V10a2 2 0 0 0 2 2h6.5v11.6a.9.9 0 0 1-.9.9H6.4a.9.9 0 0 1-.9-.9V4.4zm16.44 6.1H16a.5.5 0 0 1-.5-.5V4.06l6.44 6.44z",fill:"currentColor"})));var ho=globalThis&&globalThis.__awaiter||function(e,i,o,n){function a(s){return s instanceof o?s:new o(function(u){u(s)})}return new(o||(o=Promise))(function(s,u){function c(l){try{r(n.next(l))}catch(h){u(h)}}function d(l){try{r(n.throw(l))}catch(h){u(h)}}function r(l){l.done?s(l.value):a(l.value).then(c,d)}r((n=n.apply(e,i||[])).next())})};const ce={paddingMedium:"0 3px",heightMedium:"24px",iconSizeMedium:"18px"},go=Q({name:"UploadFile",props:{clsPrefix:{type:String,required:!0},file:{type:Object,required:!0},listType:{type:String,required:!0},index:{type:Number,required:!0}},setup(e){const i=ne(re),o=H(null),n=H(""),a=$(()=>{const{file:m}=e;return m.status==="finished"?"success":m.status==="error"?"error":"info"}),s=$(()=>{const{file:m}=e;if(m.status==="error")return"error"}),u=$(()=>{const{file:m}=e;return m.status==="uploading"}),c=$(()=>{if(!i.showCancelButtonRef.value)return!1;const{file:m}=e;return["uploading","pending","error"].includes(m.status)}),d=$(()=>{if(!i.showRemoveButtonRef.value)return!1;const{file:m}=e;return["finished"].includes(m.status)}),r=$(()=>{if(!i.showDownloadButtonRef.value)return!1;const{file:m}=e;return["finished"].includes(m.status)}),l=$(()=>{if(!i.showRetryButtonRef.value)return!1;const{file:m}=e;return["error"].includes(m.status)}),h=bt(()=>n.value||e.file.thumbnailUrl||e.file.url),b=$(()=>{if(!i.showPreviewButtonRef.value)return!1;const{file:{status:m},listType:y}=e;return["finished"].includes(m)&&h.value&&y==="image-card"});function L(){i.submit(e.file.id)}function x(m){m.preventDefault();const{file:y}=e;["finished","pending","error"].includes(y.status)?X(y):["uploading"].includes(y.status)?U(y):xt("upload","The button clicked type is unknown.")}function j(m){m.preventDefault(),E(e.file)}function X(m){const{xhrMap:y,doChange:C,onRemoveRef:{value:z},mergedFileListRef:{value:v}}=i;Promise.resolve(z?z({file:Object.assign({},m),fileList:v,index:e.index}):!0).then(k=>{if(k===!1)return;const R=Object.assign({},m,{status:"removed"});y.delete(m.id),C(R,void 0,{remove:!0})})}function E(m){const{onDownloadRef:{value:y}}=i;Promise.resolve(y?y(Object.assign({},m)):!0).then(C=>{C!==!1&&Ze(m.url,m.name)})}function U(m){const{xhrMap:y}=i,C=y.get(m.id);C?.abort(),X(Object.assign({},m))}function q(m){const{onPreviewRef:{value:y}}=i;if(y)y(e.file,{event:m});else if(e.listType==="image-card"){const{value:C}=o;if(!C)return;C.click()}}const B=()=>ho(this,void 0,void 0,function*(){const{listType:m}=e;m!=="image"&&m!=="image-card"||i.shouldUseThumbnailUrlRef.value(e.file)&&(n.value=yield i.getFileThumbnailUrlResolver(e.file))});return ke(()=>{B()}),{mergedTheme:i.mergedThemeRef,progressStatus:a,buttonType:s,showProgress:u,disabled:i.mergedDisabledRef,showCancelButton:c,showRemoveButton:d,showDownloadButton:r,showRetryButton:l,showPreviewButton:b,mergedThumbnailUrl:h,shouldUseThumbnailUrl:i.shouldUseThumbnailUrlRef,renderIcon:i.renderIconRef,imageRef:o,handleRemoveOrCancelClick:x,handleDownloadClick:j,handleRetryClick:L,handlePreviewClick:q}},render(){const{clsPrefix:e,mergedTheme:i,listType:o,file:n,renderIcon:a}=this;let s;const u=o==="image";u||o==="image-card"?s=!this.shouldUseThumbnailUrl(n)||!this.mergedThumbnailUrl?t("span",{class:`${e}-upload-file-info__thumbnail`},a?a(n):Qe(n)?t(F,{clsPrefix:e},{default:()=>co}):t(F,{clsPrefix:e},{default:()=>fo})):t("a",{rel:"noopener noreferer",target:"_blank",href:n.url||void 0,class:`${e}-upload-file-info__thumbnail`,onClick:this.handlePreviewClick},o==="image-card"?t(to,{src:this.mergedThumbnailUrl||void 0,previewSrc:n.url||void 0,alt:n.name,ref:"imageRef"}):t("img",{src:this.mergedThumbnailUrl||void 0,alt:n.name})):s=t("span",{class:`${e}-upload-file-info__thumbnail`},a?a(n):t(F,{clsPrefix:e},{default:()=>t(_t,null)}));const d=t(uo,{show:this.showProgress,percentage:n.percentage||0,status:this.progressStatus}),r=o==="text"||o==="image";return t("div",{class:[`${e}-upload-file`,`${e}-upload-file--${this.progressStatus}-status`,n.url&&n.status!=="error"&&o!=="image-card"&&`${e}-upload-file--with-url`,`${e}-upload-file--${o}-type`]},t("div",{class:`${e}-upload-file-info`},s,t("div",{class:`${e}-upload-file-info__name`},r&&(n.url&&n.status!=="error"?t("a",{rel:"noopener noreferer",target:"_blank",href:n.url||void 0,onClick:this.handlePreviewClick},n.name):t("span",{onClick:this.handlePreviewClick},n.name)),u&&d),t("div",{class:[`${e}-upload-file-info__action`,`${e}-upload-file-info__action--${o}-type`]},this.showPreviewButton?t(de,{key:"preview",quaternary:!0,type:this.buttonType,onClick:this.handlePreviewClick,theme:i.peers.Button,themeOverrides:i.peerOverrides.Button,builtinThemeOverrides:ce},{icon:()=>t(F,{clsPrefix:e},{default:()=>t(zt,null)})}):null,(this.showRemoveButton||this.showCancelButton)&&!this.disabled&&t(de,{key:"cancelOrTrash",theme:i.peers.Button,themeOverrides:i.peerOverrides.Button,quaternary:!0,builtinThemeOverrides:ce,type:this.buttonType,onClick:this.handleRemoveOrCancelClick},{icon:()=>t(Ct,null,{default:()=>this.showRemoveButton?t(F,{clsPrefix:e,key:"trash"},{default:()=>t(Mt,null)}):t(F,{clsPrefix:e,key:"cancel"},{default:()=>t(Ft,null)})})}),this.showRetryButton&&!this.disabled&&t(de,{key:"retry",quaternary:!0,type:this.buttonType,onClick:this.handleRetryClick,theme:i.peers.Button,themeOverrides:i.peerOverrides.Button,builtinThemeOverrides:ce},{icon:()=>t(F,{clsPrefix:e},{default:()=>t(Ut,null)})}),this.showDownloadButton?t(de,{key:"download",quaternary:!0,type:this.buttonType,onClick:this.handleDownloadClick,theme:i.peers.Button,themeOverrides:i.peerOverrides.Button,builtinThemeOverrides:ce},{icon:()=>t(F,{clsPrefix:e},{default:()=>t(We,null)})}):null)),!u&&d)}}),vo=Q({name:"UploadFileList",setup(e,{slots:i}){const o=ne(re,null);o||ve("upload-file-list","`n-upload-file-list` must be placed inside `n-upload`.");const{abstractRef:n,mergedClsPrefixRef:a,listTypeRef:s,mergedFileListRef:u,fileListClassRef:c,fileListStyleRef:d,cssVarsRef:r,themeClassRef:l,maxReachedRef:h,showTriggerRef:b,imageGroupPropsRef:L}=o,x=$(()=>s.value==="image-card"),j=()=>u.value.map((E,U)=>t(go,{clsPrefix:a.value,key:E.id,file:E,index:U,listType:s.value})),X=()=>x.value?t(Qt,Object.assign({},L.value),{default:j}):t(Xe,{group:!0},{default:j});return()=>{const{value:E}=a,{value:U}=n;return t("div",{class:[`${E}-upload-file-list`,x.value&&`${E}-upload-file-list--grid`,U?l?.value:void 0,c.value],style:[U&&r?r.value:"",d.value]},X(),b.value&&!h.value&&x.value&&t(et,null,i))}}}),mo=M([w("upload","width: 100%;",[A("dragger-inside",[w("upload-trigger",`
 display: block;
 `)]),A("drag-over",[w("upload-dragger",`
 border: var(--n-dragger-border-hover);
 `)])]),w("upload-dragger",`
 cursor: pointer;
 box-sizing: border-box;
 width: 100%;
 text-align: center;
 border-radius: var(--n-border-radius);
 padding: 24px;
 opacity: 1;
 transition:
 opacity .3s var(--n-bezier),
 border-color .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 background-color: var(--n-dragger-color);
 border: var(--n-dragger-border);
 `,[M("&:hover",`
 border: var(--n-dragger-border-hover);
 `),A("disabled",`
 cursor: not-allowed;
 `)]),w("upload-trigger",`
 display: inline-block;
 box-sizing: border-box;
 opacity: 1;
 transition: opacity .3s var(--n-bezier);
 `,[M("+",[w("upload-file-list","margin-top: 8px;")]),A("disabled",`
 opacity: var(--n-item-disabled-opacity);
 cursor: not-allowed;
 `),A("image-card",`
 width: 96px;
 height: 96px;
 `,[w("base-icon",`
 font-size: 24px;
 `),w("upload-dragger",`
 padding: 0;
 height: 100%;
 width: 100%;
 display: flex;
 align-items: center;
 justify-content: center;
 `)])]),w("upload-file-list",`
 line-height: var(--n-line-height);
 opacity: 1;
 transition: opacity .3s var(--n-bezier);
 `,[M("a, img","outline: none;"),A("disabled",`
 opacity: var(--n-item-disabled-opacity);
 cursor: not-allowed;
 `,[w("upload-file","cursor: not-allowed;")]),A("grid",`
 display: grid;
 grid-template-columns: repeat(auto-fill, 96px);
 grid-gap: 8px;
 margin-top: 0;
 `),w("upload-file",`
 display: block;
 box-sizing: border-box;
 cursor: default;
 padding: 0px 12px 0 6px;
 transition: background-color .3s var(--n-bezier);
 border-radius: var(--n-border-radius);
 `,[Ue(),w("progress",[Ue({foldPadding:!0})]),M("&:hover",`
 background-color: var(--n-item-color-hover);
 `,[w("upload-file-info",[J("action",`
 opacity: 1;
 `)])]),A("image-type",`
 border-radius: var(--n-border-radius);
 text-decoration: underline;
 text-decoration-color: #0000;
 `,[w("upload-file-info",`
 padding-top: 0px;
 padding-bottom: 0px;
 width: 100%;
 height: 100%;
 display: flex;
 justify-content: space-between;
 align-items: center;
 padding: 6px 0;
 `,[w("progress",`
 padding: 2px 0;
 margin-bottom: 0;
 `),J("name",`
 padding: 0 8px;
 `),J("thumbnail",`
 width: 32px;
 height: 32px;
 font-size: 28px;
 display: flex;
 justify-content: center;
 align-items: center;
 `,[M("img",`
 width: 100%;
 `)])])]),A("text-type",[w("progress",`
 box-sizing: border-box;
 padding-bottom: 6px;
 margin-bottom: 6px;
 `)]),A("image-card-type",`
 position: relative;
 width: 96px;
 height: 96px;
 border: var(--n-item-border-image-card);
 border-radius: var(--n-border-radius);
 padding: 0;
 display: flex;
 align-items: center;
 justify-content: center;
 transition: border-color .3s var(--n-bezier), background-color .3s var(--n-bezier);
 border-radius: var(--n-border-radius);
 overflow: hidden;
 `,[w("progress",`
 position: absolute;
 left: 8px;
 bottom: 8px;
 right: 8px;
 width: unset;
 `),w("upload-file-info",`
 padding: 0;
 width: 100%;
 height: 100%;
 `,[J("thumbnail",`
 width: 100%;
 height: 100%;
 display: flex;
 flex-direction: column;
 align-items: center;
 justify-content: center;
 font-size: 36px;
 `,[M("img",`
 width: 100%;
 `)])]),M("&::before",`
 position: absolute;
 z-index: 1;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 border-radius: inherit;
 opacity: 0;
 transition: opacity .2s var(--n-bezier);
 content: "";
 `),M("&:hover",[M("&::before","opacity: 1;"),w("upload-file-info",[J("thumbnail","opacity: .12;")])])]),A("error-status",[M("&:hover",`
 background-color: var(--n-item-color-hover-error);
 `),w("upload-file-info",[J("name","color: var(--n-item-text-color-error);"),J("thumbnail","color: var(--n-item-text-color-error);")]),A("image-card-type",`
 border: var(--n-item-border-image-card-error);
 `)]),A("with-url",`
 cursor: pointer;
 `,[w("upload-file-info",[J("name",`
 color: var(--n-item-text-color-success);
 text-decoration-color: var(--n-item-text-color-success);
 `,[M("a",`
 text-decoration: underline;
 `)])])]),w("upload-file-info",`
 position: relative;
 padding-top: 6px;
 padding-bottom: 6px;
 display: flex;
 flex-wrap: nowrap;
 `,[J("thumbnail",`
 font-size: 18px;
 opacity: 1;
 transition: opacity .2s var(--n-bezier);
 color: var(--n-item-icon-color);
 `,[w("base-icon",`
 margin-right: 2px;
 vertical-align: middle;
 transition: color .3s var(--n-bezier);
 `)]),J("action",`
 padding-top: inherit;
 padding-bottom: inherit;
 position: absolute;
 right: 0;
 top: 0;
 bottom: 0;
 width: 80px;
 display: flex;
 align-items: center;
 transition: opacity .2s var(--n-bezier);
 justify-content: flex-end;
 opacity: 0;
 `,[w("button",[M("&:not(:last-child)",{marginRight:"4px"}),w("base-icon",[M("svg",[yt()])])]),A("image-type",`
 position: relative;
 max-width: 80px;
 width: auto;
 `),A("image-card-type",`
 z-index: 2;
 position: absolute;
 width: 100%;
 height: 100%;
 left: 0;
 right: 0;
 bottom: 0;
 top: 0;
 display: flex;
 justify-content: center;
 align-items: center;
 `)]),J("name",`
 color: var(--n-item-text-color);
 flex: 1;
 display: flex;
 justify-content: center;
 text-overflow: ellipsis;
 overflow: hidden;
 flex-direction: column;
 text-decoration-color: #0000;
 font-size: var(--n-font-size);
 transition:
 color .3s var(--n-bezier),
 text-decoration-color .3s var(--n-bezier); 
 `,[M("a",`
 color: inherit;
 text-decoration: underline;
 `)])])])]),w("upload-file-input",`
 display: none;
 width: 0;
 height: 0;
 opacity: 0;
 `)]);var He=globalThis&&globalThis.__awaiter||function(e,i,o,n){function a(s){return s instanceof o?s:new o(function(u){u(s)})}return new(o||(o=Promise))(function(s,u){function c(l){try{r(n.next(l))}catch(h){u(h)}}function d(l){try{r(n.throw(l))}catch(h){u(h)}}function r(l){l.done?s(l.value):a(l.value).then(c,d)}r((n=n.apply(e,i||[])).next())})};function po(e,i,o){const{doChange:n,xhrMap:a}=e;let s=0;function u(d){var r;let l=Object.assign({},i,{status:"error",percentage:s});a.delete(i.id),l=le(((r=e.onError)===null||r===void 0?void 0:r.call(e,{file:l,event:d}))||l),n(l,d)}function c(d){var r;if(e.isErrorState){if(e.isErrorState(o)){u(d);return}}else if(o.status<200||o.status>=300){u(d);return}let l=Object.assign({},i,{status:"finished",percentage:s});a.delete(i.id),l=le(((r=e.onFinish)===null||r===void 0?void 0:r.call(e,{file:l,event:d}))||l),n(l,d)}return{handleXHRLoad:c,handleXHRError:u,handleXHRAbort(d){const r=Object.assign({},i,{status:"removed",file:null,percentage:s});a.delete(i.id),n(r,d)},handleXHRProgress(d){const r=Object.assign({},i,{status:"uploading"});if(d.lengthComputable){const l=Math.ceil(d.loaded/d.total*100);r.percentage=l,s=l}n(r,d)}}}function wo(e){const{inst:i,file:o,data:n,headers:a,withCredentials:s,action:u,customRequest:c}=e,{doChange:d}=e.inst;let r=0;c({file:o,data:n,headers:a,withCredentials:s,action:u,onProgress(l){const h=Object.assign({},o,{status:"uploading"}),b=l.percent;h.percentage=b,r=b,d(h)},onFinish(){var l;let h=Object.assign({},o,{status:"finished",percentage:r});h=le(((l=i.onFinish)===null||l===void 0?void 0:l.call(i,{file:h}))||h),d(h)},onError(){var l;let h=Object.assign({},o,{status:"error",percentage:r});h=le(((l=i.onError)===null||l===void 0?void 0:l.call(i,{file:h}))||h),d(h)}})}function bo(e,i,o){const n=po(e,i,o);o.onabort=n.handleXHRAbort,o.onerror=n.handleXHRError,o.onload=n.handleXHRLoad,o.upload&&(o.upload.onprogress=n.handleXHRProgress)}function tt(e,i){return typeof e=="function"?e({file:i}):e||{}}function Co(e,i,o){const n=tt(i,o);n&&Object.keys(n).forEach(a=>{e.setRequestHeader(a,n[a])})}function xo(e,i,o){const n=tt(i,o);n&&Object.keys(n).forEach(a=>{e.append(a,n[a])})}function yo(e,i,o,{method:n,action:a,withCredentials:s,responseType:u,headers:c,data:d}){const r=new XMLHttpRequest;r.responseType=u,e.xhrMap.set(o.id,r),r.withCredentials=s;const l=new FormData;if(xo(l,d,o),o.file!==null&&l.append(i,o.file),bo(e,o,r),a!==void 0){r.open(n.toUpperCase(),a),Co(r,c,o),r.send(l);const h=Object.assign({},o,{status:"uploading"});e.doChange(h)}}const Ro=Object.assign(Object.assign({},he.props),{name:{type:String,default:"file"},accept:String,action:String,customRequest:Function,directory:Boolean,directoryDnd:{type:Boolean,default:void 0},method:{type:String,default:"POST"},multiple:Boolean,showFileList:{type:Boolean,default:!0},data:[Object,Function],headers:[Object,Function],withCredentials:Boolean,responseType:{type:String,default:""},disabled:{type:Boolean,default:void 0},onChange:Function,onRemove:Function,onFinish:Function,onError:Function,onBeforeUpload:Function,isErrorState:Function,onDownload:Function,defaultUpload:{type:Boolean,default:!0},fileList:Array,"onUpdate:fileList":[Function,Array],onUpdateFileList:[Function,Array],fileListClass:String,fileListStyle:[String,Object],defaultFileList:{type:Array,default:()=>[]},showCancelButton:{type:Boolean,default:!0},showRemoveButton:{type:Boolean,default:!0},showDownloadButton:Boolean,showRetryButton:{type:Boolean,default:!0},showPreviewButton:{type:Boolean,default:!0},listType:{type:String,default:"text"},onPreview:Function,shouldUseThumbnailUrl:{type:Function,default:e=>io?Qe(e):!1},createThumbnailUrl:Function,abstract:Boolean,max:Number,showTrigger:{type:Boolean,default:!0},imageGroupProps:Object,inputProps:Object,triggerClass:String,triggerStyle:[String,Object],renderIcon:Function}),Do=Q({name:"Upload",props:Ro,setup(e){e.abstract&&e.listType==="image-card"&&ve("upload","when the list-type is image-card, abstract is not supported.");const{mergedClsPrefixRef:i,inlineThemeDisabled:o}=ge(e),n=he("Upload","-upload",mo,Rt,e,i),a=Tt(e),s=H(e.defaultFileList),u=S(e,"fileList"),c=H(null),d={value:!1},r=H(!1),l=new Map,h=Dt(u,s),b=$(()=>h.value.map(le)),L=$(()=>{const{max:v}=e;return v!==void 0?b.value.length>=v:!1});function x(){var v;(v=c.value)===null||v===void 0||v.click()}function j(v){const k=v.target;q(k.files?Array.from(k.files).map(R=>({file:R,entry:null,source:"input"})):null,v),k.value=""}function X(v){const{"onUpdate:fileList":k,onUpdateFileList:R}=e;k&&je(k,v),R&&je(R,v),s.value=v}const E=$(()=>e.multiple||e.directory),U=(v,k,R={append:!1,remove:!1})=>{const{append:T,remove:D}=R,N=Array.from(b.value),_=N.findIndex(I=>I.id===v.id);if(T||D||~_){T?N.push(v):D?N.splice(_,1):N.splice(_,1,v);const{onChange:I}=e;I&&I({file:v,fileList:N,event:k}),X(N)}};function q(v,k){if(!v||v.length===0)return;const{onBeforeUpload:R}=e;v=E.value?v:[v[0]];const{max:T,accept:D}=e;v=v.filter(({file:_,source:I})=>I==="dnd"&&D?.trim()?so(_.name,_.type,D):!0),T&&(v=v.slice(0,T-b.value.length));const N=Le();Promise.all(v.map(_=>He(this,[_],void 0,function*({file:I,entry:W}){var Z;const ee={id:Le(),batchId:N,name:I.name,status:"pending",percentage:0,file:I,url:null,type:I.type,thumbnailUrl:null,fullPath:(Z=W?.fullPath)!==null&&Z!==void 0?Z:`/${I.webkitRelativePath||I.name}`};return!R||(yield R({file:ee,fileList:b.value}))!==!1?ee:null}))).then(_=>He(this,void 0,void 0,function*(){let I=Promise.resolve();_.forEach(W=>{I=I.then(kt).then(()=>{W&&U(W,k,{append:!0})})}),yield I})).then(()=>{e.defaultUpload&&B()})}function B(v){const{method:k,action:R,withCredentials:T,headers:D,data:N,name:_}=e,I=v!==void 0?b.value.filter(Z=>Z.id===v):b.value,W=v!==void 0;I.forEach(Z=>{const{status:ee}=Z;(ee==="pending"||ee==="error"&&W)&&(e.customRequest?wo({inst:{doChange:U,xhrMap:l,onFinish:e.onFinish,onError:e.onError},file:Z,action:R,withCredentials:T,headers:D,data:N,customRequest:e.customRequest}):yo({doChange:U,xhrMap:l,onFinish:e.onFinish,onError:e.onError,isErrorState:e.isErrorState},_,Z,{method:k,action:R,withCredentials:T,responseType:e.responseType,headers:D,data:N}))})}function m(v){var k;if(v.thumbnailUrl)return v.thumbnailUrl;const{createThumbnailUrl:R}=e;return R?(k=R(v.file,v))!==null&&k!==void 0?k:v.url||"":v.url?v.url:v.file?no(v.file):""}const y=$(()=>{const{common:{cubicBezierEaseInOut:v},self:{draggerColor:k,draggerBorder:R,draggerBorderHover:T,itemColorHover:D,itemColorHoverError:N,itemTextColorError:_,itemTextColorSuccess:I,itemTextColor:W,itemIconColor:Z,itemDisabledOpacity:ee,lineHeight:me,borderRadius:ae,fontSize:pe,itemBorderImageCardError:we,itemBorderImageCard:be}}=n.value;return{"--n-bezier":v,"--n-border-radius":ae,"--n-dragger-border":R,"--n-dragger-border-hover":T,"--n-dragger-color":k,"--n-font-size":pe,"--n-item-color-hover":D,"--n-item-color-hover-error":N,"--n-item-disabled-opacity":ee,"--n-item-icon-color":Z,"--n-item-text-color":W,"--n-item-text-color-error":_,"--n-item-text-color-success":I,"--n-line-height":me,"--n-item-border-image-card-error":we,"--n-item-border-image-card":be}}),C=o?Ve("upload",void 0,y,e):void 0;Se(re,{mergedClsPrefixRef:i,mergedThemeRef:n,showCancelButtonRef:S(e,"showCancelButton"),showDownloadButtonRef:S(e,"showDownloadButton"),showRemoveButtonRef:S(e,"showRemoveButton"),showRetryButtonRef:S(e,"showRetryButton"),onRemoveRef:S(e,"onRemove"),onDownloadRef:S(e,"onDownload"),mergedFileListRef:b,triggerClassRef:S(e,"triggerClass"),triggerStyleRef:S(e,"triggerStyle"),shouldUseThumbnailUrlRef:S(e,"shouldUseThumbnailUrl"),renderIconRef:S(e,"renderIcon"),xhrMap:l,submit:B,doChange:U,showPreviewButtonRef:S(e,"showPreviewButton"),onPreviewRef:S(e,"onPreview"),getFileThumbnailUrlResolver:m,listTypeRef:S(e,"listType"),dragOverRef:r,openOpenFileDialog:x,draggerInsideRef:d,handleFileAddition:q,mergedDisabledRef:a.mergedDisabledRef,maxReachedRef:L,fileListClassRef:S(e,"fileListClass"),fileListStyleRef:S(e,"fileListStyle"),abstractRef:S(e,"abstract"),acceptRef:S(e,"accept"),cssVarsRef:o?void 0:y,themeClassRef:C?.themeClass,onRender:C?.onRender,showTriggerRef:S(e,"showTrigger"),imageGroupPropsRef:S(e,"imageGroupProps"),mergedDirectoryDndRef:$(()=>{var v;return(v=e.directoryDnd)!==null&&v!==void 0?v:e.directory})});const z={clear:()=>{s.value=[]},submit:B,openOpenFileDialog:x};return Object.assign({mergedClsPrefix:i,draggerInsideRef:d,inputElRef:c,mergedTheme:n,dragOver:r,mergedMultiple:E,cssVars:o?void 0:y,themeClass:C?.themeClass,onRender:C?.onRender,handleFileInputChange:j},z)},render(){var e,i;const{draggerInsideRef:o,mergedClsPrefix:n,$slots:a,directory:s,onRender:u}=this;if(a.default&&!this.abstract){const d=a.default()[0];!((e=d?.type)===null||e===void 0)&&e[Ke]&&(o.value=!0)}const c=t("input",Object.assign({},this.inputProps,{ref:"inputElRef",type:"file",class:`${n}-upload-file-input`,accept:this.accept,multiple:this.mergedMultiple,onChange:this.handleFileInputChange,webkitdirectory:s||void 0,directory:s||void 0}));return this.abstract?t(fe,null,(i=a.default)===null||i===void 0?void 0:i.call(a),t(Lt,{to:"body"},c)):(u?.(),t("div",{class:[`${n}-upload`,o.value&&`${n}-upload--dragger-inside`,this.dragOver&&`${n}-upload--drag-over`,this.themeClass],style:this.cssVars},c,this.showTrigger&&this.listType!=="image-card"&&t(et,null,a),this.showFileList&&t(vo,null,a)))}});export{Do as N};
