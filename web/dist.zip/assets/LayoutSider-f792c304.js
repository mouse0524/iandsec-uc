import{aV as G,j as J,bC as Q,bD as F,D as Y,e as a,g as y,d as L,m as j,r as R,l as M,C as A,bE as V,c as C,v as W,h as d,b9 as D,i as n,a as z,J as Z,G as ee,t as N,ay as _,S as k}from"./index-5696747f.js";import{C as oe}from"./Dropdown-9dd5d126.js";import{u as te}from"./use-merged-state-a7aebbe5.js";function re(e){const{baseColor:o,textColor2:r,bodyColor:u,cardColor:b,dividerColor:i,actionColor:p,scrollbarColor:B,scrollbarColorHover:x,invertedColor:h}=e;return{textColor:r,textColorInverted:"#FFF",color:u,colorEmbedded:p,headerColor:b,headerColorInverted:h,footerColor:p,footerColorInverted:h,headerBorderColor:i,headerBorderColorInverted:h,footerBorderColor:i,footerBorderColorInverted:h,siderBorderColor:i,siderBorderColorInverted:h,siderColor:b,siderColorInverted:h,siderToggleButtonBorder:`1px solid ${i}`,siderToggleButtonColor:o,siderToggleButtonIconColor:r,siderToggleButtonIconColorInverted:r,siderToggleBarColor:F(u,B),siderToggleBarColorHover:F(u,x),__invertScrollbar:"true"}}const le=G({name:"Layout",common:J,peers:{Scrollbar:Q},self:re}),H=le,se=Y("n-layout-sider"),U={type:String,default:"static"},ne=a("layout",`
 color: var(--n-text-color);
 background-color: var(--n-color);
 box-sizing: border-box;
 position: relative;
 z-index: auto;
 flex: auto;
 overflow: hidden;
 transition:
 box-shadow .3s var(--n-bezier),
 background-color .3s var(--n-bezier),
 color .3s var(--n-bezier);
`,[a("layout-scroll-container",`
 overflow-x: hidden;
 box-sizing: border-box;
 height: 100%;
 `),y("absolute-positioned",`
 position: absolute;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 `)]),ae={embedded:Boolean,position:U,nativeScrollbar:{type:Boolean,default:!0},scrollbarProps:Object,onScroll:Function,contentClass:String,contentStyle:{type:[String,Object],default:""},hasSider:Boolean,siderPlacement:{type:String,default:"left"}},X=Y("n-layout");function ie(e){return L({name:e?"LayoutContent":"Layout",props:Object.assign(Object.assign({},j.props),ae),setup(o){const r=R(null),u=R(null),{mergedClsPrefixRef:b,inlineThemeDisabled:i}=M(o),p=j("Layout","-layout",ne,H,o,b);function B(c,g){if(o.nativeScrollbar){const{value:f}=r;f&&(g===void 0?f.scrollTo(c):f.scrollTo(c,g))}else{const{value:f}=u;f&&f.scrollTo(c,g)}}A(X,o);let x=0,h=0;const O=c=>{var g;const f=c.target;x=f.scrollLeft,h=f.scrollTop,(g=o.onScroll)===null||g===void 0||g.call(o,c)};V(()=>{if(o.nativeScrollbar){const c=r.value;c&&(c.scrollTop=h,c.scrollLeft=x)}});const w={display:"flex",flexWrap:"nowrap",width:"100%",flexDirection:"row"},I={scrollTo:B},P=C(()=>{const{common:{cubicBezierEaseInOut:c},self:g}=p.value;return{"--n-bezier":c,"--n-color":o.embedded?g.colorEmbedded:g.color,"--n-text-color":g.textColor}}),m=i?W("layout",C(()=>o.embedded?"e":""),P,o):void 0;return Object.assign({mergedClsPrefix:b,scrollableElRef:r,scrollbarInstRef:u,hasSiderStyle:w,mergedTheme:p,handleNativeElScroll:O,cssVars:i?void 0:P,themeClass:m?.themeClass,onRender:m?.onRender},I)},render(){var o;const{mergedClsPrefix:r,hasSider:u}=this;(o=this.onRender)===null||o===void 0||o.call(this);const b=u?this.hasSiderStyle:void 0,i=[this.themeClass,e&&`${r}-layout-content`,`${r}-layout`,`${r}-layout--${this.position}-positioned`];return d("div",{class:i,style:this.cssVars},this.nativeScrollbar?d("div",{ref:"scrollableElRef",class:[`${r}-layout-scroll-container`,this.contentClass],style:[this.contentStyle,b],onScroll:this.handleNativeElScroll},this.$slots):d(D,Object.assign({},this.scrollbarProps,{onScroll:this.onScroll,ref:"scrollbarInstRef",theme:this.mergedTheme.peers.Scrollbar,themeOverrides:this.mergedTheme.peerOverrides.Scrollbar,contentClass:this.contentClass,contentStyle:[this.contentStyle,b]}),this.$slots))}})}const ve=ie(!1),ce=a("layout-sider",`
 flex-shrink: 0;
 box-sizing: border-box;
 position: relative;
 z-index: 1;
 color: var(--n-text-color);
 transition:
 color .3s var(--n-bezier),
 border-color .3s var(--n-bezier),
 min-width .3s var(--n-bezier),
 max-width .3s var(--n-bezier),
 transform .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 background-color: var(--n-color);
 display: flex;
 justify-content: flex-end;
`,[y("bordered",[n("border",`
 content: "";
 position: absolute;
 top: 0;
 bottom: 0;
 width: 1px;
 background-color: var(--n-border-color);
 transition: background-color .3s var(--n-bezier);
 `)]),n("left-placement",[y("bordered",[n("border",`
 right: 0;
 `)])]),y("right-placement",`
 justify-content: flex-start;
 `,[y("bordered",[n("border",`
 left: 0;
 `)]),y("collapsed",[a("layout-toggle-button",[a("base-icon",`
 transform: rotate(180deg);
 `)]),a("layout-toggle-bar",[z("&:hover",[n("top",{transform:"rotate(-12deg) scale(1.15) translateY(-2px)"}),n("bottom",{transform:"rotate(12deg) scale(1.15) translateY(2px)"})])])]),a("layout-toggle-button",`
 left: 0;
 transform: translateX(-50%) translateY(-50%);
 `,[a("base-icon",`
 transform: rotate(0);
 `)]),a("layout-toggle-bar",`
 left: -28px;
 transform: rotate(180deg);
 `,[z("&:hover",[n("top",{transform:"rotate(12deg) scale(1.15) translateY(-2px)"}),n("bottom",{transform:"rotate(-12deg) scale(1.15) translateY(2px)"})])])]),y("collapsed",[a("layout-toggle-bar",[z("&:hover",[n("top",{transform:"rotate(-12deg) scale(1.15) translateY(-2px)"}),n("bottom",{transform:"rotate(12deg) scale(1.15) translateY(2px)"})])]),a("layout-toggle-button",[a("base-icon",`
 transform: rotate(0);
 `)])]),a("layout-toggle-button",`
 transition:
 color .3s var(--n-bezier),
 right .3s var(--n-bezier),
 left .3s var(--n-bezier),
 border-color .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 cursor: pointer;
 width: 24px;
 height: 24px;
 position: absolute;
 top: 50%;
 right: 0;
 border-radius: 50%;
 display: flex;
 align-items: center;
 justify-content: center;
 font-size: 18px;
 color: var(--n-toggle-button-icon-color);
 border: var(--n-toggle-button-border);
 background-color: var(--n-toggle-button-color);
 box-shadow: 0 2px 4px 0px rgba(0, 0, 0, .06);
 transform: translateX(50%) translateY(-50%);
 z-index: 1;
 `,[a("base-icon",`
 transition: transform .3s var(--n-bezier);
 transform: rotate(180deg);
 `)]),a("layout-toggle-bar",`
 cursor: pointer;
 height: 72px;
 width: 32px;
 position: absolute;
 top: calc(50% - 36px);
 right: -28px;
 `,[n("top, bottom",`
 position: absolute;
 width: 4px;
 border-radius: 2px;
 height: 38px;
 left: 14px;
 transition: 
 background-color .3s var(--n-bezier),
 transform .3s var(--n-bezier);
 `),n("bottom",`
 position: absolute;
 top: 34px;
 `),z("&:hover",[n("top",{transform:"rotate(12deg) scale(1.15) translateY(-2px)"}),n("bottom",{transform:"rotate(-12deg) scale(1.15) translateY(2px)"})]),n("top, bottom",{backgroundColor:"var(--n-toggle-bar-color)"}),z("&:hover",[n("top, bottom",{backgroundColor:"var(--n-toggle-bar-color-hover)"})])]),n("border",`
 position: absolute;
 top: 0;
 right: 0;
 bottom: 0;
 width: 1px;
 transition: background-color .3s var(--n-bezier);
 `),a("layout-sider-scroll-container",`
 flex-grow: 1;
 flex-shrink: 0;
 box-sizing: border-box;
 height: 100%;
 opacity: 0;
 transition: opacity .3s var(--n-bezier);
 max-width: 100%;
 `),y("show-content",[a("layout-sider-scroll-container",{opacity:1})]),y("absolute-positioned",`
 position: absolute;
 left: 0;
 top: 0;
 bottom: 0;
 `)]),de=L({name:"LayoutToggleButton",props:{clsPrefix:{type:String,required:!0},onClick:Function},render(){const{clsPrefix:e}=this;return d("div",{class:`${e}-layout-toggle-button`,onClick:this.onClick},d(Z,{clsPrefix:e},{default:()=>d(oe,null)}))}}),ue=L({props:{clsPrefix:{type:String,required:!0},onClick:Function},render(){const{clsPrefix:e}=this;return d("div",{onClick:this.onClick,class:`${e}-layout-toggle-bar`},d("div",{class:`${e}-layout-toggle-bar__top`}),d("div",{class:`${e}-layout-toggle-bar__bottom`}))}}),ge={position:U,bordered:Boolean,collapsedWidth:{type:Number,default:48},width:{type:[Number,String],default:272},contentClass:String,contentStyle:{type:[String,Object],default:""},collapseMode:{type:String,default:"transform"},collapsed:{type:Boolean,default:void 0},defaultCollapsed:Boolean,showCollapsedContent:{type:Boolean,default:!0},showTrigger:{type:[Boolean,String],default:!1},nativeScrollbar:{type:Boolean,default:!0},inverted:Boolean,scrollbarProps:Object,triggerClass:String,triggerStyle:[String,Object],collapsedTriggerClass:String,collapsedTriggerStyle:[String,Object],"onUpdate:collapsed":[Function,Array],onUpdateCollapsed:[Function,Array],onAfterEnter:Function,onAfterLeave:Function,onExpand:[Function,Array],onCollapse:[Function,Array],onScroll:Function},me=L({name:"LayoutSider",props:Object.assign(Object.assign({},j.props),ge),setup(e){const o=ee(X),r=R(null),u=R(null),b=R(e.defaultCollapsed),i=te(N(e,"collapsed"),b),p=C(()=>_(i.value?e.collapsedWidth:e.width)),B=C(()=>e.collapseMode!=="transform"?{}:{minWidth:_(e.width)}),x=C(()=>o?o.siderPlacement:"left");function h(s,t){if(e.nativeScrollbar){const{value:l}=r;l&&(t===void 0?l.scrollTo(s):l.scrollTo(s,t))}else{const{value:l}=u;l&&l.scrollTo(s,t)}}function O(){const{"onUpdate:collapsed":s,onUpdateCollapsed:t,onExpand:l,onCollapse:$}=e,{value:T}=i;t&&k(t,!T),s&&k(s,!T),b.value=!T,T?l&&k(l):$&&k($)}let w=0,I=0;const P=s=>{var t;const l=s.target;w=l.scrollLeft,I=l.scrollTop,(t=e.onScroll)===null||t===void 0||t.call(e,s)};V(()=>{if(e.nativeScrollbar){const s=r.value;s&&(s.scrollTop=I,s.scrollLeft=w)}}),A(se,{collapsedRef:i,collapseModeRef:N(e,"collapseMode")});const{mergedClsPrefixRef:m,inlineThemeDisabled:c}=M(e),g=j("Layout","-layout-sider",ce,H,e,m);function f(s){var t,l;s.propertyName==="max-width"&&(i.value?(t=e.onAfterLeave)===null||t===void 0||t.call(e):(l=e.onAfterEnter)===null||l===void 0||l.call(e))}const K={scrollTo:h},E=C(()=>{const{common:{cubicBezierEaseInOut:s},self:t}=g.value,{siderToggleButtonColor:l,siderToggleButtonBorder:$,siderToggleBarColor:T,siderToggleBarColorHover:q}=t,v={"--n-bezier":s,"--n-toggle-button-color":l,"--n-toggle-button-border":$,"--n-toggle-bar-color":T,"--n-toggle-bar-color-hover":q};return e.inverted?(v["--n-color"]=t.siderColorInverted,v["--n-text-color"]=t.textColorInverted,v["--n-border-color"]=t.siderBorderColorInverted,v["--n-toggle-button-icon-color"]=t.siderToggleButtonIconColorInverted,v.__invertScrollbar=t.__invertScrollbar):(v["--n-color"]=t.siderColor,v["--n-text-color"]=t.textColor,v["--n-border-color"]=t.siderBorderColor,v["--n-toggle-button-icon-color"]=t.siderToggleButtonIconColor),v}),S=c?W("layout-sider",C(()=>e.inverted?"a":"b"),E,e):void 0;return Object.assign({scrollableElRef:r,scrollbarInstRef:u,mergedClsPrefix:m,mergedTheme:g,styleMaxWidth:p,mergedCollapsed:i,scrollContainerStyle:B,siderPlacement:x,handleNativeElScroll:P,handleTransitionend:f,handleTriggerClick:O,inlineThemeDisabled:c,cssVars:E,themeClass:S?.themeClass,onRender:S?.onRender},K)},render(){var e;const{mergedClsPrefix:o,mergedCollapsed:r,showTrigger:u}=this;return(e=this.onRender)===null||e===void 0||e.call(this),d("aside",{class:[`${o}-layout-sider`,this.themeClass,`${o}-layout-sider--${this.position}-positioned`,`${o}-layout-sider--${this.siderPlacement}-placement`,this.bordered&&`${o}-layout-sider--bordered`,r&&`${o}-layout-sider--collapsed`,(!r||this.showCollapsedContent)&&`${o}-layout-sider--show-content`],onTransitionend:this.handleTransitionend,style:[this.inlineThemeDisabled?void 0:this.cssVars,{maxWidth:this.styleMaxWidth,width:_(this.width)}]},this.nativeScrollbar?d("div",{class:[`${o}-layout-sider-scroll-container`,this.contentClass],onScroll:this.handleNativeElScroll,style:[this.scrollContainerStyle,{overflow:"auto"},this.contentStyle],ref:"scrollableElRef"},this.$slots):d(D,Object.assign({},this.scrollbarProps,{onScroll:this.onScroll,ref:"scrollbarInstRef",style:this.scrollContainerStyle,contentStyle:this.contentStyle,contentClass:this.contentClass,theme:this.mergedTheme.peers.Scrollbar,themeOverrides:this.mergedTheme.peerOverrides.Scrollbar,builtinThemeOverrides:this.inverted&&this.cssVars.__invertScrollbar==="true"?{colorHover:"rgba(255, 255, 255, .4)",color:"rgba(255, 255, 255, .3)"}:void 0}),this.$slots),u?u==="bar"?d(ue,{clsPrefix:o,class:r?this.collapsedTriggerClass:this.triggerClass,style:r?this.collapsedTriggerStyle:this.triggerStyle,onClick:this.handleTriggerClick}):d(de,{clsPrefix:o,class:r?this.collapsedTriggerClass:this.triggerClass,style:r?this.collapsedTriggerStyle:this.triggerStyle,onClick:this.handleTriggerClick}):null,this.bordered?d("div",{class:`${o}-layout-sider__border`}):null)}});export{me as N,ve as a,ie as c,se as l};
