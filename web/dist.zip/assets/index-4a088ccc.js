import{F as $e,j as Se,aw as Te,e as _,g as P,a as j,i as k,d as me,l as ue,m as he,C as Ie,h as x,D as Be,G as Ae,ax as Pe,c as S,s as L,ay as je,v as Le,az as oe,z as se,r as $,w as _e,ak as B,aA as Me,Y as r,$ as v,Z as z,_ as b,a7 as e,a4 as m,ag as M,a1 as y,a3 as U,I as R,a0 as Q,ab as V,ah as ee,ai as Re,aB as Ue,a2 as Ne,aj as Oe,al as De,am as Ee,X as Fe}from"./index-5696747f.js";import{_ as Ve}from"./CommonPage-aedd426b.js";import{_ as He}from"./CrudModal-a130952a.js";import{i as ae,s as te}from"./sanitize-0635dc57.js";import{t as We,a as qe,m as Ke}from"./ticket-meta-3041687f.js";import{_ as ve}from"./_plugin-vue_export-helper-c27b6911.js";import{N as ce}from"./Spin-6c0277c7.js";import{N as re}from"./Empty-a18a0912.js";import{N as Ge}from"./Tag-b56d7bab.js";import{N as Xe}from"./Alert-95001d88.js";import"./AppPage-ce030f87.js";import"./use-merged-state-a7aebbe5.js";import"./use-compitable-77ab7946.js";import"./use-locale-2287e579.js";let le=!1;function Ye(){if($e&&window.CSS&&!le&&(le=!0,"registerProperty"in window?.CSS))try{CSS.registerProperty({name:"--n-color-start",syntax:"<color>",inherits:!1,initialValue:"#0000"}),CSS.registerProperty({name:"--n-color-end",syntax:"<color>",inherits:!1,initialValue:"#0000"})}catch{}}function Ze(n){const{textColor3:o,infoColor:d,errorColor:u,successColor:a,warningColor:f,textColor1:p,textColor2:g,railColor:C,fontWeightStrong:T,fontSize:I}=n;return Object.assign(Object.assign({},Te),{contentFontSize:I,titleFontWeight:T,circleBorder:`2px solid ${o}`,circleBorderInfo:`2px solid ${d}`,circleBorderError:`2px solid ${u}`,circleBorderSuccess:`2px solid ${a}`,circleBorderWarning:`2px solid ${f}`,iconColor:o,iconColorInfo:d,iconColorError:u,iconColorSuccess:a,iconColorWarning:f,titleTextColor:p,contentTextColor:g,metaTextColor:o,lineColor:C})}const Je={name:"Timeline",common:Se,self:Ze},Qe=Je,de=1.25,et=_("timeline",`
 position: relative;
 width: 100%;
 display: flex;
 flex-direction: column;
 line-height: ${de};
`,[P("horizontal",`
 flex-direction: row;
 `,[j(">",[_("timeline-item",`
 flex-shrink: 0;
 padding-right: 40px;
 `,[P("dashed-line-type",[j(">",[_("timeline-item-timeline",[k("line",`
 background-image: linear-gradient(90deg, var(--n-color-start), var(--n-color-start) 50%, transparent 50%, transparent 100%);
 background-size: 10px 1px;
 `)])])]),j(">",[_("timeline-item-content",`
 margin-top: calc(var(--n-icon-size) + 12px);
 `,[j(">",[k("meta",`
 margin-top: 6px;
 margin-bottom: unset;
 `)])]),_("timeline-item-timeline",`
 width: 100%;
 height: calc(var(--n-icon-size) + 12px);
 `,[k("line",`
 left: var(--n-icon-size);
 top: calc(var(--n-icon-size) / 2 - 1px);
 right: 0px;
 width: unset;
 height: 2px;
 `)])])])])]),P("right-placement",[_("timeline-item",[_("timeline-item-content",`
 text-align: right;
 margin-right: calc(var(--n-icon-size) + 12px);
 `),_("timeline-item-timeline",`
 width: var(--n-icon-size);
 right: 0;
 `)])]),P("left-placement",[_("timeline-item",[_("timeline-item-content",`
 margin-left: calc(var(--n-icon-size) + 12px);
 `),_("timeline-item-timeline",`
 left: 0;
 `)])]),_("timeline-item",`
 position: relative;
 `,[j("&:last-child",[_("timeline-item-timeline",[k("line",`
 display: none;
 `)]),_("timeline-item-content",[k("meta",`
 margin-bottom: 0;
 `)])]),_("timeline-item-content",[k("title",`
 margin: var(--n-title-margin);
 font-size: var(--n-title-font-size);
 transition: color .3s var(--n-bezier);
 font-weight: var(--n-title-font-weight);
 color: var(--n-title-text-color);
 `),k("content",`
 transition: color .3s var(--n-bezier);
 font-size: var(--n-content-font-size);
 color: var(--n-content-text-color);
 `),k("meta",`
 transition: color .3s var(--n-bezier);
 font-size: 12px;
 margin-top: 6px;
 margin-bottom: 20px;
 color: var(--n-meta-text-color);
 `)]),P("dashed-line-type",[_("timeline-item-timeline",[k("line",`
 --n-color-start: var(--n-line-color);
 transition: --n-color-start .3s var(--n-bezier);
 background-color: transparent;
 background-image: linear-gradient(180deg, var(--n-color-start), var(--n-color-start) 50%, transparent 50%, transparent 100%);
 background-size: 1px 10px;
 `)])]),_("timeline-item-timeline",`
 width: calc(var(--n-icon-size) + 12px);
 position: absolute;
 top: calc(var(--n-title-font-size) * ${de} / 2 - var(--n-icon-size) / 2);
 height: 100%;
 `,[k("circle",`
 border: var(--n-circle-border);
 transition:
 background-color .3s var(--n-bezier),
 border-color .3s var(--n-bezier);
 width: var(--n-icon-size);
 height: var(--n-icon-size);
 border-radius: var(--n-icon-size);
 box-sizing: border-box;
 `),k("icon",`
 color: var(--n-icon-color);
 font-size: var(--n-icon-size);
 height: var(--n-icon-size);
 width: var(--n-icon-size);
 display: flex;
 align-items: center;
 justify-content: center;
 `),k("line",`
 transition: background-color .3s var(--n-bezier);
 position: absolute;
 top: var(--n-icon-size);
 left: calc(var(--n-icon-size) / 2 - 1px);
 bottom: 0px;
 width: 2px;
 background-color: var(--n-line-color);
 `)])])]),tt=Object.assign(Object.assign({},he.props),{horizontal:Boolean,itemPlacement:{type:String,default:"left"},size:{type:String,default:"medium"},iconSize:Number}),pe=Be("n-timeline"),it=me({name:"Timeline",props:tt,setup(n,{slots:o}){const{mergedClsPrefixRef:d}=ue(n),u=he("Timeline","-timeline",et,Qe,n,d);return Ie(pe,{props:n,mergedThemeRef:u,mergedClsPrefixRef:d}),()=>{const{value:a}=d;return x("div",{class:[`${a}-timeline`,n.horizontal&&`${a}-timeline--horizontal`,`${a}-timeline--${n.size}-size`,!n.horizontal&&`${a}-timeline--${n.itemPlacement}-placement`]},o)}}}),nt={time:[String,Number],title:String,content:String,color:String,lineType:{type:String,default:"default"},type:{type:String,default:"default"}},ot=me({name:"TimelineItem",props:nt,setup(n){const o=Ae(pe);o||Pe("timeline-item","`n-timeline-item` must be placed inside `n-timeline`."),Ye();const{inlineThemeDisabled:d}=ue(),u=S(()=>{const{props:{size:f,iconSize:p},mergedThemeRef:g}=o,{type:C}=n,{self:{titleTextColor:T,contentTextColor:I,metaTextColor:H,lineColor:W,titleFontWeight:q,contentFontSize:K,[L("iconSize",f)]:A,[L("titleMargin",f)]:N,[L("titleFontSize",f)]:G,[L("circleBorder",C)]:O,[L("iconColor",C)]:X},common:{cubicBezierEaseInOut:D}}=g.value;return{"--n-bezier":D,"--n-circle-border":O,"--n-icon-color":X,"--n-content-font-size":K,"--n-content-text-color":I,"--n-line-color":W,"--n-meta-text-color":H,"--n-title-font-size":G,"--n-title-font-weight":q,"--n-title-margin":N,"--n-title-text-color":T,"--n-icon-size":je(p)||A}}),a=d?Le("timeline-item",S(()=>{const{props:{size:f,iconSize:p}}=o,{type:g}=n;return`${f[0]}${p||"a"}${g[0]}`}),u,o.props):void 0;return{mergedClsPrefix:o.mergedClsPrefixRef,cssVars:d?void 0:u,themeClass:a?.themeClass,onRender:a?.onRender}},render(){const{mergedClsPrefix:n,color:o,onRender:d,$slots:u}=this;return d?.(),x("div",{class:[`${n}-timeline-item`,this.themeClass,`${n}-timeline-item--${this.type}-type`,`${n}-timeline-item--${this.lineType}-line-type`],style:this.cssVars},x("div",{class:`${n}-timeline-item-timeline`},x("div",{class:`${n}-timeline-item-timeline__line`}),oe(u.icon,a=>a?x("div",{class:`${n}-timeline-item-timeline__icon`,style:{color:o}},a):x("div",{class:`${n}-timeline-item-timeline__circle`,style:{borderColor:o}}))),x("div",{class:`${n}-timeline-item-content`},oe(u.header,a=>a||this.title?x("div",{class:`${n}-timeline-item-content__title`},a||this.title):null),x("div",{class:`${n}-timeline-item-content__content`},se(u.default,()=>[this.content])),x("div",{class:`${n}-timeline-item-content__meta`},se(u.footer,()=>[this.time]))))}});const c=n=>(De("data-v-c7a40633"),n=n(),Ee(),n),st={class:"detail-header"},at={class:"detail-no"},ct={class:"detail-title"},rt={class:"detail-section basic-section"},lt=c(()=>e("div",{class:"section-title"},"基本信息",-1)),dt={class:"detail-grid"},mt={class:"detail-card"},ut=c(()=>e("span",null,"项目名称",-1)),ht={class:"detail-card"},_t=c(()=>e("span",null,"联系人",-1)),vt={class:"detail-card"},pt=c(()=>e("span",null,"联系方式",-1)),ft={class:"detail-card"},gt=c(()=>e("span",null,"项目阶段",-1)),yt={class:"detail-card"},kt=c(()=>e("span",null,"跟踪",-1)),bt={class:"detail-card"},wt=c(()=>e("span",null,"影响范围",-1)),xt={class:"detail-card"},zt=c(()=>e("span",null,"问题分类",-1)),Ct={class:"detail-card"},$t=c(()=>e("span",null,"创建时间",-1)),St={class:"detail-card"},Tt=c(()=>e("span",null,"提交人",-1)),It={class:"detail-card"},Bt=c(()=>e("span",null,"附件数量",-1)),At={class:"detail-card"},Pt=c(()=>e("span",null,"客服审核人",-1)),jt={class:"detail-card"},Lt=c(()=>e("span",null,"指派技术",-1)),Mt={class:"detail-card"},Rt=c(()=>e("span",null,"问题根因",-1)),Ut={class:"detail-card"},Nt=c(()=>e("span",null,"完成时间",-1)),Ot={class:"detail-section issue-section"},Dt=c(()=>e("div",{class:"section-title"},"问题描述",-1)),Et={key:0,class:"detail-loading"},Ft=c(()=>e("span",null,"详情加载中...",-1)),Vt=["innerHTML"],Ht=c(()=>e("div",{class:"subsection-title"},"附件列表",-1)),Wt={key:0,class:"image-preview-grid"},qt=["href"],Kt=["src","alt"],Gt={key:1,class:"attachment-list"},Xt={class:"attachment-name"},Yt={class:"attachment-meta"},Zt={class:"attachment-actions"},Jt={class:"detail-section timeline-card"},Qt=c(()=>e("div",{class:"section-title"},"流转日志",-1)),ei={key:0,class:"detail-loading"},ti=c(()=>e("span",null,"流转日志加载中...",-1)),ii={key:0,viewBox:"0 0 24 24","aria-hidden":"true"},ni=c(()=>e("path",{d:"M5 12.5l3.2 3.2L14 10"},null,-1)),oi=c(()=>e("path",{d:"M10 12.5l3.2 3.2L19 10"},null,-1)),si=[ni,oi],ai={key:1,viewBox:"0 0 24 24","aria-hidden":"true"},ci=c(()=>e("circle",{cx:"12",cy:"12",r:"3.5",fill:"currentColor",stroke:"none"},null,-1)),ri=[ci],li={key:2,viewBox:"0 0 24 24","aria-hidden":"true"},di=c(()=>e("path",{d:"M16.5 7.5A6 6 0 1 0 18 12"},null,-1)),mi=c(()=>e("path",{d:"M16.5 4.5v3h-3"},null,-1)),ui=[di,mi],hi={key:3,viewBox:"0 0 24 24","aria-hidden":"true"},_i=c(()=>e("path",{d:"M8 8l8 8"},null,-1)),vi=c(()=>e("path",{d:"M16 8l-8 8"},null,-1)),pi=[_i,vi],fi={key:4,viewBox:"0 0 24 24","aria-hidden":"true"},gi=c(()=>e("path",{d:"M6 12.5l4 4L18 8.5"},null,-1)),yi=[gi],ki={class:"timeline-content"},bi=["innerHTML"],wi={class:"timeline-meta"},xi={key:0,class:"timeline-meta"},zi={class:"description-image-preview"},Ci=["src","alt"],$i={__name:"TicketDetailModal",props:{visible:{type:Boolean,default:!1},ticket:{type:Object,default(){return{}}},loading:{type:Boolean,default:!1},embedded:{type:Boolean,default:!1}},emits:["update:visible"],setup(n){const o=n,d=S(()=>o.ticket?.attachments||[]),u=S(()=>d.value.filter(t=>ae(t.origin_name||t.file_path||""))),a=new Set(["docx","pptx","xlsx"]),f=$(null),p=$({}),g=$({}),C=$(!1),T=$(""),I=$(""),H=S(()=>te(o.ticket?.description||"-")),W=S(()=>Array.isArray(o.ticket?.actions)&&o.ticket.actions.length>0),q=S(()=>o.embedded?"div":He),K=S(()=>o.embedded?{class:"ticket-detail-content"}:{visible:o.visible,title:"工单详情",width:"min(96vw, 1280px)",showFooter:!1});function A(){Object.values(p.value||{}).forEach(t=>{t&&URL.revokeObjectURL(t)}),Object.values(g.value||{}).forEach(t=>{t&&URL.revokeObjectURL(t)})}function N(t){return p.value[t.id]||""}function G(){C.value=!1,T.value="",I.value=""}function O(t){const s=t?.target;if(!(s instanceof HTMLImageElement))return;const l=s.currentSrc||s.src;l&&(t.preventDefault(),T.value=l,I.value=s.alt||"问题描述图片",C.value=!0)}function X(t){O(t)}function D(t){const l=String(t||"").match(/[?&]attachment_id=(\d+)/);return l?Number(l[1]):null}function ie(t,s){return`${t||"action"}:${s}`}function fe(t){const s=[],l=new Set;for(const h of t||[]){const i=String(h?.comment||""),F=new DOMParser().parseFromString(i,"text/html");for(const Ce of Array.from(F.querySelectorAll("img[src]"))){const Z=D(Ce.getAttribute("src"));if(!Z)continue;const J=ie(h.id,Z);l.has(J)||(l.add(J),s.push({key:J,attachmentId:Z}))}}return s}_e(()=>[o.visible,o.ticket?.id,u.value.map(t=>t.id).join(","),(o.ticket?.actions||[]).map(t=>`${t.id}:${t.updated_at||t.created_at||""}`).join(",")],async([t])=>{if(!t){A(),p.value={},g.value={},G();return}A();const s={};for(const h of u.value)try{const i=await B.downloadTicketAttachment({attachment_id:h.id}),w=i instanceof Blob?i:new Blob([i]);s[h.id]=URL.createObjectURL(w)}catch{s[h.id]=""}p.value=s;const l={};for(const h of fe(o.ticket?.actions||[]))try{const i=await B.downloadTicketAttachment({attachment_id:h.attachmentId}),w=i instanceof Blob?i:new Blob([i]);l[h.key]=URL.createObjectURL(w)}catch{l[h.key]=""}g.value=l},{immediate:!0}),Me(()=>{A(),p.value={},g.value={}});async function ge(t){if(!t?.id)return;const s=await B.downloadTicketAttachment({attachment_id:t.id}),l=s instanceof Blob?s:new Blob([s]),h=window.URL.createObjectURL(l),i=document.createElement("a");i.href=h,i.download=t.origin_name||`attachment-${t.id}`,document.body.appendChild(i),i.click(),i.remove(),window.URL.revokeObjectURL(h)}function ye(t){const l=String(t?.origin_name||t?.file_path||"").split(".").pop()?.toLowerCase();return a.has(l)}async function ke(t){if(t?.id){f.value=t.id;try{const l=(await B.previewTicketAttachment({attachment_id:t.id}))?.data?.preview_url||"";if(!l){$message.error("预览链接生成失败，请稍后重试");return}const h=`/public/webdav/preview?${new URLSearchParams({name:t.origin_name||`attachment-${t.id}`,url:l}).toString()}`;window.open(h,"_blank","noopener,noreferrer")}finally{f.value=null}}}async function be(t){const s=await B.downloadTicketAttachment({attachment_id:t.id}),l=s instanceof Blob?s:new Blob([s]);if(!l.type.startsWith("image/")){$message.warning("仅支持复制图片附件");return}await navigator.clipboard.write([new ClipboardItem({[l.type]:l})]),$message.success("图片已复制")}function we(t){if(!t)return"-";if(t.action==="finish"&&o.ticket?.root_cause){const i=t.comment?.trim()||(ne(t)?"转产研":"处理完成");return te(`${i}（根因：${o.ticket.root_cause}）`)}const s=te(t.comment||"-"),h=new DOMParser().parseFromString(s,"text/html");for(const i of Array.from(h.querySelectorAll("img[src]"))){const w=D(i.getAttribute("src"));if(!w)continue;const F=g.value[ie(t.id,w)];F&&i.setAttribute("src",F)}return h.body.innerHTML}function Y(t){return t==="cs_reject"||t==="tech_reject"}function ne(t){return t?.action==="finish"&&t?.from_status==="tech_processing"&&t?.to_status==="test_filtering"}function xe(t){return ne(t)?"转产研":Ke(t?.action)}function E(t){return t==="finish"?"finish":t==="submit"||t==="resubmit"?"submit":t==="tech_start"?"handle":Y(t)?"reject":"pass"}function ze(t){return Y(t)?"is-reject":t==="finish"?"is-finish":t==="submit"||t==="resubmit"?"is-submit":t==="tech_start"?"is-handle":"is-pass"}return(t,s)=>{const l=ot,h=it;return r(),v(R,null,[(r(),z(Ne(q.value),Ue(K.value,{"onUpdate:visible":s[0]||(s[0]=i=>t.$emit("update:visible",i))}),{default:b(()=>[e("div",st,[e("div",null,[e("div",at,m(n.ticket.ticket_no),1),e("div",ct,m(n.ticket.title),1)]),M(y(Ge),{class:"status-tag",type:y(We)[n.ticket.status]||"default"},{default:b(()=>[U(m(y(qe)[n.ticket.status]||"-"),1)]),_:1},8,["type"])]),e("section",rt,[lt,e("div",dt,[e("div",mt,[ut,e("strong",null,m(n.ticket.company_name||"-"),1)]),e("div",ht,[_t,e("strong",null,m(n.ticket.contact_name||"-"),1)]),e("div",vt,[pt,e("strong",null,m(n.ticket.phone||"-"),1)]),e("div",ft,[gt,e("strong",null,m(n.ticket.project_phase||"-"),1)]),e("div",yt,[kt,e("strong",null,m(n.ticket.issue_type||"-"),1)]),e("div",bt,[wt,e("strong",null,m(n.ticket.impact_scope||"-"),1)]),e("div",xt,[zt,e("strong",null,m(n.ticket.category||"-"),1)]),e("div",Ct,[$t,e("strong",null,m(n.ticket.created_at||"-"),1)]),e("div",St,[Tt,e("strong",null,m(n.ticket.submitter_name||n.ticket.submitter_id||"-"),1)]),e("div",It,[Bt,e("strong",null,m(n.ticket.attachment_count??d.value.length),1)]),e("div",At,[Pt,e("strong",null,m(n.ticket.reviewer_name||n.ticket.reviewer_id||"-"),1)]),e("div",jt,[Lt,e("strong",null,m(n.ticket.tech_name||n.ticket.tech_id||"-"),1)]),e("div",Mt,[Rt,e("strong",null,m(n.ticket.root_cause||"-"),1)]),e("div",Ut,[Nt,e("strong",null,m(n.ticket.finished_at||"-"),1)])])]),e("section",Ot,[Dt,n.loading?(r(),v("div",Et,[M(y(ce),{size:"small"}),Ft])):(r(),v(R,{key:1},[e("div",{class:"description-content",onClick:O,innerHTML:H.value},null,8,Vt),Ht,u.value.length?(r(),v("div",Wt,[(r(!0),v(R,null,Q(u.value,i=>(r(),v("a",{key:`img-${i.id}`,href:N(i),target:"_blank",rel:"noopener",class:"image-preview-item"},[e("img",{src:N(i),alt:i.origin_name||`image-${i.id}`},null,8,Kt)],8,qt))),128))])):V("",!0),d.value.length?(r(),v("div",Gt,[(r(!0),v(R,null,Q(d.value,i=>(r(),v("div",{key:i.id,class:"attachment-item"},[e("div",null,[e("div",Xt,m(i.origin_name||i.file_path),1),e("div",Yt,m(i.mime_type||"application/octet-stream")+" / "+m(i.file_size||0)+" bytes",1)]),e("div",Zt,[y(ae)(i.origin_name||i.file_path||"")?(r(),z(y(ee),{key:0,size:"small",type:"info",quaternary:"",onClick:w=>be(i)},{default:b(()=>[U("复制图片")]),_:2},1032,["onClick"])):V("",!0),ye(i)?(r(),z(y(ee),{key:1,size:"small",type:"info",quaternary:"",loading:f.value===i.id,onClick:w=>ke(i)},{default:b(()=>[U(" 预览 ")]),_:2},1032,["loading","onClick"])):V("",!0),M(y(ee),{size:"small",type:"primary",quaternary:"",onClick:w=>ge(i)},{default:b(()=>[U("下载")]),_:2},1032,["onClick"])])]))),128))])):(r(),z(y(re),{key:2,description:"暂无附件",size:"small"}))],64))]),e("section",Jt,[Qt,n.loading?(r(),v("div",ei,[M(y(ce),{size:"small"}),ti])):W.value?(r(),z(h,{key:1,class:"ticket-timeline"},{default:b(()=>[(r(!0),v(R,null,Q(n.ticket.actions||[],i=>(r(),z(l,{key:i.id,title:xe(i),type:Y(i.action)?"error":"success"},{icon:b(()=>[e("span",{class:Re(["timeline-icon",ze(i.action)])},[E(i.action)==="finish"?(r(),v("svg",ii,si)):E(i.action)==="submit"?(r(),v("svg",ai,ri)):E(i.action)==="handle"?(r(),v("svg",li,ui)):E(i.action)==="reject"?(r(),v("svg",hi,pi)):(r(),v("svg",fi,yi))],2)]),default:b(()=>[e("div",ki,[e("div",{class:"timeline-comment",onClick:X,innerHTML:we(i)},null,8,bi),e("div",wi,"操作者："+m(i.operator_display||i.operator_name||i.operator_id||"-"),1),i.created_at?(r(),v("div",xi,"时间："+m(i.created_at),1)):V("",!0)])]),_:2},1032,["title","type"]))),128))]),_:1})):(r(),z(y(re),{key:2,description:"暂无流转日志",size:"small"}))])]),_:1},16)),M(y(Oe),{show:C.value,"onUpdate:show":s[1]||(s[1]=i=>C.value=i),preset:"card",title:"图片预览",class:"description-image-modal"},{default:b(()=>[e("div",zi,[e("img",{src:T.value,alt:I.value},null,8,Ci)])]),_:1},8,["show"])],64)}}},Si=ve($i,[["__scopeId","data-v-c7a40633"]]);const Ti={class:"ticket-detail-page"},Ii=Object.assign({name:"工单详情"},{__name:"index",setup(n){const o=Fe(),d=$({}),u=$(!1),a=$("");async function f(){const p=Number(o.query.ticket_id||0);if(!p){a.value="缺少工单ID",d.value={};return}u.value=!0,a.value="",d.value={id:p};try{const g=await B.getTicketById({ticket_id:p});d.value=g?.data||{}}catch{a.value="加载工单详情失败"}finally{u.value=!1}}return _e(()=>o.query.ticket_id,f,{immediate:!0}),(p,g)=>(r(),z(Ve,{"show-header":!1},{default:b(()=>[e("div",Ti,[a.value?(r(),z(y(Xe),{key:0,type:"error"},{default:b(()=>[U(m(a.value),1)]),_:1})):(r(),z(Si,{key:1,embedded:"",visible:!0,ticket:d.value,loading:u.value},null,8,["ticket","loading"]))])]),_:1}))}}),Hi=ve(Ii,[["__scopeId","data-v-24840ee1"]]);export{Hi as default};
