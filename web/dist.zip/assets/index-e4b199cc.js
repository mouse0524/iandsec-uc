import{e as l,a as u,i as y,d as ee,l as te,u as re,h as w,ad as ae,r as s,c as U,w as oe,p as ie,Y as N,Z as T,_ as a,ag as r,a1 as o,ak as h,a7 as q,ah as m,a3 as _,a4 as B,ab as L,aJ as ne,aj as le}from"./index-5b5f01f8.js";import{_ as se}from"./CommonPage-c31d5b0f.js";import{_ as $}from"./QueryBarItem-ff2618c3.js";import{_ as ue}from"./CrudTable-a06a540d.js";import{_ as M}from"./TheIcon-cc320586.js";import{_ as de}from"./_plugin-vue_export-helper-c27b6911.js";import{a as pe,N as F}from"./Tabs-334bf708.js";import{N as j}from"./Input-0e6f9dfa.js";import{N as me}from"./Select-3f746c4c.js";import{N as ce,a as fe}from"./FormItem-96169356.js";import{N as ve}from"./Tag-24ce47f4.js";import"./AppPage-ea40ff0f.js";import"./use-merged-state-3a6a5de3.js";import"./Space-d75629e5.js";import"./get-slot-1efb97e5.js";import"./DataTable-6ac79e2e.js";import"./Checkbox-5f37402b.js";import"./Popover-09b892d6.js";import"./get-9858023f.js";import"./use-compitable-129e0075.js";import"./Dropdown-01ffb93a.js";import"./create-bc5aca98.js";import"./Tooltip-19315eb2.js";import"./Empty-4c3899b5.js";import"./use-locale-986116e5.js";import"./download-953ccaa2.js";import"./Add-93c6e904.js";const be=l("input-group",`
 display: inline-flex;
 width: 100%;
 flex-wrap: nowrap;
 vertical-align: bottom;
`,[u(">",[l("input",[u("&:not(:last-child)",`
 border-top-right-radius: 0!important;
 border-bottom-right-radius: 0!important;
 `),u("&:not(:first-child)",`
 border-top-left-radius: 0!important;
 border-bottom-left-radius: 0!important;
 margin-left: -1px!important;
 `)]),l("button",[u("&:not(:last-child)",`
 border-top-right-radius: 0!important;
 border-bottom-right-radius: 0!important;
 `,[y("state-border, border",`
 border-top-right-radius: 0!important;
 border-bottom-right-radius: 0!important;
 `)]),u("&:not(:first-child)",`
 border-top-left-radius: 0!important;
 border-bottom-left-radius: 0!important;
 `,[y("state-border, border",`
 border-top-left-radius: 0!important;
 border-bottom-left-radius: 0!important;
 `)])]),u("*",[u("&:not(:last-child)",`
 border-top-right-radius: 0!important;
 border-bottom-right-radius: 0!important;
 `,[u(">",[l("input",`
 border-top-right-radius: 0!important;
 border-bottom-right-radius: 0!important;
 `),l("base-selection",[l("base-selection-label",`
 border-top-right-radius: 0!important;
 border-bottom-right-radius: 0!important;
 `),l("base-selection-tags",`
 border-top-right-radius: 0!important;
 border-bottom-right-radius: 0!important;
 `),y("box-shadow, border, state-border",`
 border-top-right-radius: 0!important;
 border-bottom-right-radius: 0!important;
 `)])])]),u("&:not(:first-child)",`
 margin-left: -1px!important;
 border-top-left-radius: 0!important;
 border-bottom-left-radius: 0!important;
 `,[u(">",[l("input",`
 border-top-left-radius: 0!important;
 border-bottom-left-radius: 0!important;
 `),l("base-selection",[l("base-selection-label",`
 border-top-left-radius: 0!important;
 border-bottom-left-radius: 0!important;
 `),l("base-selection-tags",`
 border-top-left-radius: 0!important;
 border-bottom-left-radius: 0!important;
 `),y("box-shadow, border, state-border",`
 border-top-left-radius: 0!important;
 border-bottom-left-radius: 0!important;
 `)])])])])])]),ge={},ye=ee({name:"InputGroup",props:ge,setup(b){const{mergedClsPrefixRef:g}=te(b);return re("-input-group",be,g),{mergedClsPrefix:g}},render(){const{mergedClsPrefix:b}=this;return w("div",{class:`${b}-input-group`},this.$slots)}});const he={class:"invite-tools"},_e={flex:"","justify-end":""},we=Object.assign({name:"注册审核"},{__name:"index",setup(b){const g=ae(),p=s(null),k=s("pending"),n=s({reviewed:!1,register_type:"all",keyword:""}),c=s(!1),x=s(!1),I=s(null),S=s(null),f=s({reason:""}),d=s(""),C=s(!1),v=s(!1);let R=0;const V=U(()=>(g.role||[]).some(e=>e?.name==="技术")),z={pending:"待审核",approved:"已通过",rejected:"已驳回"},E={channel:"渠道商",user:"用户"},G=[{label:"全部类型",value:"all"},{label:"渠道商",value:"channel"},{label:"用户",value:"user"}];function K(e){n.value.register_type=e||"all",p.value?.handleSearch()}oe(()=>n.value.register_type,e=>{(e==null||e==="")&&(n.value.register_type="all")}),ie(()=>{p.value?.handleSearch()});function O(e){return`${window.location.origin}/login?invite_code=${encodeURIComponent(e)}`}async function A(){C.value=!0;try{const e=await h.createPartnerInvite();d.value=e?.data?.link||(e?.data?.code?O(e.data.code):""),v.value=!1,d.value&&$message.success("邀请链接已生成")}finally{C.value=!1}}async function D(e){if(navigator.clipboard?.writeText&&window.isSecureContext){await navigator.clipboard.writeText(e);return}const t=document.createElement("textarea");t.value=e,t.setAttribute("readonly",""),t.style.position="fixed",t.style.left="-9999px",t.style.top="-9999px",document.body.appendChild(t),t.select();const i=document.execCommand("copy");if(t.remove(),!i)throw new Error("copy failed")}async function J(){if(d.value)try{await D(d.value),v.value=!0,window.clearTimeout(R),R=window.setTimeout(()=>{v.value=!1},1800),$message.success("邀请链接已复制")}catch{$message.error("复制失败，请手动选中链接复制")}}function Y(e){k.value=e,n.value.reviewed=e==="reviewed",n.value.keyword="",p.value?.handleSearch()}async function Z(e,t){await h.reviewPartnerRegister({id:e.id,approved:t,comment:t?"审核通过":"审核驳回"}),$message.success("审核已完成，通知邮件已发送"),p.value?.handleSearch()}function H(e){I.value=e,f.value.reason="",c.value=!0}function Q(){S.value?.validate(async e=>{if(!e)try{x.value=!0,await h.reviewPartnerRegister({id:I.value.id,approved:!1,comment:f.value.reason}),$message.success("驳回已提交，通知邮件已发送"),c.value=!1,p.value?.handleSearch()}finally{x.value=!1}})}const P=[{title:"提交时间",key:"created_at",align:"center"},{title:"注册类型",key:"register_type",align:"center",render(e){return E[e.register_type]||"-"}},{title:"公司名称",key:"company_name",align:"center"},{title:"联系人",key:"contact_name",align:"center"},{title:"邮箱",key:"email",align:"center"},{title:"手机号",key:"phone",align:"center"},{title:"设备机器码",key:"hardware_id",align:"center",render:e=>e.hardware_id||"-"},{title:"状态",key:"status",align:"center",render(e){const t=e.status==="pending"?"warning":e.status==="approved"?"success":"error";return w(ve,{type:t},{default:()=>z[e.status]||e.status})}},{title:"审核时间",key:"reviewed_at",align:"center",render(e){return e.reviewed_at||"-"}},{title:"驳回理由",key:"review_comment",align:"center",render(e){return e.status==="rejected"&&e.review_comment||"-"}}],W={title:"操作",key:"actions",align:"center",render(e){return e.status!=="pending"?"-":[w(m,{size:"small",type:"primary",style:"margin-right: 8px",onClick:()=>Z(e,!0)},{default:()=>"通过"}),w(m,{size:"small",type:"error",onClick:()=>H(e)},{default:()=>"驳回"})]}},X=U(()=>k.value==="reviewed"?P:[...P,W]);return(e,t)=>(N(),T(se,{title:"注册审核","show-header":!1,"show-footer":""},{default:a(()=>[r(o(pe),{type:"line",value:k.value,"onUpdate:value":Y,"mb-12":""},{default:a(()=>[r(o(F),{name:"pending",tab:"待审核"}),r(o(F),{name:"reviewed",tab:"已审核"})]),_:1},8,["value"]),r(ue,{ref_key:"$table",ref:p,"query-items":n.value,"onUpdate:queryItems":t[4]||(t[4]=i=>n.value=i),columns:X.value,"get-data":o(h).getPartnerRegisterList},{queryBar:a(()=>[V.value?(N(),T($,{key:0,label:"","label-width":0},{default:a(()=>[q("div",he,[r(o(m),{type:"primary",loading:C.value,onClick:A},{icon:a(()=>[r(M,{icon:"material-symbols:add-link-rounded",size:18})]),default:a(()=>[_(" "+B(d.value?"重新生成":"生成邀请链接"),1)]),_:1},8,["loading"]),d.value?(N(),T(o(ye),{key:0,class:"invite-link-group"},{default:a(()=>[r(o(j),{value:d.value,"onUpdate:value":t[0]||(t[0]=i=>d.value=i),class:"invite-link",readonly:"",placeholder:"邀请链接"},null,8,["value"]),r(o(m),{type:"primary",secondary:"",class:"copy-button",onClick:J},{icon:a(()=>[r(M,{icon:v.value?"material-symbols:check-rounded":"material-symbols:content-copy-outline-rounded",size:18},null,8,["icon"])]),default:a(()=>[_(" "+B(v.value?"已复制":"复制"),1)]),_:1})]),_:1})):L("",!0)])]),_:1})):L("",!0),r($,{label:"注册类型","label-width":60},{default:a(()=>[r(o(me),{value:n.value.register_type,"onUpdate:value":[t[1]||(t[1]=i=>n.value.register_type=i),K],options:G,placeholder:"全部注册类型",style:{width:"180px"}},null,8,["value"])]),_:1}),r($,{label:"关键词","label-width":50},{default:a(()=>[r(o(j),{value:n.value.keyword,"onUpdate:value":t[2]||(t[2]=i=>n.value.keyword=i),clearable:"",placeholder:"公司/联系人/邮箱/手机号",onKeypress:t[3]||(t[3]=ne(i=>p.value?.handleSearch(),["enter"]))},null,8,["value"])]),_:1})]),_:1},8,["query-items","columns","get-data"]),r(o(le),{show:c.value,"onUpdate:show":t[7]||(t[7]=i=>c.value=i),preset:"card",title:"驳回注册申请",style:{width:"520px"}},{footer:a(()=>[q("div",_e,[r(o(m),{onClick:t[6]||(t[6]=i=>c.value=!1)},{default:a(()=>[_("取消")]),_:1}),r(o(m),{"ml-12":"",type:"error",loading:x.value,onClick:Q},{default:a(()=>[_("提交驳回")]),_:1},8,["loading"])])]),default:a(()=>[r(o(ce),{ref_key:"rejectFormRef",ref:S,model:f.value,rules:{reason:{required:!0,message:"请填写驳回理由",trigger:["blur","input"]}}},{default:a(()=>[r(o(fe),{label:"驳回理由",path:"reason"},{default:a(()=>[r(o(j),{value:f.value.reason,"onUpdate:value":t[5]||(t[5]=i=>f.value.reason=i),type:"textarea",placeholder:"请输入驳回理由（将通过邮件通知用户）"},null,8,["value"])]),_:1})]),_:1},8,["model"])]),_:1},8,["show"])]),_:1}))}}),Ze=de(we,[["__scopeId","data-v-c3157427"]]);export{Ze as default};
