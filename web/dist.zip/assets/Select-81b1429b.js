import{d as de,b$ as en,p as Ke,cQ as tn,cR as nn,c as k,r as P,K as je,bL as ot,bd as Ve,h as r,be as on,V as st,cS as dt,au as yt,e as _,i as E,a as re,l as Ue,m as be,bD as ln,G as rt,cH as rn,s as he,v as qe,J as xt,H as Re,y as Ct,g as le,O as lt,k as St,q as Rt,t as Q,cT as an,w as Te,n as Tt,bM as _e,C as ut,bF as ct,bI as sn,a$ as dn,z as un,bE as cn,R as fn,cU as hn,I as vn,cV as gn,b0 as bn,b2 as pn,ao as mn,ap as wn,b3 as ft,b5 as yn,b4 as xn,S as se}from"./index-48131692.js";import{u as ht}from"./use-merged-state-56c7087f.js";import{u as Cn}from"./use-compitable-1e43a823.js";import{a as Sn,h as Be,V as vt,g as gt,c as Rn}from"./create-0c0ffd37.js";import{u as Ft,a as Tn}from"./Input-5e8cdf68.js";import{N as Je}from"./Tag-6c51745f.js";import{c as Fn,i as at,d as On,N as zn,u as it,V as Mn,a as Pn,b as kn}from"./Popover-412f9d1c.js";import{c as In,a as Qe}from"./get-2f1b5eaa.js";function et(e){const n=e.filter(o=>o!==void 0);if(n.length!==0)return n.length===1?n[0]:o=>{e.forEach(d=>{d&&d(o)})}}function bt(e){return e&-e}class _n{constructor(n,o){this.l=n,this.min=o;const d=new Array(n+1);for(let a=0;a<n+1;++a)d[a]=0;this.ft=d}add(n,o){if(o===0)return;const{l:d,ft:a}=this;for(n+=1;n<=d;)a[n]+=o,n+=bt(n)}get(n){return this.sum(n+1)-this.sum(n)}sum(n){if(n===void 0&&(n=this.l),n<=0)return 0;const{ft:o,min:d,l:a}=this;if(n>a)throw new Error("[FinweckTree.sum]: `i` is larger than length.");let u=n*d;for(;n>0;)u+=o[n],n-=bt(n);return u}getBound(n){let o=0,d=this.l;for(;d>o;){const a=Math.floor((o+d)/2),u=this.sum(a);if(u>n){d=a;continue}else if(u<n){if(o===a)return this.sum(o+1)<=n?o+1:a;o=a}else return a}return o}}let He;function Bn(){return typeof document>"u"?!1:(He===void 0&&("matchMedia"in window?He=window.matchMedia("(pointer:coarse)").matches:He=!1),He)}let tt;function pt(){return typeof document>"u"?1:(tt===void 0&&(tt="chrome"in window?window.devicePixelRatio:1),tt)}const $n=Qe(".v-vl",{maxHeight:"inherit",height:"100%",overflow:"auto",minWidth:"1px"},[Qe("&:not(.v-vl--show-scrollbar)",{scrollbarWidth:"none"},[Qe("&::-webkit-scrollbar, &::-webkit-scrollbar-track-piece, &::-webkit-scrollbar-thumb",{width:0,height:0,display:"none"})])]),En=de({name:"VirtualList",inheritAttrs:!1,props:{showScrollbar:{type:Boolean,default:!0},items:{type:Array,default:()=>[]},itemSize:{type:Number,required:!0},itemResizable:Boolean,itemsStyle:[String,Object],visibleItemsTag:{type:[String,Object],default:"div"},visibleItemsProps:Object,ignoreItemResize:Boolean,onScroll:Function,onWheel:Function,onResize:Function,defaultScrollKey:[Number,String],defaultScrollIndex:Number,keyField:{type:String,default:"key"},paddingTop:{type:[Number,String],default:0},paddingBottom:{type:[Number,String],default:0}},setup(e){const n=en();$n.mount({id:"vueuc/virtual-list",head:!0,anchorMetaName:In,ssr:n}),Ke(()=>{const{defaultScrollIndex:h,defaultScrollKey:b}=e;h!=null?y({index:h}):b!=null&&y({key:b})});let o=!1,d=!1;tn(()=>{if(o=!1,!d){d=!0;return}y({top:S.value,left:p})}),nn(()=>{o=!0,d||(d=!0)});const a=k(()=>{const h=new Map,{keyField:b}=e;return e.items.forEach((m,N)=>{h.set(m[b],N)}),h}),u=P(null),v=P(void 0),s=new Map,T=k(()=>{const{items:h,itemSize:b,keyField:m}=e,N=new _n(h.length,b);return h.forEach((D,V)=>{const H=D[m],j=s.get(H);j!==void 0&&N.add(V,j)}),N}),C=P(0);let p=0;const S=P(0),x=je(()=>Math.max(T.value.getBound(S.value-ot(e.paddingTop))-1,0)),F=k(()=>{const{value:h}=v;if(h===void 0)return[];const{items:b,itemSize:m}=e,N=x.value,D=Math.min(N+Math.ceil(h/m+1),b.length-1),V=[];for(let H=N;H<=D;++H)V.push(b[H]);return V}),y=(h,b)=>{if(typeof h=="number"){O(h,b,"auto");return}const{left:m,top:N,index:D,key:V,position:H,behavior:j,debounce:X=!0}=h;if(m!==void 0||N!==void 0)O(m,N,j);else if(D!==void 0)B(D,j,X);else if(V!==void 0){const Y=a.value.get(V);Y!==void 0&&B(Y,j,X)}else H==="bottom"?O(0,Number.MAX_SAFE_INTEGER,j):H==="top"&&O(0,0,j)};let $,K=null;function B(h,b,m){const{value:N}=T,D=N.sum(h)+ot(e.paddingTop);if(!m)u.value.scrollTo({left:0,top:D,behavior:b});else{$=h,K!==null&&window.clearTimeout(K),K=window.setTimeout(()=>{$=void 0,K=null},16);const{scrollTop:V,offsetHeight:H}=u.value;if(D>V){const j=N.get(h);D+j<=V+H||u.value.scrollTo({left:0,top:D+j-H,behavior:b})}else u.value.scrollTo({left:0,top:D,behavior:b})}}function O(h,b,m){u.value.scrollTo({left:h,top:b,behavior:m})}function L(h,b){var m,N,D;if(o||e.ignoreItemResize||ne(b.target))return;const{value:V}=T,H=a.value.get(h),j=V.get(H),X=(D=(N=(m=b.borderBoxSize)===null||m===void 0?void 0:m[0])===null||N===void 0?void 0:N.blockSize)!==null&&D!==void 0?D:b.contentRect.height;if(X===j)return;X-e.itemSize===0?s.delete(h):s.set(h,X-e.itemSize);const Z=X-j;if(Z===0)return;V.add(H,Z);const l=u.value;if(l!=null){if($===void 0){const f=V.sum(H);l.scrollTop>f&&l.scrollBy(0,Z)}else if(H<$)l.scrollBy(0,Z);else if(H===$){const f=V.sum(H);X+f>l.scrollTop+l.offsetHeight&&l.scrollBy(0,Z)}ie()}C.value++}const W=!Bn();let A=!1;function te(h){var b;(b=e.onScroll)===null||b===void 0||b.call(e,h),(!W||!A)&&ie()}function ee(h){var b;if((b=e.onWheel)===null||b===void 0||b.call(e,h),W){const m=u.value;if(m!=null){if(h.deltaX===0&&(m.scrollTop===0&&h.deltaY<=0||m.scrollTop+m.offsetHeight>=m.scrollHeight&&h.deltaY>=0))return;h.preventDefault(),m.scrollTop+=h.deltaY/pt(),m.scrollLeft+=h.deltaX/pt(),ie(),A=!0,Fn(()=>{A=!1})}}}function ue(h){if(o||ne(h.target)||h.contentRect.height===v.value)return;v.value=h.contentRect.height;const{onResize:b}=e;b!==void 0&&b(h)}function ie(){const{value:h}=u;h!=null&&(S.value=h.scrollTop,p=h.scrollLeft)}function ne(h){let b=h;for(;b!==null;){if(b.style.display==="none")return!0;b=b.parentElement}return!1}return{listHeight:v,listStyle:{overflow:"auto"},keyToIndex:a,itemsStyle:k(()=>{const{itemResizable:h}=e,b=Ve(T.value.sum());return C.value,[e.itemsStyle,{boxSizing:"content-box",height:h?"":b,minHeight:h?b:"",paddingTop:Ve(e.paddingTop),paddingBottom:Ve(e.paddingBottom)}]}),visibleItemsStyle:k(()=>(C.value,{transform:`translateY(${Ve(T.value.sum(x.value))})`})),viewportItems:F,listElRef:u,itemsElRef:P(null),scrollTo:y,handleListResize:ue,handleListScroll:te,handleListWheel:ee,handleItemResize:L}},render(){const{itemResizable:e,keyField:n,keyToIndex:o,visibleItemsTag:d}=this;return r(st,{onResize:this.handleListResize},{default:()=>{var a,u;return r("div",on(this.$attrs,{class:["v-vl",this.showScrollbar&&"v-vl--show-scrollbar"],onScroll:this.handleListScroll,onWheel:this.handleListWheel,ref:"listElRef"}),[this.items.length!==0?r("div",{ref:"itemsElRef",class:"v-vl-items",style:this.itemsStyle},[r(d,Object.assign({class:"v-vl-visible-items",style:this.visibleItemsStyle},this.visibleItemsProps),{default:()=>this.viewportItems.map(v=>{const s=v[n],T=o.get(s),C=this.$slots.default({item:v,index:T})[0];return e?r(st,{key:s,onResize:p=>this.handleItemResize(s,p)},{default:()=>C}):(C.key=s,C)})})]):(u=(a=this.$slots).empty)===null||u===void 0?void 0:u.call(a)])}})}});function Ot(e,n){n&&(Ke(()=>{const{value:o}=e;o&&dt.registerHandler(o,n)}),yt(()=>{const{value:o}=e;o&&dt.unregisterHandler(o)}))}const Nn=de({name:"Checkmark",render(){return r("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 16 16"},r("g",{fill:"none"},r("path",{d:"M14.046 3.486a.75.75 0 0 1-.032 1.06l-7.93 7.474a.85.85 0 0 1-1.188-.022l-2.68-2.72a.75.75 0 1 1 1.068-1.053l2.234 2.267l7.468-7.038a.75.75 0 0 1 1.06.032z",fill:"currentColor"})))}}),An=de({name:"Empty",render(){return r("svg",{viewBox:"0 0 28 28",fill:"none",xmlns:"http://www.w3.org/2000/svg"},r("path",{d:"M26 7.5C26 11.0899 23.0899 14 19.5 14C15.9101 14 13 11.0899 13 7.5C13 3.91015 15.9101 1 19.5 1C23.0899 1 26 3.91015 26 7.5ZM16.8536 4.14645C16.6583 3.95118 16.3417 3.95118 16.1464 4.14645C15.9512 4.34171 15.9512 4.65829 16.1464 4.85355L18.7929 7.5L16.1464 10.1464C15.9512 10.3417 15.9512 10.6583 16.1464 10.8536C16.3417 11.0488 16.6583 11.0488 16.8536 10.8536L19.5 8.20711L22.1464 10.8536C22.3417 11.0488 22.6583 11.0488 22.8536 10.8536C23.0488 10.6583 23.0488 10.3417 22.8536 10.1464L20.2071 7.5L22.8536 4.85355C23.0488 4.65829 23.0488 4.34171 22.8536 4.14645C22.6583 3.95118 22.3417 3.95118 22.1464 4.14645L19.5 6.79289L16.8536 4.14645Z",fill:"currentColor"}),r("path",{d:"M25 22.75V12.5991C24.5572 13.0765 24.053 13.4961 23.5 13.8454V16H17.5L17.3982 16.0068C17.0322 16.0565 16.75 16.3703 16.75 16.75C16.75 18.2688 15.5188 19.5 14 19.5C12.4812 19.5 11.25 18.2688 11.25 16.75L11.2432 16.6482C11.1935 16.2822 10.8797 16 10.5 16H4.5V7.25C4.5 6.2835 5.2835 5.5 6.25 5.5H12.2696C12.4146 4.97463 12.6153 4.47237 12.865 4H6.25C4.45507 4 3 5.45507 3 7.25V22.75C3 24.5449 4.45507 26 6.25 26H21.75C23.5449 26 25 24.5449 25 22.75ZM4.5 22.75V17.5H9.81597L9.85751 17.7041C10.2905 19.5919 11.9808 21 14 21L14.215 20.9947C16.2095 20.8953 17.842 19.4209 18.184 17.5H23.5V22.75C23.5 23.7165 22.7165 24.5 21.75 24.5H6.25C5.2835 24.5 4.5 23.7165 4.5 22.75Z",fill:"currentColor"}))}}),Ln=de({props:{onFocus:Function,onBlur:Function},setup(e){return()=>r("div",{style:"width: 0; height: 0",tabindex:0,onFocus:e.onFocus,onBlur:e.onBlur})}}),Dn=_("empty",`
 display: flex;
 flex-direction: column;
 align-items: center;
 font-size: var(--n-font-size);
`,[E("icon",`
 width: var(--n-icon-size);
 height: var(--n-icon-size);
 font-size: var(--n-icon-size);
 line-height: var(--n-icon-size);
 color: var(--n-icon-color);
 transition:
 color .3s var(--n-bezier);
 `,[re("+",[E("description",`
 margin-top: 8px;
 `)])]),E("description",`
 transition: color .3s var(--n-bezier);
 color: var(--n-text-color);
 `),E("extra",`
 text-align: center;
 transition: color .3s var(--n-bezier);
 margin-top: 12px;
 color: var(--n-extra-text-color);
 `)]),Vn=Object.assign(Object.assign({},be.props),{description:String,showDescription:{type:Boolean,default:!0},showIcon:{type:Boolean,default:!0},size:{type:String,default:"medium"},renderIcon:Function}),Hn=de({name:"Empty",props:Vn,setup(e){const{mergedClsPrefixRef:n,inlineThemeDisabled:o}=Ue(e),d=be("Empty","-empty",Dn,ln,e,n),{localeRef:a}=Ft("Empty"),u=rt(rn,null),v=k(()=>{var p,S,x;return(p=e.description)!==null&&p!==void 0?p:(x=(S=u?.mergedComponentPropsRef.value)===null||S===void 0?void 0:S.Empty)===null||x===void 0?void 0:x.description}),s=k(()=>{var p,S;return((S=(p=u?.mergedComponentPropsRef.value)===null||p===void 0?void 0:p.Empty)===null||S===void 0?void 0:S.renderIcon)||(()=>r(An,null))}),T=k(()=>{const{size:p}=e,{common:{cubicBezierEaseInOut:S},self:{[he("iconSize",p)]:x,[he("fontSize",p)]:F,textColor:y,iconColor:$,extraTextColor:K}}=d.value;return{"--n-icon-size":x,"--n-font-size":F,"--n-bezier":S,"--n-text-color":y,"--n-icon-color":$,"--n-extra-text-color":K}}),C=o?qe("empty",k(()=>{let p="";const{size:S}=e;return p+=S[0],p}),T,e):void 0;return{mergedClsPrefix:n,mergedRenderIcon:s,localizedDescription:k(()=>v.value||a.value.description),cssVars:o?void 0:T,themeClass:C?.themeClass,onRender:C?.onRender}},render(){const{$slots:e,mergedClsPrefix:n,onRender:o}=this;return o?.(),r("div",{class:[`${n}-empty`,this.themeClass],style:this.cssVars},this.showIcon?r("div",{class:`${n}-empty__icon`},e.icon?e.icon():r(xt,{clsPrefix:n},{default:this.mergedRenderIcon})):null,this.showDescription?r("div",{class:`${n}-empty__description`},e.default?e.default():this.localizedDescription):null,e.extra?r("div",{class:`${n}-empty__extra`},e.extra()):null)}});function jn(e,n){return r(Ct,{name:"fade-in-scale-up-transition"},{default:()=>e?r(xt,{clsPrefix:n,class:`${n}-base-select-option__check`},{default:()=>r(Nn)}):null})}const mt=de({name:"NBaseSelectOption",props:{clsPrefix:{type:String,required:!0},tmNode:{type:Object,required:!0}},setup(e){const{valueRef:n,pendingTmNodeRef:o,multipleRef:d,valueSetRef:a,renderLabelRef:u,renderOptionRef:v,labelFieldRef:s,valueFieldRef:T,showCheckmarkRef:C,nodePropsRef:p,handleOptionClick:S,handleOptionMouseEnter:x}=rt(at),F=je(()=>{const{value:B}=o;return B?e.tmNode.key===B.key:!1});function y(B){const{tmNode:O}=e;O.disabled||S(B,O)}function $(B){const{tmNode:O}=e;O.disabled||x(B,O)}function K(B){const{tmNode:O}=e,{value:L}=F;O.disabled||L||x(B,O)}return{multiple:d,isGrouped:je(()=>{const{tmNode:B}=e,{parent:O}=B;return O&&O.rawNode.type==="group"}),showCheckmark:C,nodeProps:p,isPending:F,isSelected:je(()=>{const{value:B}=n,{value:O}=d;if(B===null)return!1;const L=e.tmNode.rawNode[T.value];if(O){const{value:W}=a;return W.has(L)}else return B===L}),labelField:s,renderLabel:u,renderOption:v,handleMouseMove:K,handleMouseEnter:$,handleClick:y}},render(){const{clsPrefix:e,tmNode:{rawNode:n},isSelected:o,isPending:d,isGrouped:a,showCheckmark:u,nodeProps:v,renderOption:s,renderLabel:T,handleClick:C,handleMouseEnter:p,handleMouseMove:S}=this,x=jn(o,e),F=T?[T(n,o),u&&x]:[Re(n[this.labelField],n,o),u&&x],y=v?.(n),$=r("div",Object.assign({},y,{class:[`${e}-base-select-option`,n.class,y?.class,{[`${e}-base-select-option--disabled`]:n.disabled,[`${e}-base-select-option--selected`]:o,[`${e}-base-select-option--grouped`]:a,[`${e}-base-select-option--pending`]:d,[`${e}-base-select-option--show-checkmark`]:u}],style:[y?.style||"",n.style||""],onClick:et([C,y?.onClick]),onMouseenter:et([p,y?.onMouseenter]),onMousemove:et([S,y?.onMousemove])}),r("div",{class:`${e}-base-select-option__content`},F));return n.render?n.render({node:$,option:n,selected:o}):s?s({node:$,option:n,selected:o}):$}}),wt=de({name:"NBaseSelectGroupHeader",props:{clsPrefix:{type:String,required:!0},tmNode:{type:Object,required:!0}},setup(){const{renderLabelRef:e,renderOptionRef:n,labelFieldRef:o,nodePropsRef:d}=rt(at);return{labelField:o,nodeProps:d,renderLabel:e,renderOption:n}},render(){const{clsPrefix:e,renderLabel:n,renderOption:o,nodeProps:d,tmNode:{rawNode:a}}=this,u=d?.(a),v=n?n(a,!1):Re(a[this.labelField],a,!1),s=r("div",Object.assign({},u,{class:[`${e}-base-select-group-header`,u?.class]}),v);return a.render?a.render({node:s,option:a}):o?o({node:s,option:a,selected:!1}):s}}),Wn=_("base-select-menu",`
 line-height: 1.5;
 outline: none;
 z-index: 0;
 position: relative;
 border-radius: var(--n-border-radius);
 transition:
 background-color .3s var(--n-bezier),
 box-shadow .3s var(--n-bezier);
 background-color: var(--n-color);
`,[_("scrollbar",`
 max-height: var(--n-height);
 `),_("virtual-list",`
 max-height: var(--n-height);
 `),_("base-select-option",`
 min-height: var(--n-option-height);
 font-size: var(--n-option-font-size);
 display: flex;
 align-items: center;
 `,[E("content",`
 z-index: 1;
 white-space: nowrap;
 text-overflow: ellipsis;
 overflow: hidden;
 `)]),_("base-select-group-header",`
 min-height: var(--n-option-height);
 font-size: .93em;
 display: flex;
 align-items: center;
 `),_("base-select-menu-option-wrapper",`
 position: relative;
 width: 100%;
 `),E("loading, empty",`
 display: flex;
 padding: 12px 32px;
 flex: 1;
 justify-content: center;
 `),E("loading",`
 color: var(--n-loading-color);
 font-size: var(--n-loading-size);
 `),E("header",`
 padding: 8px var(--n-option-padding-left);
 font-size: var(--n-option-font-size);
 transition: 
 color .3s var(--n-bezier),
 border-color .3s var(--n-bezier);
 border-bottom: 1px solid var(--n-action-divider-color);
 color: var(--n-action-text-color);
 `),E("action",`
 padding: 8px var(--n-option-padding-left);
 font-size: var(--n-option-font-size);
 transition: 
 color .3s var(--n-bezier),
 border-color .3s var(--n-bezier);
 border-top: 1px solid var(--n-action-divider-color);
 color: var(--n-action-text-color);
 `),_("base-select-group-header",`
 position: relative;
 cursor: default;
 padding: var(--n-option-padding);
 color: var(--n-group-header-text-color);
 `),_("base-select-option",`
 cursor: pointer;
 position: relative;
 padding: var(--n-option-padding);
 transition:
 color .3s var(--n-bezier),
 opacity .3s var(--n-bezier);
 box-sizing: border-box;
 color: var(--n-option-text-color);
 opacity: 1;
 `,[le("show-checkmark",`
 padding-right: calc(var(--n-option-padding-right) + 20px);
 `),re("&::before",`
 content: "";
 position: absolute;
 left: 4px;
 right: 4px;
 top: 0;
 bottom: 0;
 border-radius: var(--n-border-radius);
 transition: background-color .3s var(--n-bezier);
 `),re("&:active",`
 color: var(--n-option-text-color-pressed);
 `),le("grouped",`
 padding-left: calc(var(--n-option-padding-left) * 1.5);
 `),le("pending",[re("&::before",`
 background-color: var(--n-option-color-pending);
 `)]),le("selected",`
 color: var(--n-option-text-color-active);
 `,[re("&::before",`
 background-color: var(--n-option-color-active);
 `),le("pending",[re("&::before",`
 background-color: var(--n-option-color-active-pending);
 `)])]),le("disabled",`
 cursor: not-allowed;
 `,[lt("selected",`
 color: var(--n-option-text-color-disabled);
 `),le("selected",`
 opacity: var(--n-option-opacity-disabled);
 `)]),E("check",`
 font-size: 16px;
 position: absolute;
 right: calc(var(--n-option-padding-right) - 4px);
 top: calc(50% - 7px);
 color: var(--n-option-check-color);
 transition: color .3s var(--n-bezier);
 `,[St({enterScale:"0.5"})])])]),Kn=de({name:"InternalSelectMenu",props:Object.assign(Object.assign({},be.props),{clsPrefix:{type:String,required:!0},scrollable:{type:Boolean,default:!0},treeMate:{type:Object,required:!0},multiple:Boolean,size:{type:String,default:"medium"},value:{type:[String,Number,Array],default:null},autoPending:Boolean,virtualScroll:{type:Boolean,default:!0},show:{type:Boolean,default:!0},labelField:{type:String,default:"label"},valueField:{type:String,default:"value"},loading:Boolean,focusable:Boolean,renderLabel:Function,renderOption:Function,nodeProps:Function,showCheckmark:{type:Boolean,default:!0},onMousedown:Function,onScroll:Function,onFocus:Function,onBlur:Function,onKeyup:Function,onKeydown:Function,onTabOut:Function,onMouseenter:Function,onMouseleave:Function,onResize:Function,resetMenuOnOptionsChange:{type:Boolean,default:!0},inlineThemeDisabled:Boolean,onToggle:Function}),setup(e){const{mergedClsPrefixRef:n,mergedRtlRef:o}=Ue(e),d=Rt("InternalSelectMenu",o,n),a=be("InternalSelectMenu","-internal-select-menu",Wn,an,e,Q(e,"clsPrefix")),u=P(null),v=P(null),s=P(null),T=k(()=>e.treeMate.getFlattenedNodes()),C=k(()=>Sn(T.value)),p=P(null);function S(){const{treeMate:l}=e;let f=null;const{value:U}=e;U===null?f=l.getFirstAvailableNode():(e.multiple?f=l.getNode((U||[])[(U||[]).length-1]):f=l.getNode(U),(!f||f.disabled)&&(f=l.getFirstAvailableNode())),N(f||null)}function x(){const{value:l}=p;l&&!e.treeMate.getNode(l.key)&&(p.value=null)}let F;Te(()=>e.show,l=>{l?F=Te(()=>e.treeMate,()=>{e.resetMenuOnOptionsChange?(e.autoPending?S():x(),Tt(D)):x()},{immediate:!0}):F?.()},{immediate:!0}),yt(()=>{F?.()});const y=k(()=>ot(a.value.self[he("optionHeight",e.size)])),$=k(()=>_e(a.value.self[he("padding",e.size)])),K=k(()=>e.multiple&&Array.isArray(e.value)?new Set(e.value):new Set),B=k(()=>{const l=T.value;return l&&l.length===0});function O(l){const{onToggle:f}=e;f&&f(l)}function L(l){const{onScroll:f}=e;f&&f(l)}function W(l){var f;(f=s.value)===null||f===void 0||f.sync(),L(l)}function A(){var l;(l=s.value)===null||l===void 0||l.sync()}function te(){const{value:l}=p;return l||null}function ee(l,f){f.disabled||N(f,!1)}function ue(l,f){f.disabled||O(f)}function ie(l){var f;Be(l,"action")||(f=e.onKeyup)===null||f===void 0||f.call(e,l)}function ne(l){var f;Be(l,"action")||(f=e.onKeydown)===null||f===void 0||f.call(e,l)}function h(l){var f;(f=e.onMousedown)===null||f===void 0||f.call(e,l),!e.focusable&&l.preventDefault()}function b(){const{value:l}=p;l&&N(l.getNext({loop:!0}),!0)}function m(){const{value:l}=p;l&&N(l.getPrev({loop:!0}),!0)}function N(l,f=!1){p.value=l,f&&D()}function D(){var l,f;const U=p.value;if(!U)return;const ce=C.value(U.key);ce!==null&&(e.virtualScroll?(l=v.value)===null||l===void 0||l.scrollTo({index:ce}):(f=s.value)===null||f===void 0||f.scrollTo({index:ce,elSize:y.value}))}function V(l){var f,U;!((f=u.value)===null||f===void 0)&&f.contains(l.target)&&((U=e.onFocus)===null||U===void 0||U.call(e,l))}function H(l){var f,U;!((f=u.value)===null||f===void 0)&&f.contains(l.relatedTarget)||(U=e.onBlur)===null||U===void 0||U.call(e,l)}ut(at,{handleOptionMouseEnter:ee,handleOptionClick:ue,valueSetRef:K,pendingTmNodeRef:p,nodePropsRef:Q(e,"nodeProps"),showCheckmarkRef:Q(e,"showCheckmark"),multipleRef:Q(e,"multiple"),valueRef:Q(e,"value"),renderLabelRef:Q(e,"renderLabel"),renderOptionRef:Q(e,"renderOption"),labelFieldRef:Q(e,"labelField"),valueFieldRef:Q(e,"valueField")}),ut(On,u),Ke(()=>{const{value:l}=s;l&&l.sync()});const j=k(()=>{const{size:l}=e,{common:{cubicBezierEaseInOut:f},self:{height:U,borderRadius:ce,color:ye,groupHeaderTextColor:xe,actionDividerColor:fe,optionTextColorPressed:oe,optionTextColor:Ce,optionTextColorDisabled:ve,optionTextColorActive:Fe,optionOpacityDisabled:Oe,optionCheckColor:ze,actionTextColor:Me,optionColorPending:pe,optionColorActive:me,loadingColor:Pe,loadingSize:ke,optionColorActivePending:Ie,[he("optionFontSize",l)]:Se,[he("optionHeight",l)]:we,[he("optionPadding",l)]:J}}=a.value;return{"--n-height":U,"--n-action-divider-color":fe,"--n-action-text-color":Me,"--n-bezier":f,"--n-border-radius":ce,"--n-color":ye,"--n-option-font-size":Se,"--n-group-header-text-color":xe,"--n-option-check-color":ze,"--n-option-color-pending":pe,"--n-option-color-active":me,"--n-option-color-active-pending":Ie,"--n-option-height":we,"--n-option-opacity-disabled":Oe,"--n-option-text-color":Ce,"--n-option-text-color-active":Fe,"--n-option-text-color-disabled":ve,"--n-option-text-color-pressed":oe,"--n-option-padding":J,"--n-option-padding-left":_e(J,"left"),"--n-option-padding-right":_e(J,"right"),"--n-loading-color":Pe,"--n-loading-size":ke}}),{inlineThemeDisabled:X}=e,Y=X?qe("internal-select-menu",k(()=>e.size[0]),j,e):void 0,Z={selfRef:u,next:b,prev:m,getPendingTmNode:te};return Ot(u,e.onResize),Object.assign({mergedTheme:a,mergedClsPrefix:n,rtlEnabled:d,virtualListRef:v,scrollbarRef:s,itemSize:y,padding:$,flattenedNodes:T,empty:B,virtualListContainer(){const{value:l}=v;return l?.listElRef},virtualListContent(){const{value:l}=v;return l?.itemsElRef},doScroll:L,handleFocusin:V,handleFocusout:H,handleKeyUp:ie,handleKeyDown:ne,handleMouseDown:h,handleVirtualListResize:A,handleVirtualListScroll:W,cssVars:X?void 0:j,themeClass:Y?.themeClass,onRender:Y?.onRender},Z)},render(){const{$slots:e,virtualScroll:n,clsPrefix:o,mergedTheme:d,themeClass:a,onRender:u}=this;return u?.(),r("div",{ref:"selfRef",tabindex:this.focusable?0:-1,class:[`${o}-base-select-menu`,this.rtlEnabled&&`${o}-base-select-menu--rtl`,a,this.multiple&&`${o}-base-select-menu--multiple`],style:this.cssVars,onFocusin:this.handleFocusin,onFocusout:this.handleFocusout,onKeyup:this.handleKeyUp,onKeydown:this.handleKeyDown,onMousedown:this.handleMouseDown,onMouseenter:this.onMouseenter,onMouseleave:this.onMouseleave},ct(e.header,v=>v&&r("div",{class:`${o}-base-select-menu__header`,"data-header":!0,key:"header"},v)),this.loading?r("div",{class:`${o}-base-select-menu__loading`},r(sn,{clsPrefix:o,strokeWidth:20})):this.empty?r("div",{class:`${o}-base-select-menu__empty`,"data-empty":!0},un(e.empty,()=>[r(Hn,{theme:d.peers.Empty,themeOverrides:d.peerOverrides.Empty})])):r(dn,{ref:"scrollbarRef",theme:d.peers.Scrollbar,themeOverrides:d.peerOverrides.Scrollbar,scrollable:this.scrollable,container:n?this.virtualListContainer:void 0,content:n?this.virtualListContent:void 0,onScroll:n?void 0:this.doScroll},{default:()=>n?r(En,{ref:"virtualListRef",class:`${o}-virtual-list`,items:this.flattenedNodes,itemSize:this.itemSize,showScrollbar:!1,paddingTop:this.padding.top,paddingBottom:this.padding.bottom,onResize:this.handleVirtualListResize,onScroll:this.handleVirtualListScroll,itemResizable:!0},{default:({item:v})=>v.isGroup?r(wt,{key:v.key,clsPrefix:o,tmNode:v}):v.ignored?null:r(mt,{clsPrefix:o,key:v.key,tmNode:v})}):r("div",{class:`${o}-base-select-menu-option-wrapper`,style:{paddingTop:this.padding.top,paddingBottom:this.padding.bottom}},this.flattenedNodes.map(v=>v.isGroup?r(wt,{key:v.key,clsPrefix:o,tmNode:v}):r(mt,{clsPrefix:o,key:v.key,tmNode:v})))}),ct(e.action,v=>v&&[r("div",{class:`${o}-base-select-menu__action`,"data-action":!0,key:"action"},v),r(Ln,{onFocus:this.onTabOut,key:"focus-detector"})]))}}),Un=re([_("base-selection",`
 --n-padding-single: var(--n-padding-single-top) var(--n-padding-single-right) var(--n-padding-single-bottom) var(--n-padding-single-left);
 --n-padding-multiple: var(--n-padding-multiple-top) var(--n-padding-multiple-right) var(--n-padding-multiple-bottom) var(--n-padding-multiple-left);
 position: relative;
 z-index: auto;
 box-shadow: none;
 width: 100%;
 max-width: 100%;
 display: inline-block;
 vertical-align: bottom;
 border-radius: var(--n-border-radius);
 min-height: var(--n-height);
 line-height: 1.5;
 font-size: var(--n-font-size);
 `,[_("base-loading",`
 color: var(--n-loading-color);
 `),_("base-selection-tags","min-height: var(--n-height);"),E("border, state-border",`
 position: absolute;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 pointer-events: none;
 border: var(--n-border);
 border-radius: inherit;
 transition:
 box-shadow .3s var(--n-bezier),
 border-color .3s var(--n-bezier);
 `),E("state-border",`
 z-index: 1;
 border-color: #0000;
 `),_("base-suffix",`
 cursor: pointer;
 position: absolute;
 top: 50%;
 transform: translateY(-50%);
 right: 10px;
 `,[E("arrow",`
 font-size: var(--n-arrow-size);
 color: var(--n-arrow-color);
 transition: color .3s var(--n-bezier);
 `)]),_("base-selection-overlay",`
 display: flex;
 align-items: center;
 white-space: nowrap;
 pointer-events: none;
 position: absolute;
 top: 0;
 right: 0;
 bottom: 0;
 left: 0;
 padding: var(--n-padding-single);
 transition: color .3s var(--n-bezier);
 `,[E("wrapper",`
 flex-basis: 0;
 flex-grow: 1;
 overflow: hidden;
 text-overflow: ellipsis;
 `)]),_("base-selection-placeholder",`
 color: var(--n-placeholder-color);
 `,[E("inner",`
 max-width: 100%;
 overflow: hidden;
 `)]),_("base-selection-tags",`
 cursor: pointer;
 outline: none;
 box-sizing: border-box;
 position: relative;
 z-index: auto;
 display: flex;
 padding: var(--n-padding-multiple);
 flex-wrap: wrap;
 align-items: center;
 width: 100%;
 vertical-align: bottom;
 background-color: var(--n-color);
 border-radius: inherit;
 transition:
 color .3s var(--n-bezier),
 box-shadow .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 `),_("base-selection-label",`
 height: var(--n-height);
 display: inline-flex;
 width: 100%;
 vertical-align: bottom;
 cursor: pointer;
 outline: none;
 z-index: auto;
 box-sizing: border-box;
 position: relative;
 transition:
 color .3s var(--n-bezier),
 box-shadow .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 border-radius: inherit;
 background-color: var(--n-color);
 align-items: center;
 `,[_("base-selection-input",`
 font-size: inherit;
 line-height: inherit;
 outline: none;
 cursor: pointer;
 box-sizing: border-box;
 border:none;
 width: 100%;
 padding: var(--n-padding-single);
 background-color: #0000;
 color: var(--n-text-color);
 transition: color .3s var(--n-bezier);
 caret-color: var(--n-caret-color);
 `,[E("content",`
 text-overflow: ellipsis;
 overflow: hidden;
 white-space: nowrap; 
 `)]),E("render-label",`
 color: var(--n-text-color);
 `)]),lt("disabled",[re("&:hover",[E("state-border",`
 box-shadow: var(--n-box-shadow-hover);
 border: var(--n-border-hover);
 `)]),le("focus",[E("state-border",`
 box-shadow: var(--n-box-shadow-focus);
 border: var(--n-border-focus);
 `)]),le("active",[E("state-border",`
 box-shadow: var(--n-box-shadow-active);
 border: var(--n-border-active);
 `),_("base-selection-label","background-color: var(--n-color-active);"),_("base-selection-tags","background-color: var(--n-color-active);")])]),le("disabled","cursor: not-allowed;",[E("arrow",`
 color: var(--n-arrow-color-disabled);
 `),_("base-selection-label",`
 cursor: not-allowed;
 background-color: var(--n-color-disabled);
 `,[_("base-selection-input",`
 cursor: not-allowed;
 color: var(--n-text-color-disabled);
 `),E("render-label",`
 color: var(--n-text-color-disabled);
 `)]),_("base-selection-tags",`
 cursor: not-allowed;
 background-color: var(--n-color-disabled);
 `),_("base-selection-placeholder",`
 cursor: not-allowed;
 color: var(--n-placeholder-color-disabled);
 `)]),_("base-selection-input-tag",`
 height: calc(var(--n-height) - 6px);
 line-height: calc(var(--n-height) - 6px);
 outline: none;
 display: none;
 position: relative;
 margin-bottom: 3px;
 max-width: 100%;
 vertical-align: bottom;
 `,[E("input",`
 font-size: inherit;
 font-family: inherit;
 min-width: 1px;
 padding: 0;
 background-color: #0000;
 outline: none;
 border: none;
 max-width: 100%;
 overflow: hidden;
 width: 1em;
 line-height: inherit;
 cursor: pointer;
 color: var(--n-text-color);
 caret-color: var(--n-caret-color);
 `),E("mirror",`
 position: absolute;
 left: 0;
 top: 0;
 white-space: pre;
 visibility: hidden;
 user-select: none;
 -webkit-user-select: none;
 opacity: 0;
 `)]),["warning","error"].map(e=>le(`${e}-status`,[E("state-border",`border: var(--n-border-${e});`),lt("disabled",[re("&:hover",[E("state-border",`
 box-shadow: var(--n-box-shadow-hover-${e});
 border: var(--n-border-hover-${e});
 `)]),le("active",[E("state-border",`
 box-shadow: var(--n-box-shadow-active-${e});
 border: var(--n-border-active-${e});
 `),_("base-selection-label",`background-color: var(--n-color-active-${e});`),_("base-selection-tags",`background-color: var(--n-color-active-${e});`)]),le("focus",[E("state-border",`
 box-shadow: var(--n-box-shadow-focus-${e});
 border: var(--n-border-focus-${e});
 `)])])]))]),_("base-selection-popover",`
 margin-bottom: -3px;
 display: flex;
 flex-wrap: wrap;
 margin-right: -8px;
 `),_("base-selection-tag-wrapper",`
 max-width: 100%;
 display: inline-flex;
 padding: 0 7px 3px 0;
 `,[re("&:last-child","padding-right: 0;"),_("tag",`
 font-size: 14px;
 max-width: 100%;
 `,[E("content",`
 line-height: 1.25;
 text-overflow: ellipsis;
 overflow: hidden;
 `)])])]),qn=de({name:"InternalSelection",props:Object.assign(Object.assign({},be.props),{clsPrefix:{type:String,required:!0},bordered:{type:Boolean,default:void 0},active:Boolean,pattern:{type:String,default:""},placeholder:String,selectedOption:{type:Object,default:null},selectedOptions:{type:Array,default:null},labelField:{type:String,default:"label"},valueField:{type:String,default:"value"},multiple:Boolean,filterable:Boolean,clearable:Boolean,disabled:Boolean,size:{type:String,default:"medium"},loading:Boolean,autofocus:Boolean,showArrow:{type:Boolean,default:!0},inputProps:Object,focused:Boolean,renderTag:Function,onKeydown:Function,onClick:Function,onBlur:Function,onFocus:Function,onDeleteOption:Function,maxTagCount:[String,Number],ellipsisTagPopoverProps:Object,onClear:Function,onPatternInput:Function,onPatternFocus:Function,onPatternBlur:Function,renderLabel:Function,status:String,inlineThemeDisabled:Boolean,ignoreComposition:{type:Boolean,default:!0},onResize:Function}),setup(e){const{mergedClsPrefixRef:n,mergedRtlRef:o}=Ue(e),d=Rt("InternalSelection",o,n),a=P(null),u=P(null),v=P(null),s=P(null),T=P(null),C=P(null),p=P(null),S=P(null),x=P(null),F=P(null),y=P(!1),$=P(!1),K=P(!1),B=be("InternalSelection","-internal-selection",Un,cn,e,Q(e,"clsPrefix")),O=k(()=>e.clearable&&!e.disabled&&(K.value||e.active)),L=k(()=>e.selectedOption?e.renderTag?e.renderTag({option:e.selectedOption,handleClose:()=>{}}):e.renderLabel?e.renderLabel(e.selectedOption,!0):Re(e.selectedOption[e.labelField],e.selectedOption,!0):e.placeholder),W=k(()=>{const i=e.selectedOption;if(i)return i[e.labelField]}),A=k(()=>e.multiple?!!(Array.isArray(e.selectedOptions)&&e.selectedOptions.length):e.selectedOption!==null);function te(){var i;const{value:g}=a;if(g){const{value:q}=u;q&&(q.style.width=`${g.offsetWidth}px`,e.maxTagCount!=="responsive"&&((i=x.value)===null||i===void 0||i.sync({showAllItemsBeforeCalculate:!1})))}}function ee(){const{value:i}=F;i&&(i.style.display="none")}function ue(){const{value:i}=F;i&&(i.style.display="inline-block")}Te(Q(e,"active"),i=>{i||ee()}),Te(Q(e,"pattern"),()=>{e.multiple&&Tt(te)});function ie(i){const{onFocus:g}=e;g&&g(i)}function ne(i){const{onBlur:g}=e;g&&g(i)}function h(i){const{onDeleteOption:g}=e;g&&g(i)}function b(i){const{onClear:g}=e;g&&g(i)}function m(i){const{onPatternInput:g}=e;g&&g(i)}function N(i){var g;(!i.relatedTarget||!(!((g=v.value)===null||g===void 0)&&g.contains(i.relatedTarget)))&&ie(i)}function D(i){var g;!((g=v.value)===null||g===void 0)&&g.contains(i.relatedTarget)||ne(i)}function V(i){b(i)}function H(){K.value=!0}function j(){K.value=!1}function X(i){!e.active||!e.filterable||i.target!==u.value&&i.preventDefault()}function Y(i){h(i)}const Z=P(!1);function l(i){if(i.key==="Backspace"&&!Z.value&&!e.pattern.length){const{selectedOptions:g}=e;g?.length&&Y(g[g.length-1])}}let f=null;function U(i){const{value:g}=a;if(g){const q=i.target.value;g.textContent=q,te()}e.ignoreComposition&&Z.value?f=i:m(i)}function ce(){Z.value=!0}function ye(){Z.value=!1,e.ignoreComposition&&m(f),f=null}function xe(i){var g;$.value=!0,(g=e.onPatternFocus)===null||g===void 0||g.call(e,i)}function fe(i){var g;$.value=!1,(g=e.onPatternBlur)===null||g===void 0||g.call(e,i)}function oe(){var i,g;if(e.filterable)$.value=!1,(i=C.value)===null||i===void 0||i.blur(),(g=u.value)===null||g===void 0||g.blur();else if(e.multiple){const{value:q}=s;q?.blur()}else{const{value:q}=T;q?.blur()}}function Ce(){var i,g,q;e.filterable?($.value=!1,(i=C.value)===null||i===void 0||i.focus()):e.multiple?(g=s.value)===null||g===void 0||g.focus():(q=T.value)===null||q===void 0||q.focus()}function ve(){const{value:i}=u;i&&(ue(),i.focus())}function Fe(){const{value:i}=u;i&&i.blur()}function Oe(i){const{value:g}=p;g&&g.setTextContent(`+${i}`)}function ze(){const{value:i}=S;return i}function Me(){return u.value}let pe=null;function me(){pe!==null&&window.clearTimeout(pe)}function Pe(){e.active||(me(),pe=window.setTimeout(()=>{A.value&&(y.value=!0)},100))}function ke(){me()}function Ie(i){i||(me(),y.value=!1)}Te(A,i=>{i||(y.value=!1)}),Ke(()=>{fn(()=>{const i=C.value;i&&(e.disabled?i.removeAttribute("tabindex"):i.tabIndex=$.value?-1:0)})}),Ot(v,e.onResize);const{inlineThemeDisabled:Se}=e,we=k(()=>{const{size:i}=e,{common:{cubicBezierEaseInOut:g},self:{borderRadius:q,color:Ge,placeholderColor:Ye,textColor:$e,paddingSingle:Ee,paddingMultiple:Ne,caretColor:Ze,colorDisabled:Xe,textColorDisabled:Ae,placeholderColorDisabled:ge,colorActive:t,boxShadowFocus:c,boxShadowActive:w,boxShadowHover:I,border:z,borderFocus:R,borderHover:M,borderActive:G,arrowColor:ae,arrowColorDisabled:Mt,loadingColor:Pt,colorActiveWarning:kt,boxShadowFocusWarning:It,boxShadowActiveWarning:_t,boxShadowHoverWarning:Bt,borderWarning:$t,borderFocusWarning:Et,borderHoverWarning:Nt,borderActiveWarning:At,colorActiveError:Lt,boxShadowFocusError:Dt,boxShadowActiveError:Vt,boxShadowHoverError:Ht,borderError:jt,borderFocusError:Wt,borderHoverError:Kt,borderActiveError:Ut,clearColor:qt,clearColorHover:Gt,clearColorPressed:Yt,clearSize:Zt,arrowSize:Xt,[he("height",i)]:Jt,[he("fontSize",i)]:Qt}}=B.value,Le=_e(Ee),De=_e(Ne);return{"--n-bezier":g,"--n-border":z,"--n-border-active":G,"--n-border-focus":R,"--n-border-hover":M,"--n-border-radius":q,"--n-box-shadow-active":w,"--n-box-shadow-focus":c,"--n-box-shadow-hover":I,"--n-caret-color":Ze,"--n-color":Ge,"--n-color-active":t,"--n-color-disabled":Xe,"--n-font-size":Qt,"--n-height":Jt,"--n-padding-single-top":Le.top,"--n-padding-multiple-top":De.top,"--n-padding-single-right":Le.right,"--n-padding-multiple-right":De.right,"--n-padding-single-left":Le.left,"--n-padding-multiple-left":De.left,"--n-padding-single-bottom":Le.bottom,"--n-padding-multiple-bottom":De.bottom,"--n-placeholder-color":Ye,"--n-placeholder-color-disabled":ge,"--n-text-color":$e,"--n-text-color-disabled":Ae,"--n-arrow-color":ae,"--n-arrow-color-disabled":Mt,"--n-loading-color":Pt,"--n-color-active-warning":kt,"--n-box-shadow-focus-warning":It,"--n-box-shadow-active-warning":_t,"--n-box-shadow-hover-warning":Bt,"--n-border-warning":$t,"--n-border-focus-warning":Et,"--n-border-hover-warning":Nt,"--n-border-active-warning":At,"--n-color-active-error":Lt,"--n-box-shadow-focus-error":Dt,"--n-box-shadow-active-error":Vt,"--n-box-shadow-hover-error":Ht,"--n-border-error":jt,"--n-border-focus-error":Wt,"--n-border-hover-error":Kt,"--n-border-active-error":Ut,"--n-clear-size":Zt,"--n-clear-color":qt,"--n-clear-color-hover":Gt,"--n-clear-color-pressed":Yt,"--n-arrow-size":Xt}}),J=Se?qe("internal-selection",k(()=>e.size[0]),we,e):void 0;return{mergedTheme:B,mergedClearable:O,mergedClsPrefix:n,rtlEnabled:d,patternInputFocused:$,filterablePlaceholder:L,label:W,selected:A,showTagsPanel:y,isComposing:Z,counterRef:p,counterWrapperRef:S,patternInputMirrorRef:a,patternInputRef:u,selfRef:v,multipleElRef:s,singleElRef:T,patternInputWrapperRef:C,overflowRef:x,inputTagElRef:F,handleMouseDown:X,handleFocusin:N,handleClear:V,handleMouseEnter:H,handleMouseLeave:j,handleDeleteOption:Y,handlePatternKeyDown:l,handlePatternInputInput:U,handlePatternInputBlur:fe,handlePatternInputFocus:xe,handleMouseEnterCounter:Pe,handleMouseLeaveCounter:ke,handleFocusout:D,handleCompositionEnd:ye,handleCompositionStart:ce,onPopoverUpdateShow:Ie,focus:Ce,focusInput:ve,blur:oe,blurInput:Fe,updateCounter:Oe,getCounter:ze,getTail:Me,renderLabel:e.renderLabel,cssVars:Se?void 0:we,themeClass:J?.themeClass,onRender:J?.onRender}},render(){const{status:e,multiple:n,size:o,disabled:d,filterable:a,maxTagCount:u,bordered:v,clsPrefix:s,ellipsisTagPopoverProps:T,onRender:C,renderTag:p,renderLabel:S}=this;C?.();const x=u==="responsive",F=typeof u=="number",y=x||F,$=r(hn,null,{default:()=>r(Tn,{clsPrefix:s,loading:this.loading,showArrow:this.showArrow,showClear:this.mergedClearable&&this.selected,onClear:this.handleClear},{default:()=>{var B,O;return(O=(B=this.$slots).arrow)===null||O===void 0?void 0:O.call(B)}})});let K;if(n){const{labelField:B}=this,O=m=>r("div",{class:`${s}-base-selection-tag-wrapper`,key:m.value},p?p({option:m,handleClose:()=>{this.handleDeleteOption(m)}}):r(Je,{size:o,closable:!m.disabled,disabled:d,onClose:()=>{this.handleDeleteOption(m)},internalCloseIsButtonTag:!1,internalCloseFocusable:!1},{default:()=>S?S(m,!0):Re(m[B],m,!0)})),L=()=>(F?this.selectedOptions.slice(0,u):this.selectedOptions).map(O),W=a?r("div",{class:`${s}-base-selection-input-tag`,ref:"inputTagElRef",key:"__input-tag__"},r("input",Object.assign({},this.inputProps,{ref:"patternInputRef",tabindex:-1,disabled:d,value:this.pattern,autofocus:this.autofocus,class:`${s}-base-selection-input-tag__input`,onBlur:this.handlePatternInputBlur,onFocus:this.handlePatternInputFocus,onKeydown:this.handlePatternKeyDown,onInput:this.handlePatternInputInput,onCompositionstart:this.handleCompositionStart,onCompositionend:this.handleCompositionEnd})),r("span",{ref:"patternInputMirrorRef",class:`${s}-base-selection-input-tag__mirror`},this.pattern)):null,A=x?()=>r("div",{class:`${s}-base-selection-tag-wrapper`,ref:"counterWrapperRef"},r(Je,{size:o,ref:"counterRef",onMouseenter:this.handleMouseEnterCounter,onMouseleave:this.handleMouseLeaveCounter,disabled:d})):void 0;let te;if(F){const m=this.selectedOptions.length-u;m>0&&(te=r("div",{class:`${s}-base-selection-tag-wrapper`,key:"__counter__"},r(Je,{size:o,ref:"counterRef",onMouseenter:this.handleMouseEnterCounter,disabled:d},{default:()=>`+${m}`})))}const ee=x?a?r(vt,{ref:"overflowRef",updateCounter:this.updateCounter,getCounter:this.getCounter,getTail:this.getTail,style:{width:"100%",display:"flex",overflow:"hidden"}},{default:L,counter:A,tail:()=>W}):r(vt,{ref:"overflowRef",updateCounter:this.updateCounter,getCounter:this.getCounter,style:{width:"100%",display:"flex",overflow:"hidden"}},{default:L,counter:A}):F&&te?L().concat(te):L(),ue=y?()=>r("div",{class:`${s}-base-selection-popover`},x?L():this.selectedOptions.map(O)):void 0,ie=y?Object.assign({show:this.showTagsPanel,trigger:"hover",overlap:!0,placement:"top",width:"trigger",onUpdateShow:this.onPopoverUpdateShow,theme:this.mergedTheme.peers.Popover,themeOverrides:this.mergedTheme.peerOverrides.Popover},T):null,h=(this.selected?!1:this.active?!this.pattern&&!this.isComposing:!0)?r("div",{class:`${s}-base-selection-placeholder ${s}-base-selection-overlay`},r("div",{class:`${s}-base-selection-placeholder__inner`},this.placeholder)):null,b=a?r("div",{ref:"patternInputWrapperRef",class:`${s}-base-selection-tags`},ee,x?null:W,$):r("div",{ref:"multipleElRef",class:`${s}-base-selection-tags`,tabindex:d?void 0:0},ee,$);K=r(vn,null,y?r(zn,Object.assign({},ie,{scrollable:!0,style:"max-height: calc(var(--v-target-height) * 6.6);"}),{trigger:()=>b,default:ue}):b,h)}else if(a){const B=this.pattern||this.isComposing,O=this.active?!B:!this.selected,L=this.active?!1:this.selected;K=r("div",{ref:"patternInputWrapperRef",class:`${s}-base-selection-label`,title:this.patternInputFocused?void 0:gt(this.label)},r("input",Object.assign({},this.inputProps,{ref:"patternInputRef",class:`${s}-base-selection-input`,value:this.active?this.pattern:"",placeholder:"",readonly:d,disabled:d,tabindex:-1,autofocus:this.autofocus,onFocus:this.handlePatternInputFocus,onBlur:this.handlePatternInputBlur,onInput:this.handlePatternInputInput,onCompositionstart:this.handleCompositionStart,onCompositionend:this.handleCompositionEnd})),L?r("div",{class:`${s}-base-selection-label__render-label ${s}-base-selection-overlay`,key:"input"},r("div",{class:`${s}-base-selection-overlay__wrapper`},p?p({option:this.selectedOption,handleClose:()=>{}}):S?S(this.selectedOption,!0):Re(this.label,this.selectedOption,!0))):null,O?r("div",{class:`${s}-base-selection-placeholder ${s}-base-selection-overlay`,key:"placeholder"},r("div",{class:`${s}-base-selection-overlay__wrapper`},this.filterablePlaceholder)):null,$)}else K=r("div",{ref:"singleElRef",class:`${s}-base-selection-label`,tabindex:this.disabled?void 0:0},this.label!==void 0?r("div",{class:`${s}-base-selection-input`,title:gt(this.label),key:"input"},r("div",{class:`${s}-base-selection-input__content`},p?p({option:this.selectedOption,handleClose:()=>{}}):S?S(this.selectedOption,!0):Re(this.label,this.selectedOption,!0))):r("div",{class:`${s}-base-selection-placeholder ${s}-base-selection-overlay`,key:"placeholder"},r("div",{class:`${s}-base-selection-placeholder__inner`},this.placeholder)),$);return r("div",{ref:"selfRef",class:[`${s}-base-selection`,this.rtlEnabled&&`${s}-base-selection--rtl`,this.themeClass,e&&`${s}-base-selection--${e}-status`,{[`${s}-base-selection--active`]:this.active,[`${s}-base-selection--selected`]:this.selected||this.active&&this.pattern,[`${s}-base-selection--disabled`]:this.disabled,[`${s}-base-selection--multiple`]:this.multiple,[`${s}-base-selection--focus`]:this.focused}],style:this.cssVars,onClick:this.onClick,onMouseenter:this.handleMouseEnter,onMouseleave:this.handleMouseLeave,onKeydown:this.onKeydown,onFocusin:this.handleFocusin,onFocusout:this.handleFocusout,onMousedown:this.handleMouseDown},K,v?r("div",{class:`${s}-base-selection__border`}):null,v?r("div",{class:`${s}-base-selection__state-border`}):null)}});function We(e){return e.type==="group"}function zt(e){return e.type==="ignored"}function nt(e,n){try{return!!(1+n.toString().toLowerCase().indexOf(e.trim().toLowerCase()))}catch{return!1}}function Gn(e,n){return{getIsGroup:We,getIgnored:zt,getKey(d){return We(d)?d.name||d.key||"key-required":d[e]},getChildren(d){return d[n]}}}function Yn(e,n,o,d){if(!n)return e;function a(u){if(!Array.isArray(u))return[];const v=[];for(const s of u)if(We(s)){const T=a(s[d]);T.length&&v.push(Object.assign({},s,{[d]:T}))}else{if(zt(s))continue;n(o,s)&&v.push(s)}return v}return a(e)}function Zn(e,n,o){const d=new Map;return e.forEach(a=>{We(a)?a[o].forEach(u=>{d.set(u[n],u)}):d.set(a[n],a)}),d}const Xn=re([_("select",`
 z-index: auto;
 outline: none;
 width: 100%;
 position: relative;
 `),_("select-menu",`
 margin: 4px 0;
 box-shadow: var(--n-menu-box-shadow);
 `,[St({originalTransition:"background-color .3s var(--n-bezier), box-shadow .3s var(--n-bezier)"})])]),Jn=Object.assign(Object.assign({},be.props),{to:it.propTo,bordered:{type:Boolean,default:void 0},clearable:Boolean,clearFilterAfterSelect:{type:Boolean,default:!0},options:{type:Array,default:()=>[]},defaultValue:{type:[String,Number,Array],default:null},keyboard:{type:Boolean,default:!0},value:[String,Number,Array],placeholder:String,menuProps:Object,multiple:Boolean,size:String,filterable:Boolean,disabled:{type:Boolean,default:void 0},remote:Boolean,loading:Boolean,filter:Function,placement:{type:String,default:"bottom-start"},widthMode:{type:String,default:"trigger"},tag:Boolean,onCreate:Function,fallbackOption:{type:[Function,Boolean],default:void 0},show:{type:Boolean,default:void 0},showArrow:{type:Boolean,default:!0},maxTagCount:[Number,String],ellipsisTagPopoverProps:Object,consistentMenuWidth:{type:Boolean,default:!0},virtualScroll:{type:Boolean,default:!0},labelField:{type:String,default:"label"},valueField:{type:String,default:"value"},childrenField:{type:String,default:"children"},renderLabel:Function,renderOption:Function,renderTag:Function,"onUpdate:value":[Function,Array],inputProps:Object,nodeProps:Function,ignoreComposition:{type:Boolean,default:!0},showOnFocus:Boolean,onUpdateValue:[Function,Array],onBlur:[Function,Array],onClear:[Function,Array],onFocus:[Function,Array],onScroll:[Function,Array],onSearch:[Function,Array],onUpdateShow:[Function,Array],"onUpdate:show":[Function,Array],displayDirective:{type:String,default:"show"},resetMenuOnOptionsChange:{type:Boolean,default:!0},status:String,showCheckmark:{type:Boolean,default:!0},onChange:[Function,Array],items:Array}),ao=de({name:"Select",props:Jn,setup(e){const{mergedClsPrefixRef:n,mergedBorderedRef:o,namespaceRef:d,inlineThemeDisabled:a}=Ue(e),u=be("Select","-select",Xn,gn,e,n),v=P(e.defaultValue),s=Q(e,"value"),T=ht(s,v),C=P(!1),p=P(""),S=Cn(e,["items","options"]),x=P([]),F=P([]),y=k(()=>F.value.concat(x.value).concat(S.value)),$=k(()=>{const{filter:t}=e;if(t)return t;const{labelField:c,valueField:w}=e;return(I,z)=>{if(!z)return!1;const R=z[c];if(typeof R=="string")return nt(I,R);const M=z[w];return typeof M=="string"?nt(I,M):typeof M=="number"?nt(I,String(M)):!1}}),K=k(()=>{if(e.remote)return S.value;{const{value:t}=y,{value:c}=p;return!c.length||!e.filterable?t:Yn(t,$.value,c,e.childrenField)}}),B=k(()=>{const{valueField:t,childrenField:c}=e,w=Gn(t,c);return Rn(K.value,w)}),O=k(()=>Zn(y.value,e.valueField,e.childrenField)),L=P(!1),W=ht(Q(e,"show"),L),A=P(null),te=P(null),ee=P(null),{localeRef:ue}=Ft("Select"),ie=k(()=>{var t;return(t=e.placeholder)!==null&&t!==void 0?t:ue.value.placeholder}),ne=[],h=P(new Map),b=k(()=>{const{fallbackOption:t}=e;if(t===void 0){const{labelField:c,valueField:w}=e;return I=>({[c]:String(I),[w]:I})}return t===!1?!1:c=>Object.assign(t(c),{value:c})});function m(t){const c=e.remote,{value:w}=h,{value:I}=O,{value:z}=b,R=[];return t.forEach(M=>{if(I.has(M))R.push(I.get(M));else if(c&&w.has(M))R.push(w.get(M));else if(z){const G=z(M);G&&R.push(G)}}),R}const N=k(()=>{if(e.multiple){const{value:t}=T;return Array.isArray(t)?m(t):[]}return null}),D=k(()=>{const{value:t}=T;return!e.multiple&&!Array.isArray(t)?t===null?null:m([t])[0]||null:null}),V=bn(e),{mergedSizeRef:H,mergedDisabledRef:j,mergedStatusRef:X}=V;function Y(t,c){const{onChange:w,"onUpdate:value":I,onUpdateValue:z}=e,{nTriggerFormChange:R,nTriggerFormInput:M}=V;w&&se(w,t,c),z&&se(z,t,c),I&&se(I,t,c),v.value=t,R(),M()}function Z(t){const{onBlur:c}=e,{nTriggerFormBlur:w}=V;c&&se(c,t),w()}function l(){const{onClear:t}=e;t&&se(t)}function f(t){const{onFocus:c,showOnFocus:w}=e,{nTriggerFormFocus:I}=V;c&&se(c,t),I(),w&&fe()}function U(t){const{onSearch:c}=e;c&&se(c,t)}function ce(t){const{onScroll:c}=e;c&&se(c,t)}function ye(){var t;const{remote:c,multiple:w}=e;if(c){const{value:I}=h;if(w){const{valueField:z}=e;(t=N.value)===null||t===void 0||t.forEach(R=>{I.set(R[z],R)})}else{const z=D.value;z&&I.set(z[e.valueField],z)}}}function xe(t){const{onUpdateShow:c,"onUpdate:show":w}=e;c&&se(c,t),w&&se(w,t),L.value=t}function fe(){j.value||(xe(!0),L.value=!0,e.filterable&&Ne())}function oe(){xe(!1)}function Ce(){p.value="",F.value=ne}const ve=P(!1);function Fe(){e.filterable&&(ve.value=!0)}function Oe(){e.filterable&&(ve.value=!1,W.value||Ce())}function ze(){j.value||(W.value?e.filterable?Ne():oe():fe())}function Me(t){var c,w;!((w=(c=ee.value)===null||c===void 0?void 0:c.selfRef)===null||w===void 0)&&w.contains(t.relatedTarget)||(C.value=!1,Z(t),oe())}function pe(t){f(t),C.value=!0}function me(){C.value=!0}function Pe(t){var c;!((c=A.value)===null||c===void 0)&&c.$el.contains(t.relatedTarget)||(C.value=!1,Z(t),oe())}function ke(){var t;(t=A.value)===null||t===void 0||t.focus(),oe()}function Ie(t){var c;W.value&&(!((c=A.value)===null||c===void 0)&&c.$el.contains(yn(t))||oe())}function Se(t){if(!Array.isArray(t))return[];if(b.value)return Array.from(t);{const{remote:c}=e,{value:w}=O;if(c){const{value:I}=h;return t.filter(z=>w.has(z)||I.has(z))}else return t.filter(I=>w.has(I))}}function we(t){J(t.rawNode)}function J(t){if(j.value)return;const{tag:c,remote:w,clearFilterAfterSelect:I,valueField:z}=e;if(c&&!w){const{value:R}=F,M=R[0]||null;if(M){const G=x.value;G.length?G.push(M):x.value=[M],F.value=ne}}if(w&&h.value.set(t[z],t),e.multiple){const R=Se(T.value),M=R.findIndex(G=>G===t[z]);if(~M){if(R.splice(M,1),c&&!w){const G=i(t[z]);~G&&(x.value.splice(G,1),I&&(p.value=""))}}else R.push(t[z]),I&&(p.value="");Y(R,m(R))}else{if(c&&!w){const R=i(t[z]);~R?x.value=[x.value[R]]:x.value=ne}Ee(),oe(),Y(t[z],t)}}function i(t){return x.value.findIndex(w=>w[e.valueField]===t)}function g(t){W.value||fe();const{value:c}=t.target;p.value=c;const{tag:w,remote:I}=e;if(U(c),w&&!I){if(!c){F.value=ne;return}const{onCreate:z}=e,R=z?z(c):{[e.labelField]:c,[e.valueField]:c},{valueField:M,labelField:G}=e;S.value.some(ae=>ae[M]===R[M]||ae[G]===R[G])||x.value.some(ae=>ae[M]===R[M]||ae[G]===R[G])?F.value=ne:F.value=[R]}}function q(t){t.stopPropagation();const{multiple:c}=e;!c&&e.filterable&&oe(),l(),c?Y([],[]):Y(null,null)}function Ge(t){!Be(t,"action")&&!Be(t,"empty")&&!Be(t,"header")&&t.preventDefault()}function Ye(t){ce(t)}function $e(t){var c,w,I,z,R;if(!e.keyboard){t.preventDefault();return}switch(t.key){case" ":if(e.filterable)break;t.preventDefault();case"Enter":if(!(!((c=A.value)===null||c===void 0)&&c.isComposing)){if(W.value){const M=(w=ee.value)===null||w===void 0?void 0:w.getPendingTmNode();M?we(M):e.filterable||(oe(),Ee())}else if(fe(),e.tag&&ve.value){const M=F.value[0];if(M){const G=M[e.valueField],{value:ae}=T;e.multiple&&Array.isArray(ae)&&ae.includes(G)||J(M)}}}t.preventDefault();break;case"ArrowUp":if(t.preventDefault(),e.loading)return;W.value&&((I=ee.value)===null||I===void 0||I.prev());break;case"ArrowDown":if(t.preventDefault(),e.loading)return;W.value?(z=ee.value)===null||z===void 0||z.next():fe();break;case"Escape":W.value&&(xn(t),oe()),(R=A.value)===null||R===void 0||R.focus();break}}function Ee(){var t;(t=A.value)===null||t===void 0||t.focus()}function Ne(){var t;(t=A.value)===null||t===void 0||t.focusInput()}function Ze(){var t;W.value&&((t=te.value)===null||t===void 0||t.syncPosition())}ye(),Te(Q(e,"options"),ye);const Xe={focus:()=>{var t;(t=A.value)===null||t===void 0||t.focus()},focusInput:()=>{var t;(t=A.value)===null||t===void 0||t.focusInput()},blur:()=>{var t;(t=A.value)===null||t===void 0||t.blur()},blurInput:()=>{var t;(t=A.value)===null||t===void 0||t.blurInput()}},Ae=k(()=>{const{self:{menuBoxShadow:t}}=u.value;return{"--n-menu-box-shadow":t}}),ge=a?qe("select",void 0,Ae,e):void 0;return Object.assign(Object.assign({},Xe),{mergedStatus:X,mergedClsPrefix:n,mergedBordered:o,namespace:d,treeMate:B,isMounted:pn(),triggerRef:A,menuRef:ee,pattern:p,uncontrolledShow:L,mergedShow:W,adjustedTo:it(e),uncontrolledValue:v,mergedValue:T,followerRef:te,localizedPlaceholder:ie,selectedOption:D,selectedOptions:N,mergedSize:H,mergedDisabled:j,focused:C,activeWithoutMenuOpen:ve,inlineThemeDisabled:a,onTriggerInputFocus:Fe,onTriggerInputBlur:Oe,handleTriggerOrMenuResize:Ze,handleMenuFocus:me,handleMenuBlur:Pe,handleMenuTabOut:ke,handleTriggerClick:ze,handleToggle:we,handleDeleteOption:J,handlePatternInput:g,handleClear:q,handleTriggerBlur:Me,handleTriggerFocus:pe,handleKeydown:$e,handleMenuAfterLeave:Ce,handleMenuClickOutside:Ie,handleMenuScroll:Ye,handleMenuKeydown:$e,handleMenuMousedown:Ge,mergedTheme:u,cssVars:a?void 0:Ae,themeClass:ge?.themeClass,onRender:ge?.onRender})},render(){return r("div",{class:`${this.mergedClsPrefix}-select`},r(Mn,null,{default:()=>[r(Pn,null,{default:()=>r(qn,{ref:"triggerRef",inlineThemeDisabled:this.inlineThemeDisabled,status:this.mergedStatus,inputProps:this.inputProps,clsPrefix:this.mergedClsPrefix,showArrow:this.showArrow,maxTagCount:this.maxTagCount,ellipsisTagPopoverProps:this.ellipsisTagPopoverProps,bordered:this.mergedBordered,active:this.activeWithoutMenuOpen||this.mergedShow,pattern:this.pattern,placeholder:this.localizedPlaceholder,selectedOption:this.selectedOption,selectedOptions:this.selectedOptions,multiple:this.multiple,renderTag:this.renderTag,renderLabel:this.renderLabel,filterable:this.filterable,clearable:this.clearable,disabled:this.mergedDisabled,size:this.mergedSize,theme:this.mergedTheme.peers.InternalSelection,labelField:this.labelField,valueField:this.valueField,themeOverrides:this.mergedTheme.peerOverrides.InternalSelection,loading:this.loading,focused:this.focused,onClick:this.handleTriggerClick,onDeleteOption:this.handleDeleteOption,onPatternInput:this.handlePatternInput,onClear:this.handleClear,onBlur:this.handleTriggerBlur,onFocus:this.handleTriggerFocus,onKeydown:this.handleKeydown,onPatternBlur:this.onTriggerInputBlur,onPatternFocus:this.onTriggerInputFocus,onResize:this.handleTriggerOrMenuResize,ignoreComposition:this.ignoreComposition},{arrow:()=>{var e,n;return[(n=(e=this.$slots).arrow)===null||n===void 0?void 0:n.call(e)]}})}),r(kn,{ref:"followerRef",show:this.mergedShow,to:this.adjustedTo,teleportDisabled:this.adjustedTo===it.tdkey,containerClass:this.namespace,width:this.consistentMenuWidth?"target":void 0,minWidth:"target",placement:this.placement},{default:()=>r(Ct,{name:"fade-in-scale-up-transition",appear:this.isMounted,onAfterLeave:this.handleMenuAfterLeave},{default:()=>{var e,n,o;return this.mergedShow||this.displayDirective==="show"?((e=this.onRender)===null||e===void 0||e.call(this),mn(r(Kn,Object.assign({},this.menuProps,{ref:"menuRef",onResize:this.handleTriggerOrMenuResize,inlineThemeDisabled:this.inlineThemeDisabled,virtualScroll:this.consistentMenuWidth&&this.virtualScroll,class:[`${this.mergedClsPrefix}-select-menu`,this.themeClass,(n=this.menuProps)===null||n===void 0?void 0:n.class],clsPrefix:this.mergedClsPrefix,focusable:!0,labelField:this.labelField,valueField:this.valueField,autoPending:!0,nodeProps:this.nodeProps,theme:this.mergedTheme.peers.InternalSelectMenu,themeOverrides:this.mergedTheme.peerOverrides.InternalSelectMenu,treeMate:this.treeMate,multiple:this.multiple,size:"medium",renderOption:this.renderOption,renderLabel:this.renderLabel,value:this.mergedValue,style:[(o=this.menuProps)===null||o===void 0?void 0:o.style,this.cssVars],onToggle:this.handleToggle,onScroll:this.handleMenuScroll,onFocus:this.handleMenuFocus,onBlur:this.handleMenuBlur,onKeydown:this.handleMenuKeydown,onTabOut:this.handleMenuTabOut,onMousedown:this.handleMenuMousedown,show:this.mergedShow,showCheckmark:this.showCheckmark,resetMenuOnOptionsChange:this.resetMenuOnOptionsChange}),{empty:()=>{var d,a;return[(a=(d=this.$slots).empty)===null||a===void 0?void 0:a.call(d)]},header:()=>{var d,a;return[(a=(d=this.$slots).header)===null||a===void 0?void 0:a.call(d)]},action:()=>{var d,a;return[(a=(d=this.$slots).action)===null||a===void 0?void 0:a.call(d)]}}),this.displayDirective==="show"?[[wn,this.mergedShow],[ft,this.handleMenuClickOutside,void 0,{capture:!0}]]:[[ft,this.handleMenuClickOutside,void 0,{capture:!0}]])):null}})})]}))}});export{Ln as F,ao as N,En as V,qn as a,Hn as b,Gn as c,Kn as d,et as m,Ot as u};
